# Managed overlay consumer

Copy this folder outside the repository. Install the complete local
electron-game-overlay-0.1.0-rc.5.tgz as a production dependency:

```powershell
npm install --save-exact "C:\downloads\electron-game-overlay-0.1.0-rc.5.tgz"
npm start -- --smoke
npm start -- "--target=C:\Games\game.exe"
```

Keep the target closed until "Watcher armed". The exact path is the application's
explicit authorization. The controller baselines already-running processes and
rearms after authoritative exit. An uncertain attempt is never retried.
The early lane is exclusive across apps; best-effort exact-PID policy is available
for multi-application attachment but can miss fast graphics initialization.

Smoke creates a hidden genuine Electron DOM and a lazy SDK session, then exits.
It never creates a controller, starts a broker or injects. The native example
shows the established show/focus/intercept sequence and separately chooses its
DOM input. The app still owns input release, UI state and cleanup.

electron-builder.config.cjs demonstrates the SDK-owned afterPack helper and
required ASAR unpack pattern. Compose it with the application's other hooks.
No manual SDK path construction or nested-notice copy/filter logic is needed.

See [the rc.5 API and migration guide](../../doc/sdk-rc5-managed-attachment.md)
for update/cancel behavior, selector reservations and validation limits.
