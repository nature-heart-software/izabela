# RC.11 long-path activation readiness

The consumer's complete, unchanged RC.10 SDK successfully loaded and registered
the 293-character extended registered add-on path in the original long profile.
The fresh owned host then failed activation with owned late D3D11 error `0x15`
(`ERROR_NOT_READY`), retaining runtime ownership. No authenticated target,
graphics surface or structured native success arrived. The controlled graphics
startup barrier remained held. Fresh short-profile positive and separate
negative controls passed with the same app, SDK and native hashes.

This is a separate failure after the loader correction in
[RC.10](sdk-rc10-preload-long-path.md). Session and current discovery readiness,
or the DLL's registration log alone, do not establish overlay activation.

## Native failure and correction

The owned host checked callback readiness by taking a Toolhelp module snapshot.
An isolated Windows console probe extracts and executes the exact production
readiness functions with an inert data-export DLL. Its explicitly
`longPathAware=false` children demonstrate that `Module32FirstW` fails with
`ERROR_MORE_DATA` (234) after a DLL at a long path is mapped. The existing check
therefore returns false despite a valid module, ABI and callback-ready word.
The same exact selector succeeds at the 233-character short control and rejects
that control when the adapter-ready word is zero. At 259/260/289/293/320
characters, direct exported-word checks, handle enumeration and address-based
loader references still succeed while Toolhelp fails.

The correction uses `K32EnumProcessModules` to enumerate module handles without
materializing fixed-size module paths. It grows its buffer within a fixed
65536-module bound and eight attempts, rejects incomplete or malformed lists,
then retains each candidate's loader reference before checking its ABI and
actual callback-ready word. An explicitly present adapter-ready word still
takes precedence over the older cooperative-ready fallback. No readiness claim,
retry, ownership release or second ReShade injection is added.

Only the bundled owned ReShade host implementation changes. The EGO add-on
implementation, build ID `CCE20935ADD44EF6A5A7973014B2E07F` and cooperative ABI
remain unchanged. Generation 21 binds the new host patch in both architecture
stamps and the sealed SDK implementation, alongside the required generation-20
injector patch. Historical generation-19/20 source and package meanings remain
valid. Cache migration reverses the exact new host tail before the injector
tail under the existing lock, preserving recognized intermediate states and
rejecting unknown edits.

The new frozen patch SHA-256 is
`BCC0F0CD455B80DB3ED6D850B63600116B1D9881F1C85602CF76CEF7B23C35A6`.
Its final normalized host source SHA-256 is
`36753053450815B934A6117B1C072A2100AA86032DF30D937F9A127CA0F7A5F0`.
The injector source remains `91D82243D81D2CDC082DA1AF9BFF55A13315BF59F1FE5F9ACA1DFAE8442C8A10`.
All native tools were rebuilt, so their recorded binary hashes remain the
authority even when their implementation source did not change.

## Validation and handoff boundary

The [evidence record](evidence/sdk-rc11-preload-activation.json) separates exact
native selector and policy controls, SDK/package tests and actual consumer
acceptance. The new console fixture loads inert test modules only; it does not
load ReShade, launch a graphics target, execute the production injector or alter
another process. Source-cache fixtures are synthetic Git/CMake tests.

The complete SDK suite passes 1,316 of 1,326 tests with zero failures and ten
expected skips, at concurrency four. It includes 212 retained generation-19/20
cache controls and 14 new generation-21 cases. Both native builds and console
ABI smoke tests pass. The exact readiness fixture passes 61 candidate controls
on x64 and 61 on x86, including false readiness, invalid ABI, legacy fallback
and bounded enumeration failure/growth. The separate 54-control baseline
preserves the original failure. The complete sealed SDK contains 154 payloads;
installed-package acceptance and hashes are recorded in the release directory.

The local candidate is based on commit
`f51777621927ff090d0281ad069b720ed553d589` plus its exact uncommitted source
snapshot. Complete package and source hashes are recorded separately under
`artifacts/rc11-preload-activation` to avoid a self-referential source manifest.
No earlier candidate artifact is rewritten.

No Izabela source, installation, running application, user game or security
setting is changed here. No consumer graphics test runs for this correction.
The preserved original long-profile D3D11 positive and separate fresh
native-focus negative control must pass in the consumer's authorized retest
before that case is accepted. Existing targets retain their mapped host;
updating this SDK does not replace it. No foreign ReShade installation is
patched. The Windows 299 investigation remains paused.
