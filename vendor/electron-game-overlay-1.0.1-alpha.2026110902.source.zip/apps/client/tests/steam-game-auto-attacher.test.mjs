import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import test from 'node:test';
import fs from 'node:fs';
import path from 'node:path';

test('packaged watcher factory selects bundled Node without PATH and preserves development resolution', () => {
  const source = fs.readFileSync(new URL('../src/main/electron/app-entry.ts', import.meta.url), 'utf8');
  const expression = source.match(/new ForkedProcessWatcher\([\s\S]*?\n\s+\),/)[0].slice(0, -1);
  const resourcesPath = path.resolve('portable-demo/resources');
  const factoryArgs = (isPackaged) => new Function('app', 'process', 'path', 'ForkedProcessWatcher', 'resolveProcessWatcherEntry', 'reshadeConfig', `return ${expression}`)(
    { isPackaged }, { resourcesPath }, path, function (...args) { return args; },
    () => path.resolve('watcher.cjs'), { injectorPath: path.resolve('inject.exe') },
  );
  for (const env of [{ PATH: '' }, { PATH: '', npm_node_execpath: path.resolve('external/node.exe') }]) {
    assert.equal(resolveNodeExecutable(factoryArgs(true)[3], env, path.resolve('ElectronGameOverlayDemo.exe')), path.join(resourcesPath, 'node/node.exe'));
  }
  assert.equal(resolveNodeExecutable(factoryArgs(false)[3], { PATH: '' }, path.resolve('ElectronGameOverlayDemo.exe')), 'node');
  assert.equal(resolveNodeExecutable(factoryArgs(false)[3], { npm_node_execpath: process.execPath }, path.resolve('electron.exe')), process.execPath);
});
test('broker test mode disables the exclusive prearmed lane without changing default Steam attachment', () => {
  const source = fs.readFileSync(new URL('../src/main/electron/app-entry.ts', import.meta.url), 'utf8');
  const assignment = source.match(/this\.steamGameAutoAttacher =[\s\S]*?: null;/)[0];
  const configure = new Function('SteamGameAutoAttacher', 'steamAutoAttachRequested', 'reshadeConfig', 'process', `${assignment}\nreturn this.steamGameAutoAttacher;`);
  const capture = function (options) { return options; };
  const context = { overlaySession: {} };
  assert.equal(configure.call(context, capture, true, {}, { argv: ['--steam-exact-pid-only'] }).prearmedPathInjection, false);
  assert.equal(configure.call(context, capture, true, {}, { argv: ['--steam-exact-pid-only'] }).waitForSessionReady, true);
  assert.equal(configure.call(context, capture, true, {}, { argv: [] }).prearmedPathInjection, true);
  assert.equal(configure.call(context, capture, true, {}, { argv: [] }).waitForSessionReady, false);
  assert.equal(configure.call(context, capture, false, {}, { argv: ['--steam-exact-pid-only'] }), null);
});

import { ReShadeOperationError } from 'electron-game-overlay';
import { createReShadeOperationError } from '../../../libs/electron-game-overlay/dist/lib/reshade-launcher.js';
import {
  ForkedProcessWatcher,
  isSteamAppsProcessPath,
  resolveNodeExecutable,
  SteamGameAutoAttacher,
  stripAutomaticTargeting,
} from '../src/main/electron/steam-game-auto-attacher.ts';

test('watcher fork strips inherited preload hooks case-insensitively and parent flags', async () => {
  const keys = ['NoDe_OpTiOnS', 'node_path', 'Electron_Run_As_Node'];
  const saved = keys.map(key => process.env[key]);
  let options;
  const child = createFakeChildProcess();
  try {
    for (const key of keys) process.env[key] = 'untrusted';
    const watcher = new ForkedProcessWatcher(path.resolve('watcher.cjs'), path.resolve('inject.exe'), (_entry, _args, opts) => { options = opts; return child; }, process.execPath);
    watcher.start({ onEvent() {}, onStatus() {} });
    assert.equal(Object.keys(options.env).some(key => /^(NODE_OPTIONS|NODE_PATH|ELECTRON_RUN_AS_NODE)$/i.test(key)), false);
    assert.deepEqual(options.execArgv, []);
    child.emit('exit', 0, null);
    await watcher.stop();
  } finally { keys.forEach((key, i) => { if (saved[i] === undefined) delete process.env[key]; else process.env[key] = saved[i]; }); }
});

test('Node executable resolution avoids Electron and has a PATH fallback', () => {
  assert.equal(
    resolveNodeExecutable(
      ' C:\\portable-node\\node.exe ',
      { npm_node_execpath: 'C:\\npm\\node.exe' },
      'C:\\Electron\\electron.exe',
    ),
    'C:\\portable-node\\node.exe',
  );
  assert.equal(
    resolveNodeExecutable(
      undefined,
      { npm_node_execpath: 'C:\\npm\\node.exe' },
      'C:\\Electron\\electron.exe',
    ),
    'C:\\npm\\node.exe',
  );
  assert.equal(
    resolveNodeExecutable(
      undefined,
      { npm_node_execpath: 'C:\\Electron\\electron.exe' },
      'C:\\Program Files\\nodejs\\node.exe',
    ),
    'C:\\Program Files\\nodejs\\node.exe',
  );
  assert.equal(
    resolveNodeExecutable(
      undefined,
      { npm_node_execpath: 'C:\\Electron\\electron.exe' },
      'C:\\Electron\\electron.exe',
    ),
    'node',
  );
});

test('forked watcher uses real Node and preserves a detailed startup failure', () => {
  const child = createFakeChildProcess();
  const calls = [];
  const statuses = [];
  const watcher = new ForkedProcessWatcher(
    path.resolve('client/process-watcher/index.cjs'),
    path.resolve('runtime/inject.exe'),
    (...args) => {
      calls.push(args);
      return child;
    },
    'C:\\Program Files\\nodejs\\node.exe',
  );

  watcher.start({
    onEvent: () => assert.fail('no process event was expected'),
    onStatus: (status, error) => statuses.push({ status, error }),
  });

  assert.equal(calls.length, 1);
  assert.deepEqual(calls[0][1], [path.resolve('runtime/inject.exe')]);
  assert.equal(calls[0][2].execPath, 'C:\\Program Files\\nodejs\\node.exe');
  assert.equal(Object.hasOwn(calls[0][2].env, 'ELECTRON_RUN_AS_NODE'), false);

  child.emit('message', {
    type: 'process-watcher-error',
    error: 'WMI startup failed with HRESULT 0x80041003',
  });
  child.emit('exit', 1, null);

  assert.deepEqual(statuses, [
    { status: 'starting', error: undefined },
    {
      status: 'failed',
      error: 'WMI startup failed with HRESULT 0x80041003',
    },
  ]);
});

test('Steam application paths match case-insensitively across Windows separators', () => {
  assert.equal(
    isSteamAppsProcessPath(
      'D:\\SteamLibrary\\STEAMAPPS\\common\\Example\\game.exe',
    ),
    true,
  );
  assert.equal(
    isSteamAppsProcessPath('E:/games/steamapps/common/Example/bin/helper.EXE'),
    true,
  );
  assert.equal(
    isSteamAppsProcessPath('C:\\games\\notsteamapps\\game.exe'),
    false,
  );
  assert.equal(isSteamAppsProcessPath(''), false);
  assert.equal(isSteamAppsProcessPath(undefined), false);
});

test('automatic targeting options are removed from per-PID launcher configs', () => {
  const source = createConfig({
    autoTargetProcess: 'Gun Frog.exe',
    expectedTargetPid: 42,
  });
  const stripped = stripAutomaticTargeting(source);

  assert.equal(Object.hasOwn(stripped, 'autoTargetProcess'), false);
  assert.equal(Object.hasOwn(stripped, 'expectedTargetPid'), false);
  assert.equal(stripped.runtimeDirectory, source.runtimeDirectory);
  assert.equal(stripped.runsRootDirectory, source.runsRootDirectory);
});

test('the prearmed Steam path lane has no exclusions while every observed executable keeps an exact attempt', async () => {
  const watcher = new FakeProcessWatcher();
  const session = new FakeOverlaySession();
  const launchers = [];
  const autoAttacher = new SteamGameAutoAttacher({
    session,
    reshadeConfig: createConfig(),
    watcherFactory: () => watcher,
    launcherFactory: (config) => {
      const launcher = new FakeLauncher(config);
      launchers.push(launcher);
      return launcher;
    },
    prearmedPathInjection: true,
    preparedLauncherPoolSize: 0,
  });
  const processes = [
    processInfo(
      8801,
      'D:\\SteamLibrary\\steamapps\\common\\Gun Frog\\Gun Frog.exe',
    ),
    processInfo(
      8802,
      'D:\\SteamLibrary\\steamapps\\common\\Gun Frog\\UnityCrashHandler64.exe',
    ),
    processInfo(
      8803,
      'D:\\SteamLibrary\\steamapps\\common\\Steamworks Shared\\_CommonRedist\\VC_redist.x64.exe',
    ),
  ];

  autoAttacher.start();
  watcher.ready();
  await flushMicrotasks();
  assert.equal(launchers.length, 1);
  assert.deepEqual(launchers[0].target, {
    pathContains: '\\steamapps\\',
  });

  for (const info of processes) {
    watcher.create(info);
  }
  await flushMicrotasks();
  assert.equal(launchers.length, 4);
  assert.deepEqual(
    launchers.slice(1).map(({ target }) => target),
    processes.map(({ pid, process, filepath }) => ({
      processName: process,
      pid,
      executablePath: filepath,
    })),
  );

  launchers[0].connect(processes[0].pid, processes[0].filepath);
  await flushMicrotasks();
  assert.equal(
    launchers[1].disposed,
    true,
    'the exact loser must be released when the prearmed path wins',
  );
  assert.deepEqual(
    autoAttacher.targets.map(({ pid, phase }) => ({ pid, phase })),
    [
      { pid: 8801, phase: 'connected' },
      { pid: 8802, phase: 'attaching' },
      { pid: 8803, phase: 'attaching' },
    ],
  );
  assert.equal(launchers.length, 5);
  assert.deepEqual(launchers[4].target, {
    pathContains: '\\steamapps\\',
  });

  await autoAttacher.dispose();
});

test('early native selection coordinates the same incarnation while other Steam executables attach independently', async (t) => {
  for (const selectionFirst of [true, false]) {
    await t.test(selectionFirst ? 'selection before process event' : 'process event before selection', async () => {
      const watcher = new FakeProcessWatcher();
      const launchers = [];
      const autoAttacher = new SteamGameAutoAttacher({
        session: new FakeOverlaySession(), reshadeConfig: createConfig(),
        watcherFactory: () => watcher, prearmedPathInjection: true,
        preparedLauncherPoolSize: 0,
        launcherFactory: config => {
          const launcher = new EventLauncher(config);
          launchers.push(launcher);
          return launcher;
        },
      });
      const game = { ...processInfo(8804, 'D:\\Steam\\steamapps\\common\\Game\\game.exe'), creationTime100ns: '1234' };
      const helper = processInfo(8805, 'D:\\Steam\\steamapps\\common\\Game\\UnityCrashHandler64.exe');
      autoAttacher.start(); watcher.ready();
      await flushMicrotasks();
      const early = launchers[0];
      const select = () => early.emit({ type: 'target-selected', pid: game.pid, executablePath: game.filepath, creationTime100ns: game.creationTime100ns });
      if (selectionFirst) select();
      watcher.create(game); watcher.create(helper);
      await flushMicrotasks();
      if (!selectionFirst) {
        assert.equal(launchers.length, 1, 'wait only for the early selection, never its startup grace');
        select();
      }
      await flushMicrotasks();
      assert.equal(launchers.length, 2);
      assert.equal(launchers[1].target.pid, helper.pid, 'helper exact attempt is independent of the selected game');
      assert.equal(early.disposed, false, 'coordinating the exact observation preserves the leader');
      early.connect(game.pid, game.filepath);
      await flushMicrotasks();
      assert.equal(autoAttacher.targets.find(target => target.pid === game.pid).phase, 'connected');
      assert.equal(early.disposed, false, 'adoption must not dispose the live prearmed route');
      await autoAttacher.dispose();
      assert.equal(early.disposed, true);
    });
  }
});

test('a selected helper does not hold another executable behind official startup grace', async () => {
  const watcher = new FakeProcessWatcher(), launchers = [];
  const autoAttacher = new SteamGameAutoAttacher({
    session: new FakeOverlaySession(), reshadeConfig: createConfig(), watcherFactory: () => watcher,
    prearmedPathInjection: true, preparedLauncherPoolSize: 0,
    launcherFactory: config => { const launcher = new EventLauncher(config); launchers.push(launcher); return launcher; },
  });
  autoAttacher.start(); watcher.ready(); await flushMicrotasks();
  const helper = processInfo(8806, 'D:\\Steam\\steamapps\\common\\Game\\UnityCrashHandler64.exe');
  launchers[0].emit({ type: 'target-selected', pid: helper.pid, executablePath: helper.filepath, creationTime100ns: '1235' });
  watcher.create(helper);
  watcher.create(processInfo(8807, 'D:\\Steam\\steamapps\\common\\Game\\game.exe'));
  await flushMicrotasks();
  assert.equal(launchers.length, 2);
  assert.equal(launchers[1].target.pid, 8807);
  assert.equal(launchers[0].state, 'attaching');
  launchers[0].fail(new Error('selected helper startup failed'));
  await flushMicrotasks();
  assert.equal(autoAttacher.targets.find(target => target.pid === helper.pid).phase, 'failed');
  assert.equal(launchers.length, 2, 'an uncertain selected attempt must not start a fallback injection');
  await autoAttacher.dispose();
});

test('selection wait is bounded and stale selected incarnations cannot adopt a reused PID', async () => {
  const watcher = new FakeProcessWatcher(), launchers = [];
  const autoAttacher = new SteamGameAutoAttacher({
    session: new FakeOverlaySession(), reshadeConfig: createConfig(), watcherFactory: () => watcher,
    prearmedPathInjection: true, preparedLauncherPoolSize: 0,
    launcherFactory: config => { const launcher = new EventLauncher(config); launchers.push(launcher); return launcher; },
  });
  autoAttacher.start(); watcher.ready(); await flushMicrotasks();
  const game = { ...processInfo(8808, 'D:\\Steam\\steamapps\\common\\Game\\game.exe'), creationTime100ns: '1236' };
  watcher.create(game);
  await new Promise(resolve => setTimeout(resolve, 130));
  assert.equal(launchers[0].quiescenceCalls, 1);
  assert.equal(launchers[0].disposed, true, 'bounded fallback requires completed no-selection quiescence');
  assert.equal(launchers[1].target.pid, game.pid, 'an unselected broad watcher cannot indefinitely reserve every executable');
  const selectedLauncher = launchers.at(-1);
  selectedLauncher.emit({ type: 'target-selected', pid: game.pid, executablePath: game.filepath, creationTime100ns: '1236' });
  watcher.delete(game);
  watcher.create({ ...game, creationTime100ns: '1237' });
  await flushMicrotasks();
  assert.equal(launchers.at(-1).target.pid, game.pid, 'the new incarnation gets its own exact attempt');
  assert.notEqual(launchers.at(-1), selectedLauncher);
  selectedLauncher.connect(game.pid, game.filepath);
  await flushMicrotasks();
  assert.equal(autoAttacher.targets.find(target => target.pid === game.pid).phase, 'attaching');
  assert.equal(selectedLauncher.disposed, true, 'a stale completion cannot replace the new incarnation');
  await autoAttacher.dispose();
});

test('an uncertain watcher stop never authorizes an exact fallback', async () => {
  const watcher = new FakeProcessWatcher(), launchers = [];
  const autoAttacher = new SteamGameAutoAttacher({
    session: new FakeOverlaySession(), reshadeConfig: createConfig(), watcherFactory: () => watcher,
    prearmedPathInjection: true, preparedLauncherPoolSize: 0,
    launcherFactory: config => {
      const launcher = new EventLauncher(config);
      launcher.quiesceUnselectedFutureWatcher = () => Promise.resolve(false);
      launchers.push(launcher); return launcher;
    },
  });
  autoAttacher.start(); watcher.ready(); await flushMicrotasks();
  watcher.create(processInfo(8809, 'D:\\Steam\\steamapps\\common\\Game\\game.exe'));
  await new Promise(resolve => setTimeout(resolve, 130));
  assert.equal(launchers.length, 1, 'no new native invocation is allowed without drained no-selection proof');
  assert.equal(autoAttacher.targets[0].phase, 'failed');
  assert.match(autoAttacher.targets[0].error, /could not prove safe quiescence/);
  assert.equal(launchers[0].disposed, false, 'uncertain native ownership remains reserved');
  await autoAttacher.dispose();
});

test('an exact-PID winner keeps the target connected when the prearmed attempt loses its native claim', async () => {
  const watcher = new FakeProcessWatcher();
  const session = new FakeOverlaySession();
  const launchers = [];
  const autoAttacher = new SteamGameAutoAttacher({
    session,
    reshadeConfig: createConfig(),
    watcherFactory: () => watcher,
    launcherFactory: (config) => {
      const launcher = new FakeLauncher(config);
      launchers.push(launcher);
      return launcher;
    },
    prearmedPathInjection: true,
    preparedLauncherPoolSize: 0,
  });
  const info = processInfo(
    8811,
    'D:\\SteamLibrary\\steamapps\\common\\Race\\race.exe',
  );

  autoAttacher.start();
  watcher.ready();
  watcher.create(info);
  await flushMicrotasks();
  assert.equal(launchers.length, 2);

  launchers[1].connect(info.pid, info.filepath);
  await flushMicrotasks();
  launchers[0].fail(
    createReShadeOperationError({
      stage: 'target-preflight',
      code: 'target-injection-already-claimed',
      retrySafety: 'definite-safe',
      message: 'another injector owns the target claim',
      targetLabel: 'path:\\steamapps\\',
      pid: info.pid,
    }),
  );
  await flushMicrotasks();

  assert.deepEqual(autoAttacher.targets, [
    {
      pid: info.pid,
      processName: 'race.exe',
      filepath: info.filepath,
      phase: 'connected',
      error: null,
      diagnostic: null,
    },
  ]);
  assert.equal(launchers[0].disposed, true);
  assert.equal(launchers[1].disposed, false);
  assert.equal(launchers.length, 3);
  assert.deepEqual(launchers[2].target, {
    pathContains: '\\steamapps\\',
  });

  await autoAttacher.dispose();
});

test('a path-first connection owns the later exact observation without a second engine', async () => {
  const watcher = new FakeProcessWatcher();
  const session = new FakeOverlaySession();
  const launchers = [];
  const autoAttacher = new SteamGameAutoAttacher({
    session,
    reshadeConfig: createConfig(),
    watcherFactory: () => watcher,
    launcherFactory: (config) => {
      const launcher = new FakeLauncher(config);
      launchers.push(launcher);
      return launcher;
    },
    prearmedPathInjection: true,
    preparedLauncherPoolSize: 0,
  });
  const info = processInfo(
    8821,
    'D:\\SteamLibrary\\steamapps\\common\\Path First\\path-first.exe',
  );

  autoAttacher.start();
  watcher.ready();
  await flushMicrotasks();
  launchers[0].connect(info.pid, info.filepath);
  await flushMicrotasks();
  assert.equal(autoAttacher.targets[0].phase, 'connected');
  assert.deepEqual(launchers[1].target, {
    pathContains: '\\steamapps\\',
  });

  watcher.create(info);
  await flushMicrotasks();
  assert.equal(launchers.length, 2);
  assert.equal(launchers[0].disposed, false);
  assert.equal(autoAttacher.targets[0].phase, 'connected');

  await autoAttacher.dispose();
});

test('existing-runtime reuse failures remain visible with their SDK retry safety', async (t) => {
  const scenarios = [
    {
      code: 'target-runtime-incompatible',
      retrySafety: 'definite-safe',
      message: 'the existing ReShade runtime is not ABI compatible',
      stage: 'target-preflight',
    },
    {
      code: 'target-runtime-reuse-too-late',
      retrySafety: 'definite-safe',
      message: 'the existing runtime can no longer accept this add-on',
      stage: 'target-preflight',
    },
    {
      code: 'target-runtime-reuse-raced',
      retrySafety: 'definite-safe',
      message: 'the target runtime changed during reuse preflight',
      stage: 'target-preflight',
    },
    {
      code: 'existing-runtime-addon-load-failed',
      retrySafety: 'indeterminate',
      message: 'the existing runtime add-on load outcome is indeterminate',
      stage: 'injector',
    },
  ];

  for (const [index, scenario] of scenarios.entries()) {
    await t.test(scenario.code, async () => {
      const watcher = new FakeProcessWatcher();
      const session = new FakeOverlaySession();
      const launchers = [];
      const autoAttacher = new SteamGameAutoAttacher({
        session,
        reshadeConfig: createConfig(),
        watcherFactory: () => watcher,
        launcherFactory: (config) => {
          const launcher = new FakeLauncher(config);
          launchers.push(launcher);
          return launcher;
        },
        prearmedPathInjection: true,
        preparedLauncherPoolSize: 0,
      });
      const pid = 8841 + index;
      const filepath = `D:\\SteamLibrary\\steamapps\\common\\Reuse Failure ${index}\\reuse-failure-${index}.exe`;

      autoAttacher.start();
      watcher.ready();
      watcher.create(processInfo(pid, filepath));
      await flushMicrotasks();
      assert.equal(launchers.length, 2);

      const failure = createReShadeOperationError({
        stage: scenario.stage,
        code: scenario.code,
        retrySafety: scenario.retrySafety,
        message: scenario.message,
        targetLabel: 'path:\\steamapps\\',
        pid,
      });
      launchers[0].fail(failure);
      await flushMicrotasks();

      assert.deepEqual(autoAttacher.targets, [
        {
          pid,
          processName: `reuse-failure-${index}.exe`,
          filepath,
          phase: 'failed',
          error: scenario.message,
          diagnostic: failure.diagnostic,
        },
      ]);

      await autoAttacher.dispose();
    });
  }
});

test('deferred official add-on maintenance keeps the exact launcher until target exit', async (t) => {
  for (const [index, code] of [
    'existing-reshade-addon-maintenance-deferred',
  ].entries()) {
    await t.test(code, async () => {
      const watcher = new FakeProcessWatcher();
      const session = new FakeOverlaySession();
      const launchers = [];
      const autoAttacher = new SteamGameAutoAttacher({
        session,
        reshadeConfig: createConfig(),
        watcherFactory: () => watcher,
        launcherFactory: (config) => {
          const launcher = new FakeLauncher(config);
          launchers.push(launcher);
          return launcher;
        },
        preparedLauncherPoolSize: 0,
      });
      const pid = 8845 + index;
      const filepath = `D:\\SteamLibrary\\steamapps\\common\\Official Addon ${index}\\official-addon-${index}.exe`;

      autoAttacher.start();
      watcher.create(processInfo(pid, filepath));
      await flushMicrotasks();

      launchers[0].fail(
        createReShadeOperationError({
          stage: 'target-preflight',
          code,
          retrySafety: 'definite-safe',
          message: 'the managed add-on needs target-exit maintenance',
          targetLabel: `process:official-addon-${index}.exe:pid:${pid}`,
          pid,
        }),
      );
      await flushMicrotasks();

      assert.equal(launchers[0].disposed, false);
      assert.deepEqual(launchers[0].exitConfirmations, []);
      watcher.delete(processInfo(pid + 100, ''));
      assert.equal(launchers[0].disposed, false);

      watcher.delete(processInfo(pid, filepath));
      assert.deepEqual(launchers[0].exitConfirmations, [
        { pid, confirmed: false },
      ]);
      assert.equal(launchers[0].disposed, true);
      assert.deepEqual(launchers[0].order.slice(-2), [
        `launcher-confirm-exit:${pid}:false`,
        'launcher-dispose',
      ]);

      await autoAttacher.dispose();
    });
  }
});

test('official add-on failures without deferred work dispose their launchers immediately', async (t) => {
  for (const [index, code] of [
    'existing-reshade-addon-preparation-failed',
    'existing-reshade-addon-restart-required',
    'existing-reshade-addon-conflict',
    'existing-reshade-addon-host-incompatible',
  ].entries()) {
    await t.test(code, async () => {
      const watcher = new FakeProcessWatcher();
      const session = new FakeOverlaySession();
      const launchers = [];
      const autoAttacher = new SteamGameAutoAttacher({
        session,
        reshadeConfig: createConfig(),
        watcherFactory: () => watcher,
        launcherFactory: (config) => {
          const launcher = new FakeLauncher(config);
          launchers.push(launcher);
          return launcher;
        },
        preparedLauncherPoolSize: 0,
      });
      const pid = 8860 + index;
      const filepath = `D:\\SteamLibrary\\steamapps\\common\\Official Refusal ${index}\\official-refusal-${index}.exe`;

      autoAttacher.start();
      watcher.create(processInfo(pid, filepath));
      await flushMicrotasks();
      launchers[0].fail(
        createReShadeOperationError({
          stage: 'target-preflight',
          code,
          retrySafety: 'definite-safe',
          message: 'no target-exit maintenance was scheduled',
          targetLabel: `process:official-refusal-${index}.exe:pid:${pid}`,
          pid,
        }),
      );
      await flushMicrotasks();

      assert.equal(launchers[0].disposed, true);
      assert.deepEqual(launchers[0].exitConfirmations, []);
      await autoAttacher.dispose();
    });
  }
});

test('a prearmed maintenance failure also reaches its launcher at the observed process exit', async () => {
  const watcher = new FakeProcessWatcher();
  const session = new FakeOverlaySession();
  const launchers = [];
  const autoAttacher = new SteamGameAutoAttacher({
    session,
    reshadeConfig: createConfig(),
    watcherFactory: () => watcher,
    launcherFactory: (config) => {
      const launcher = new FakeLauncher(config);
      launchers.push(launcher);
      return launcher;
    },
    prearmedPathInjection: true,
    preparedLauncherPoolSize: 0,
  });
  const pid = 8847;
  const filepath =
    'D:\\SteamLibrary\\steamapps\\common\\Official Path\\official-path.exe';

  autoAttacher.start();
  watcher.ready();
  await flushMicrotasks();
  launchers[0].fail(
    createReShadeOperationError({
      stage: 'target-preflight',
      code: 'existing-reshade-addon-maintenance-deferred',
      retrySafety: 'definite-safe',
      message: 'the mapped add-on could not be updated while loaded',
      targetLabel: 'path:\\steamapps\\',
      pid,
    }),
  );
  await new Promise((resolve) => setTimeout(resolve, 300));

  assert.equal(launchers[0].disposed, false);
  assert.equal(launchers.length, 2, 'the retry-safe path lane should rearm');
  watcher.delete(processInfo(pid, filepath));
  assert.deepEqual(launchers[0].exitConfirmations, [{ pid, confirmed: false }]);
  assert.equal(launchers[0].disposed, true);
  assert.deepEqual(launchers[0].order.slice(-2), [
    `launcher-confirm-exit:${pid}:false`,
    'launcher-dispose',
  ]);

  await autoAttacher.dispose();
});

test('the prearmed lane rearms only after a retry-safe failure or its blocked target exits', async (t) => {
  const scenarios = [
    {
      name: 'definite-safe failure rearms',
      code: 'target-runtime-incompatible',
      retrySafety: 'definite-safe',
      expectedLauncherCount: 3,
    },
    {
      name: 'indeterminate failure remains blocked',
      code: 'existing-runtime-addon-load-failed',
      retrySafety: 'indeterminate',
      expectedLauncherCount: 2,
    },
  ];

  for (const [index, scenario] of scenarios.entries()) {
    await t.test(scenario.name, async () => {
      const watcher = new FakeProcessWatcher();
      const session = new FakeOverlaySession();
      const launchers = [];
      const autoAttacher = new SteamGameAutoAttacher({
        session,
        reshadeConfig: createConfig(),
        watcherFactory: () => watcher,
        launcherFactory: (config) => {
          const launcher = new FakeLauncher(config);
          launchers.push(launcher);
          return launcher;
        },
        prearmedPathInjection: true,
        preparedLauncherPoolSize: 0,
      });
      const pid = 8851 + index;
      const filepath = `D:\\SteamLibrary\\steamapps\\common\\Retry Safety ${index}\\retry-safety-${index}.exe`;

      autoAttacher.start();
      watcher.ready();
      watcher.create(processInfo(pid, filepath));
      await flushMicrotasks();
      assert.equal(launchers.length, 2);

      launchers[0].fail(
        createReShadeOperationError({
          stage:
            scenario.retrySafety === 'definite-safe'
              ? 'target-preflight'
              : 'injector',
          code: scenario.code,
          retrySafety: scenario.retrySafety,
          message: scenario.name,
          targetLabel: 'path:\\steamapps\\',
          pid,
        }),
      );
      await new Promise((resolve) => setTimeout(resolve, 300));

      assert.equal(launchers.length, scenario.expectedLauncherCount);
      assert.equal(autoAttacher.targets[0].phase, 'failed');

      if (scenario.retrySafety === 'indeterminate') {
        watcher.delete(processInfo(pid + 100, ''));
        await flushMicrotasks();
        assert.equal(
          launchers.length,
          2,
          'an unrelated process exit must not release the blocked path lane',
        );

        watcher.delete(processInfo(pid, filepath));
        await flushMicrotasks();
        assert.equal(
          launchers.length,
          3,
          'the blocked target exit is a safe boundary for a fresh path lane',
        );
      }

      await autoAttacher.dispose();
    });
  }
});

test('a target exit observed before an indeterminate path result still releases that lane', async () => {
  const watcher = new FakeProcessWatcher();
  const session = new FakeOverlaySession();
  const launchers = [];
  const autoAttacher = new SteamGameAutoAttacher({
    session,
    reshadeConfig: createConfig(),
    watcherFactory: () => watcher,
    launcherFactory: (config) => {
      const launcher = new FakeLauncher(config);
      launchers.push(launcher);
      return launcher;
    },
    prearmedPathInjection: true,
    preparedLauncherPoolSize: 0,
  });
  const info = processInfo(
    8853,
    'D:\\SteamLibrary\\steamapps\\common\\Early Exit\\early-exit.exe',
  );

  autoAttacher.start();
  watcher.ready();
  watcher.create(info);
  await flushMicrotasks();
  assert.equal(launchers.length, 2);

  watcher.delete(info);
  await flushMicrotasks();
  launchers[0].fail(
    createReShadeOperationError({
      stage: 'runtime-initialization',
      code: 'existing-runtime-addon-load-failed',
      retrySafety: 'indeterminate',
      message: 'the result arrived after the observed exit',
      targetLabel: 'path:\\steamapps\\',
      pid: info.pid,
    }),
  );
  await flushMicrotasks();

  assert.equal(
    launchers.length,
    3,
    'the retained process-exit proof must release the path lane immediately',
  );

  await autoAttacher.dispose();
});

test('an exact startup-grace loser waits for its prearmed owner outcome', async () => {
  const watcher = new FakeProcessWatcher();
  const session = new FakeOverlaySession();
  const launchers = [];
  const autoAttacher = new SteamGameAutoAttacher({
    session,
    reshadeConfig: createConfig(),
    watcherFactory: () => watcher,
    launcherFactory: (config) => {
      const launcher = new FakeLauncher(config);
      launchers.push(launcher);
      return launcher;
    },
    prearmedPathInjection: true,
    preparedLauncherPoolSize: 0,
  });
  const info = processInfo(
    8831,
    'D:\\SteamLibrary\\steamapps\\common\\Claim Failure\\claim-failure.exe',
  );

  autoAttacher.start();
  watcher.ready();
  watcher.create(info);
  await flushMicrotasks();
  assert.equal(launchers.length, 2);

  launchers[1].fail(
    createReShadeOperationError({
      stage: 'target-preflight',
      code: 'official-addon-startup-grace-coordinated',
      retrySafety: 'definite-safe',
      message: 'the prearmed lane owns the startup grace',
      targetLabel: 'process:claim-failure.exe:pid:8831',
      pid: info.pid,
    }),
  );
  await flushMicrotasks();
  assert.equal(autoAttacher.targets[0].phase, 'attaching');

  launchers[0].fail(new Error('the path injector failed after selection'));
  await flushMicrotasks();
  assert.equal(
    autoAttacher.targets[0].phase,
    'failed',
    'the coordinated target must not remain permanently attaching',
  );

  await autoAttacher.dispose();
});

test('broker readiness gate stages in parallel and starts observation after session and first prepared launcher', { timeout: 2000 }, async (t) => {
  for (const sessionFirst of [true, false]) {
    const ready = createDeferred();
    const preparations = [createDeferred(), createDeferred()];
    const session = new FakeOverlaySession();
    session.whenReady = () => ready.promise;
    const watcher = new FakeProcessWatcher();
    const launchers = [];
    const attacher = new SteamGameAutoAttacher({
      session, reshadeConfig: createConfig(), watcherFactory: () => watcher,
      waitForSessionReady: true, prearmedPathInjection: false, preparedLauncherPoolSize: 2,
      launcherFactory: config => {
        const index = launchers.length;
        const launcher = new FakeLauncher(config, [], () => preparations[index]?.promise ?? Promise.resolve());
        launchers.push(launcher);
        return launcher;
      },
    });
    t.after(() => attacher.dispose());
    attacher.start();
    assert.equal(launchers.length, 2, 'pool staging starts while session readiness is pending');
    assert.equal(watcher.handlers, null, 'native watcher started before broker readiness');
    (sessionFirst ? ready : preparations[1]).resolve();
    await flushMicrotasks();
    assert.equal(watcher.handlers, null, 'both readiness conditions are required');
    assert.equal(attacher.watcherStatus, 'starting');
    (sessionFirst ? preparations[1] : ready).resolve();
    await flushMicrotasks();
    assert.notEqual(watcher.handlers, null, 'one prepared success is sufficient; the other remains pending');
    assert.equal(attacher.watcherStatus, 'starting');
    watcher.ready();
    assert.equal(attacher.watcherStatus, 'running');
    const info = processInfo(9901, 'D:/Steam/steamapps/common/Game/UnityCrashHandler64.exe');
    watcher.create(info);
    await flushMicrotasks();
    assert.deepEqual(launchers[1].target, { processName: info.process, pid: info.pid, executablePath: info.filepath });
    assert.equal(launchers[0].target, null);
    await attacher.dispose();
    preparations[0].resolve();
    await flushMicrotasks();
  }
});

test('broker readiness rejection fails closed even when native preparation finishes later', { timeout: 2000 }, async (t) => {
  const ready = createDeferred();
  const preparation = createDeferred();
  const session = new FakeOverlaySession();
  session.whenReady = () => ready.promise;
  const watcher = new FakeProcessWatcher();
  const attacher = new SteamGameAutoAttacher({
    session, reshadeConfig: createConfig(), watcherFactory: () => watcher,
    waitForSessionReady: true, preparedLauncherPoolSize: 1,
    launcherFactory: config => new FakeLauncher(config, [], () => preparation.promise),
  });
  t.after(() => attacher.dispose());
  attacher.start();
  await flushMicrotasks();
  ready.reject(new Error('private filesystem detail ' + 'x'.repeat(5000)));
  await flushMicrotasks();
  assert.equal(attacher.watcherStatus, 'failed');
  assert.equal(attacher.watcherError, 'overlay session readiness failed');
  preparation.resolve();
  await flushMicrotasks();
  assert.equal(watcher.handlers, null);
  assert.equal(attacher.watcherStatus, 'failed');
});

test('broker readiness gate ignores settlement after disposal and supports a disabled pool', { timeout: 2000 }, async (t) => {
  for (const disposeEarly of [false, true]) {
    const ready = createDeferred();
    const session = new FakeOverlaySession();
    session.whenReady = () => ready.promise;
    const watcher = new FakeProcessWatcher();
    const attacher = new SteamGameAutoAttacher({
      session, reshadeConfig: createConfig(), watcherFactory: () => watcher,
      waitForSessionReady: true, preparedLauncherPoolSize: 0,
      launcherFactory: () => assert.fail('disabled pool must not stage launchers'),
    });
    t.after(() => attacher.dispose());
    attacher.start();
    assert.equal(watcher.handlers, null);
    if (disposeEarly) await attacher.dispose();
    ready.resolve();
    await flushMicrotasks();
    assert.equal(watcher.handlers === null, disposeEarly);
    assert.equal(attacher.watcherStatus, disposeEarly ? 'stopped' : 'starting');
    await attacher.dispose();
    assert.ok([...session.handlers.values()].every(handlers => handlers.size === 0));
  }
});

test('broker readiness gate fails explicitly when session readiness is unavailable', { timeout: 2000 }, async (t) => {
  const session = new FakeOverlaySession();
  session.whenReady = undefined;
  const watcher = new FakeProcessWatcher();
  const attacher = new SteamGameAutoAttacher({
    session, reshadeConfig: createConfig(), watcherFactory: () => watcher,
    waitForSessionReady: true, preparedLauncherPoolSize: 0,
  });
  t.after(() => attacher.dispose());
  attacher.start();
  await flushMicrotasks();
  assert.equal(attacher.watcherStatus, 'failed');
  assert.equal(watcher.handlers, null);
});

test('broker readiness gate keeps starting through preparation failure until a retry succeeds', { timeout: 2000 }, async (t) => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  const watcher = new FakeProcessWatcher();
  const launchers = [];
  const attacher = new SteamGameAutoAttacher({
    session: new FakeOverlaySession(), reshadeConfig: createConfig(), watcherFactory: () => watcher,
    waitForSessionReady: true, preparedLauncherPoolSize: 1,
    preparedLauncherRetryBaseDelayMs: 50,
    launcherFactory: config => {
      const first = launchers.length === 0;
      const launcher = new FakeLauncher(config, [], () => first ? Promise.reject(new Error('staging failed')) : Promise.resolve());
      launchers.push(launcher);
      return launcher;
    },
  });
  t.after(() => attacher.dispose());
  attacher.start();
  await flushMicrotasks();
  assert.equal(attacher.watcherStatus, 'starting');
  assert.equal(watcher.handlers, null);
  t.mock.timers.tick(50);
  await flushMicrotasks();
  assert.equal(launchers.length, 2);
  assert.notEqual(watcher.handlers, null);
  watcher.ready();
  assert.equal(attacher.watcherStatus, 'running');
});

test('the watcher starts before prewarm and queued targets consume immediately replenished slots', async () => {
  const watcher = new FakeProcessWatcher();
  const session = new FakeOverlaySession();
  const initialPreparations = [createDeferred(), createDeferred()];
  const launchers = [];
  const autoAttacher = new SteamGameAutoAttacher({
    session,
    reshadeConfig: createConfig(),
    watcherFactory: () => watcher,
    launcherFactory: (config) => {
      const index = launchers.length;
      const launcher = new FakeLauncher(
        config,
        [],
        index < initialPreparations.length
          ? () => initialPreparations[index].promise
          : undefined,
      );
      launchers.push(launcher);
      return launcher;
    },
    preparedLauncherPoolSize: 2,
  });

  autoAttacher.start();
  assert.equal(launchers.length, 2);
  assert.notEqual(
    watcher.handlers,
    null,
    'native observation must not wait for every runtime copy to finish',
  );
  assert.equal(autoAttacher.watcherStatus, 'starting');

  watcher.create(
    processInfo(
      9010,
      'D:\\SteamLibrary\\steamapps\\common\\Prepared\\first.exe',
    ),
  );
  watcher.create(
    processInfo(
      9011,
      'D:\\SteamLibrary\\steamapps\\common\\Prepared\\second.exe',
    ),
  );
  await flushMicrotasks();
  assert.equal(launchers[0].target, null);
  assert.equal(launchers[1].target, null);

  initialPreparations[0].resolve();
  await flushMicrotasks();
  await flushMicrotasks();
  assert.deepEqual(launchers[0].target, {
    processName: 'first.exe',
    pid: 9010,
    executablePath: 'D:\\SteamLibrary\\steamapps\\common\\Prepared\\first.exe',
  });
  assert.equal(
    launchers.length,
    4,
    'each consumed slot should begin one bounded replacement immediately',
  );
  assert.deepEqual(launchers[2].target, {
    processName: 'second.exe',
    pid: 9011,
    executablePath: 'D:\\SteamLibrary\\steamapps\\common\\Prepared\\second.exe',
  });
  assert.equal(launchers[1].target, null);
  assert.equal(launchers[3].prepared, true);
  assert.equal(launchers[3].target, null);

  initialPreparations[1].resolve();
  await flushMicrotasks();
  await autoAttacher.dispose();
});

test('failed pool preparation backs off without delaying watcher startup or exceeding the pool bound', async (t) => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  const watcher = new FakeProcessWatcher();
  const session = new FakeOverlaySession();
  const launchers = [];
  const autoAttacher = new SteamGameAutoAttacher({
    session,
    reshadeConfig: createConfig(),
    watcherFactory: () => watcher,
    launcherFactory: (config) => {
      const launcher = new FakeLauncher(config, [], () =>
        Promise.reject(new Error('runtime staging failed')),
      );
      launchers.push(launcher);
      return launcher;
    },
    preparedLauncherPoolSize: 2,
    preparedLauncherRetryBaseDelayMs: 50,
    preparedLauncherRetryMaxDelayMs: 200,
  });

  autoAttacher.start();
  await flushMicrotasks();

  assert.notEqual(
    watcher.handlers,
    null,
    'a failed pool member must not prevent the watcher from starting',
  );
  assert.equal(launchers.length, 2);
  assert.equal(launchers[0].disposed, true);
  assert.equal(launchers[1].disposed, true);
  assert.equal(launchers[0].prepared, false);

  t.mock.timers.tick(49);
  await flushMicrotasks();
  assert.equal(launchers.length, 2);
  t.mock.timers.tick(1);
  await flushMicrotasks();
  assert.equal(
    launchers.length,
    4,
    'one retry pass should remain bounded by the configured pool size',
  );

  t.mock.timers.tick(199);
  await flushMicrotasks();
  assert.equal(launchers.length, 4);
  t.mock.timers.tick(1);
  await flushMicrotasks();
  assert.equal(launchers.length, 6);

  await autoAttacher.dispose();
});

test('dispose releases both unused and still-preparing pool launchers', async () => {
  const watcher = new FakeProcessWatcher();
  const pendingPreparation = createDeferred();
  const launchers = [];
  const autoAttacher = new SteamGameAutoAttacher({
    session: new FakeOverlaySession(),
    reshadeConfig: createConfig(),
    watcherFactory: () => watcher,
    launcherFactory: (config) => {
      const index = launchers.length;
      const launcher = new FakeLauncher(
        config,
        [],
        index === 1 ? () => pendingPreparation.promise : undefined,
      );
      launchers.push(launcher);
      return launcher;
    },
    preparedLauncherPoolSize: 2,
  });

  autoAttacher.start();
  await flushMicrotasks();
  assert.equal(launchers[0].prepared, true);
  assert.equal(launchers[1].prepared, false);
  assert.notEqual(watcher.handlers, null);

  await autoAttacher.dispose();
  assert.equal(launchers[0].disposed, true);
  assert.equal(launchers[1].disposed, true);
  assert.equal(watcher.stopped, true);
  assert.equal(autoAttacher.watcherStatus, 'stopped');

  pendingPreparation.resolve();
  await flushMicrotasks();
  assert.equal(launchers.length, 2);
});

test('a process deleted while queued is never attached after preparation finishes', async () => {
  const watcher = new FakeProcessWatcher();
  const pendingPreparation = createDeferred();
  const launchers = [];
  const autoAttacher = new SteamGameAutoAttacher({
    session: new FakeOverlaySession(),
    reshadeConfig: createConfig(),
    watcherFactory: () => watcher,
    launcherFactory: (config) => {
      const launcher = new FakeLauncher(
        config,
        [],
        () => pendingPreparation.promise,
      );
      launchers.push(launcher);
      return launcher;
    },
    preparedLauncherPoolSize: 1,
  });
  const info = processInfo(
    9030,
    'D:\\SteamLibrary\\steamapps\\common\\Gone\\gone.exe',
  );

  autoAttacher.start();
  watcher.create(info);
  watcher.delete(info);
  pendingPreparation.resolve();
  await flushMicrotasks();

  assert.equal(launchers.length, 1);
  assert.equal(launchers[0].target, null);
  assert.deepEqual(autoAttacher.targets, []);
  await autoAttacher.dispose();
});

test('connected and attaching target deletion is confirmed before launcher disposal', async () => {
  const watcher = new FakeProcessWatcher();
  const session = new FakeOverlaySession();
  const order = [];
  const launchers = [];
  const autoAttacher = new SteamGameAutoAttacher({
    session,
    reshadeConfig: createConfig(),
    watcherFactory: () => watcher,
    launcherFactory: (config) => {
      const launcher = new FakeLauncher(config, order);
      launchers.push(launcher);
      return launcher;
    },
    preparedLauncherPoolSize: 0,
  });
  const watcherDeleted = processInfo(
    9040,
    'D:\\SteamLibrary\\steamapps\\common\\Deleted\\deleted.exe',
  );
  const sessionDisconnected = processInfo(
    9041,
    'D:\\SteamLibrary\\steamapps\\common\\Disconnected\\disconnected.exe',
  );
  const attachingDeleted = processInfo(
    9042,
    'D:\\SteamLibrary\\steamapps\\common\\Attaching\\attaching.exe',
  );

  autoAttacher.start();
  watcher.create(watcherDeleted);
  await flushMicrotasks();
  launchers[0].connect(watcherDeleted.pid, watcherDeleted.filepath);
  await flushMicrotasks();

  watcher.delete(watcherDeleted);

  assert.deepEqual(launchers[0].exitConfirmations, [
    { pid: watcherDeleted.pid, confirmed: true },
  ]);
  assert.deepEqual(order, [
    `launcher-confirm-exit:${watcherDeleted.pid}:true`,
    'launcher-dispose',
  ]);
  assert.deepEqual(autoAttacher.targets, []);

  order.length = 0;
  watcher.create(sessionDisconnected);
  await flushMicrotasks();
  launchers[1].connect(sessionDisconnected.pid, sessionDisconnected.filepath);
  await flushMicrotasks();

  session.emitNative('game.process.disconnected', {
    pid: sessionDisconnected.pid,
  });
  await flushMicrotasks();

  assert.deepEqual(launchers[1].exitConfirmations, [
    { pid: sessionDisconnected.pid, confirmed: false },
  ]);
  assert.deepEqual(order, [
    `launcher-confirm-exit:${sessionDisconnected.pid}:false`,
    'launcher-dispose',
  ]);
  assert.deepEqual(autoAttacher.targets, []);

  order.length = 0;
  watcher.create(attachingDeleted);
  await flushMicrotasks();
  watcher.delete(attachingDeleted);

  assert.deepEqual(launchers[2].exitConfirmations, [
    { pid: attachingDeleted.pid, confirmed: true },
  ]);
  assert.deepEqual(order, [
    `launcher-confirm-exit:${attachingDeleted.pid}:true`,
    'launcher-dispose',
  ]);
  assert.deepEqual(autoAttacher.targets, []);

  await autoAttacher.dispose();
});

test('every detected Steam executable starts an independent exact-PID injection', async () => {
  const watcher = new FakeProcessWatcher();
  const session = new FakeOverlaySession();
  const launchers = [];
  const autoAttacher = new SteamGameAutoAttacher({
    session,
    reshadeConfig: createConfig(),
    watcherFactory: () => watcher,
    launcherFactory: (config) => {
      const launcher = new FakeLauncher(config);
      launchers.push(launcher);
      return launcher;
    },
  });

  autoAttacher.start();
  await flushMicrotasks();
  assert.equal(launchers.length, 0);

  watcher.ready();
  watcher.create(
    processInfo(1001, 'D:\\SteamLibrary\\steamapps\\common\\One\\one.exe'),
  );
  watcher.create(processInfo(1003, 'C:\\Windows\\System32\\notepad.exe'));
  await flushMicrotasks();

  assert.equal(launchers.length, 1);
  assert.deepEqual(launchers[0].target, {
    processName: 'one.exe',
    pid: 1001,
    executablePath: 'D:\\SteamLibrary\\steamapps\\common\\One\\one.exe',
  });
  assert.deepEqual(
    autoAttacher.targets.map(({ pid, phase }) => ({ pid, phase })),
    [{ pid: 1001, phase: 'attaching' }],
  );

  launchers[0].connect(
    1001,
    'D:\\SteamLibrary\\steamapps\\common\\One\\one.exe',
  );
  await flushMicrotasks();
  assert.equal(launchers.length, 1);
  assert.deepEqual(
    autoAttacher.targets.map(({ pid, phase }) => ({ pid, phase })),
    [{ pid: 1001, phase: 'connected' }],
  );

  watcher.create(processInfo(1002, 'E:/Games/SteamApps/common/Two/two.exe'));
  watcher.create(processInfo(1002, 'E:/Games/SteamApps/common/Two/two.exe'));
  await flushMicrotasks();
  assert.equal(launchers.length, 2, 'a live PID is attempted exactly once');
  assert.deepEqual(launchers[1].target, {
    processName: 'two.exe',
    pid: 1002,
    executablePath: 'E:/Games/SteamApps/common/Two/two.exe',
  });
  assert.deepEqual(
    autoAttacher.targets.map(({ pid, phase }) => ({ pid, phase })),
    [
      { pid: 1001, phase: 'connected' },
      { pid: 1002, phase: 'attaching' },
    ],
  );

  launchers[1].connect(1002, 'E:\\Games\\SteamApps\\common\\Two\\two.exe');
  await flushMicrotasks();
  assert.equal(launchers.length, 2);
  assert.deepEqual(
    autoAttacher.targets.map(({ pid, phase }) => ({ pid, phase })),
    [
      { pid: 1001, phase: 'connected' },
      { pid: 1002, phase: 'connected' },
    ],
  );

  watcher.delete(processInfo(1001, ''));
  assert.equal(launchers[0].disposed, true);
  assert.deepEqual(
    autoAttacher.targets.map(({ pid }) => pid),
    [1002],
  );

  session.emitNative('game.process.disconnected', { pid: 1002 });
  await flushMicrotasks();
  assert.equal(launchers[1].disposed, true);
  assert.deepEqual(autoAttacher.targets, []);

  await autoAttacher.dispose();
  assert.equal(watcher.stopped, true);
});

test('launcher, renderer, helpers, and redistributables are all attempted', async () => {
  const watcher = new FakeProcessWatcher();
  const session = new FakeOverlaySession();
  const launchers = [];
  const autoAttacher = new SteamGameAutoAttacher({
    session,
    reshadeConfig: createConfig(),
    watcherFactory: () => watcher,
    launcherFactory: (config) => {
      const launcher = new FakeLauncher(config);
      launchers.push(launcher);
      return launcher;
    },
  });

  autoAttacher.start();
  await flushMicrotasks();
  const processes = [
    processInfo(
      1101,
      'D:\\SteamLibrary\\steamapps\\common\\LORT\\LortGame.exe',
    ),
    processInfo(
      1102,
      'D:\\SteamLibrary\\steamapps\\common\\LORT\\BW\\Binaries\\Win64\\LortGame-Win64-Shipping.exe',
    ),
    processInfo(
      1103,
      'D:\\SteamLibrary\\steamapps\\common\\One\\UnityCrashHandler64.exe',
    ),
    processInfo(
      1104,
      'D:\\SteamLibrary\\steamapps\\common\\Steamworks Shared\\_CommonRedist\\VC_redist.x64.exe',
    ),
  ];
  for (const info of processes) {
    watcher.create(info);
  }
  await flushMicrotasks();

  assert.equal(launchers.length, processes.length);
  assert.deepEqual(
    launchers.map(({ target }) => target),
    processes.map(({ pid, process, filepath }) => ({
      processName: process,
      pid,
      executablePath: filepath,
    })),
  );

  launchers[0].fail(new Error('bootstrap did not initialize graphics'));
  launchers[1].connect(1102, processes[1].filepath);
  await flushMicrotasks();
  assert.deepEqual(
    autoAttacher.targets.slice(0, 2).map(({ pid, phase }) => ({ pid, phase })),
    [
      { pid: 1101, phase: 'failed' },
      { pid: 1102, phase: 'connected' },
    ],
  );

  await autoAttacher.dispose();
});

test('no injection starts when the process watcher cannot start', async (t) => {
  const scenarios = [
    {
      name: 'watcher factory throws',
      watcherFactory: () => {
        throw new Error('watcher construction failed');
      },
      expectedError: 'watcher construction failed',
    },
    {
      name: 'watcher start throws',
      watcherFactory: () => ({
        start() {
          throw new Error('watcher startup failed');
        },
        stop() {
          return Promise.resolve();
        },
      }),
      expectedError: 'watcher startup failed',
    },
  ];

  for (const scenario of scenarios) {
    await t.test(scenario.name, async () => {
      const launchers = [];
      const autoAttacher = new SteamGameAutoAttacher({
        session: new FakeOverlaySession(),
        reshadeConfig: createConfig(),
        watcherFactory: scenario.watcherFactory,
        launcherFactory: (config) => {
          const launcher = new FakeLauncher(config);
          launchers.push(launcher);
          return launcher;
        },
        prearmedPathInjection: true,
      });

      autoAttacher.start();
      await flushMicrotasks();

      assert.equal(autoAttacher.watcherStatus, 'failed');
      assert.equal(autoAttacher.watcherError, scenario.expectedError);
      assert.equal(launchers.length, 0);

      await autoAttacher.dispose();
    });
  }
});

test('no prearmed injection starts before asynchronous watcher readiness', async () => {
  const watcher = new FakeProcessWatcher();
  const launchers = [];
  const autoAttacher = new SteamGameAutoAttacher({
    session: new FakeOverlaySession(),
    reshadeConfig: createConfig(),
    watcherFactory: () => watcher,
    launcherFactory: (config) => {
      const launcher = new FakeLauncher(config);
      launchers.push(launcher);
      return launcher;
    },
    prearmedPathInjection: true,
    preparedLauncherPoolSize: 0,
  });

  autoAttacher.start();
  await flushMicrotasks();
  assert.equal(autoAttacher.watcherStatus, 'starting');
  assert.equal(launchers.length, 0);

  watcher.fail('native observer failed before ready');
  await flushMicrotasks();
  assert.equal(autoAttacher.watcherStatus, 'failed');
  assert.equal(launchers.length, 0);

  await autoAttacher.dispose();
});

test('a failed PID is not retried until deletion proves a new process lifetime', async () => {
  const watcher = new FakeProcessWatcher();
  const session = new FakeOverlaySession();
  const launchers = [];
  const autoAttacher = new SteamGameAutoAttacher({
    session,
    reshadeConfig: createConfig(),
    watcherFactory: () => watcher,
    launcherFactory: (config) => {
      const launcher = new FakeLauncher(config);
      launchers.push(launcher);
      return launcher;
    },
  });
  const info = processInfo(
    2001,
    'D:\\SteamLibrary\\steamapps\\common\\Failed\\failed.exe',
  );

  autoAttacher.start();
  watcher.create(info);
  await flushMicrotasks();
  launchers[0].fail(new Error('injection refused'));
  await flushMicrotasks();
  assert.equal(launchers[0].disposed, true);
  assert.equal(launchers.length, 1);
  assert.equal(autoAttacher.targets[0].phase, 'failed');
  assert.equal(autoAttacher.targets[0].error, 'injection refused');
  assert.equal(autoAttacher.targets[0].diagnostic, null);

  watcher.create(info);
  assert.equal(launchers.length, 1);

  watcher.delete(info);
  assert.deepEqual(autoAttacher.targets, []);
  watcher.create(info);
  await flushMicrotasks();
  assert.equal(launchers.length, 2);
  assert.deepEqual(launchers[1].target, {
    processName: 'failed.exe',
    pid: 2001,
    executablePath: info.filepath,
  });

  await autoAttacher.dispose();
});

test('a late overlay handshake promotes an already attempted PID', async () => {
  const watcher = new FakeProcessWatcher();
  const session = new FakeOverlaySession();
  const launchers = [];
  const autoAttacher = new SteamGameAutoAttacher({
    session,
    reshadeConfig: createConfig(),
    watcherFactory: () => watcher,
    launcherFactory: (config) => {
      const launcher = new FakeLauncher(config);
      launchers.push(launcher);
      return launcher;
    },
  });
  const filepath =
    'D:\\SteamLibrary\\steamapps\\common\\Slow Game\\slow-game.exe';

  autoAttacher.start();
  watcher.create(processInfo(2501, filepath));
  await flushMicrotasks();
  const initializationFailure = createReShadeOperationError({
    stage: 'runtime-initialization',
    code: 'runtime-initialization-timeout',
    retrySafety: 'indeterminate',
    message: 'graphics initialization proof timed out',
    targetLabel: 'process:slow-game.exe:pid:2501',
    pid: 2501,
  });
  launchers[0].fail(initializationFailure);
  await flushMicrotasks();
  assert.equal(autoAttacher.targets[0].phase, 'failed');
  assert.equal(
    autoAttacher.targets[0].diagnostic,
    initializationFailure.diagnostic,
  );

  session.emitNative('game.process', { pid: 2501, path: filepath });
  await flushMicrotasks();
  assert.equal(launchers.length, 1, 'late initialization must not reinject');
  assert.deepEqual(autoAttacher.targets[0], {
    pid: 2501,
    processName: 'slow-game.exe',
    filepath,
    phase: 'connected',
    error: null,
    diagnostic: null,
  });

  await autoAttacher.dispose();
});

test('dispose stops the watcher before launchers and ignores late events', async () => {
  const order = [];
  const watcher = new FakeProcessWatcher(order);
  const session = new FakeOverlaySession();
  const launchers = [];
  const autoAttacher = new SteamGameAutoAttacher({
    session,
    reshadeConfig: createConfig(),
    watcherFactory: () => watcher,
    launcherFactory: (config) => {
      const launcher = new FakeLauncher(config, order);
      launchers.push(launcher);
      return launcher;
    },
  });

  autoAttacher.start();
  watcher.create(
    processInfo(3001, 'D:\\SteamLibrary\\steamapps\\common\\One\\one.exe'),
  );
  await autoAttacher.dispose();

  assert.deepEqual(order, ['watcher-stop', 'launcher-dispose']);
  watcher.create(
    processInfo(3002, 'D:\\SteamLibrary\\steamapps\\common\\Two\\two.exe'),
  );
  assert.equal(launchers.length, 1);
  assert.deepEqual(autoAttacher.targets, []);
});

class FakeProcessWatcher {
  handlers = null;
  stopped = false;

  constructor(order = []) {
    this.order = order;
  }

  start(handlers) {
    this.handlers = handlers;
    handlers.onStatus('starting');
  }

  ready() {
    this.handlers?.onStatus('running');
  }

  fail(error) {
    this.handlers?.onStatus('failed', error);
  }

  create(payload) {
    this.handlers?.onEvent({ type: 'process-creation', payload });
  }

  delete(payload) {
    this.handlers?.onEvent({ type: 'process-deletion', payload });
  }

  stop() {
    this.stopped = true;
    this.order.push('watcher-stop');
    return Promise.resolve();
  }
}

function createFakeChildProcess() {
  const child = new EventEmitter();
  child.stdout = null;
  child.stderr = null;
  child.exitCode = null;
  child.signalCode = null;
  child.connected = true;
  child.disconnect = () => {
    child.connected = false;
  };
  child.kill = () => true;
  return child;
}

class FakeOverlaySession {
  handlers = new Map();

  on(event, handler) {
    let handlers = this.handlers.get(event);
    if (!handlers) {
      handlers = new Set();
      this.handlers.set(event, handlers);
    }
    handlers.add(handler);
    return () => handlers.delete(handler);
  }

  onClose() {
    return () => {};
  }

  whenReady() {
    return Promise.resolve();
  }

  emitNative(event, payload) {
    const typedEvent = {
      'game.process': 'targetConnected',
      'game.process.transport-lost': 'targetTransportLost',
      'game.process.disconnected': 'targetDisconnected',
    }[event];
    assert.ok(typedEvent, `unexpected lifecycle event ${event}`);
    for (const handler of this.handlers.get(typedEvent) ?? []) {
      handler({
        pid: payload.pid,
        executablePath: payload.path ?? 'C:\\Games\\unknown.exe',
      });
    }
  }
}

class FakeLauncher {
  state = 'idle';
  target = null;
  disposed = false;
  connectedPid = null;
  exitConfirmations = [];
  prepareCalls = 0;
  prepared = false;

  constructor(config, order = [], prepareOperation = undefined) {
    this.config = config;
    this.order = order;
    this.prepareOperation = prepareOperation ?? (() => Promise.resolve());
    this.promise = new Promise((resolve, reject) => {
      this.resolve = resolve;
      this.reject = reject;
    });
  }

  prepare() {
    this.prepareCalls += 1;
    return Promise.resolve()
      .then(() => this.prepareOperation())
      .then(() => {
        this.prepared = true;
      });
  }

  attach(session, target) {
    assert.ok(session);
    this.state = 'attaching';
    this.target = target;
    this.removeSessionListener = session.on('targetDisconnected', ({ pid }) => {
      if (pid !== this.connectedPid) {
        return;
      }
      this.state = 'idle';
      this.connectedPid = null;
      this.removeSessionListener?.();
      this.removeSessionListener = undefined;
    });
    return this.promise;
  }

  connect(
    pid,
    selectedPath = `C:\\SteamLibrary\\steamapps\\common\\Game\\game.exe`,
  ) {
    this.state = 'connected';
    this.connectedPid = pid;
    this.resolve({
      pid,
      processName: selectedPath.split(/[\\/]/).at(-1),
      selectedPath,
    });
  }

  fail(error) {
    this.state =
      error instanceof ReShadeOperationError &&
      error.retrySafety === 'definite-safe'
        ? 'idle'
        : 'blocked';
    this.reject(error);
  }

  confirmTargetExited(pid) {
    const confirmed =
      (this.state === 'connected' && this.connectedPid === pid) ||
      (this.state === 'attaching' && this.target?.pid === pid);
    this.exitConfirmations.push({ pid, confirmed });
    this.order.push(`launcher-confirm-exit:${pid}:${confirmed}`);
    if (confirmed) {
      this.state = 'idle';
      this.connectedPid = null;
      this.removeSessionListener?.();
      this.removeSessionListener = undefined;
    }
    return confirmed;
  }

  dispose() {
    this.disposed = true;
    this.state = 'idle';
    this.connectedPid = null;
    this.removeSessionListener?.();
    this.removeSessionListener = undefined;
    this.order.push('launcher-dispose');
  }
}

class EventLauncher extends FakeLauncher {
  handlers = new Set();
  quiescenceCalls = 0;
  onEvent(handler) { this.handlers.add(handler); return () => this.handlers.delete(handler); }
  emit(event) { for (const handler of this.handlers) handler(event); }
  quiesceUnselectedFutureWatcher() {
    this.quiescenceCalls += 1;
    this.dispose();
    return Promise.resolve(true);
  }
}

function createConfig(overrides = {}) {
  return {
    runtimeDirectory: 'C:\\runtime',
    runsRootDirectory: 'C:\\runs',
    injectorPath: 'C:\\runtime\\inject.exe',
    addonManagerPath: 'C:\\runtime\\electron_game_overlay_reshade_manager.exe',
    runtimePath: 'C:\\runtime\\ReShade64.dll',
    buildStampPath: 'C:\\runtime\\ReShade64.build.json',
    packageBuildStampPath:
      'C:\\runtime\\electron_game_overlay_runtime.build.json',
    addonPath: 'C:\\runtime\\electron_game_overlay.addon64',
    configPath: 'C:\\runtime\\ReShade.ini',
    ...overrides,
  };
}

function processInfo(pid, filepath) {
  return {
    process: filepath ? filepath.split(/[\\/]/).at(-1) : '',
    pid,
    filepath,
    user: 'tester',
  };
}

function createDeferred() {
  let resolve;
  let reject;
  const promise = new Promise((resolvePromise, rejectPromise) => {
    resolve = resolvePromise;
    reject = rejectPromise;
  });
  return { promise, resolve, reject };
}

async function flushMicrotasks() {
  for (let index = 0; index < 10; index += 1) {
    await Promise.resolve();
  }
}
