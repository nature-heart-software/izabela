#include <Windows.h>
#include <CommCtrl.h>

#include <electron_overlay_transport.h>
#include <imgui.h>
#include <reshade.hpp>
#include "ego_cooperative_registry.hpp"
#include "ego_cooperative_input.hpp"
#include "ego_cooperative_frame_policy.hpp"
#include "ego_render_readback_diagnostic.hpp"
#include "ego_initial_texture_upload.hpp"
#include "ego_preloaded_addon.hpp"

#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <iterator>
#include <limits>
#include <filesystem>
#include <memory>
#include <mutex>
#include <new>
#include <optional>
#include <string>
#include <string_view>
#include <type_traits>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

#pragma comment(lib, "Comctl32.lib")

extern "C" __declspec(dllexport) DWORD WINAPI ElectronGameOverlayInitializeMember(void *request);
extern "C" __declspec(dllexport) DWORD WINAPI ElectronGameOverlayActivatePreloadedMemberV1(void *request);
extern "C" __declspec(dllexport) void AddonUninit(HMODULE module, HMODULE reshade_module);
extern "C" { __declspec(dllexport) extern const char *NAME; }
extern "C" { __declspec(dllexport) extern volatile LONG ElectronGameOverlayCooperativeReadyV1; }
extern "C" { __declspec(dllexport) extern volatile LONG ElectronGameOverlayCooperativeAdapterReadyV1; }

namespace
{
using namespace reshade::api;

// The add-on is compiled against public ReShade add-on API 18. The repository
// runtime carries a private, capability-negotiated input event, but that
// extension does not change any public effect_runtime vtable. Public hosts are
// accepted by capability: registration and the exact ImGui function table must
// both succeed. ReShade's exported product version is deliberately not pinned.
constexpr std::uint32_t public_reshade_api_version = 18;
constexpr std::uint32_t final_transport_drain_timeout_ms = 250;
static_assert(
    final_transport_drain_timeout_ms <= EGO_TRANSPORT_DRAIN_MAX_TIMEOUT_MS);

HMODULE g_reshade_host_module = nullptr;
HMODULE g_addon_module = nullptr;
bool g_has_private_input_observer = false;
ego::cooperative::registry g_cooperative;
ego::render_readback_diagnostic::probe g_render_readback;
std::atomic<bool> g_module_pinned = false;
std::mutex g_member_initialization_mutex;
bool g_cooperative_dispatcher = false;
bool g_public_registered = false;
bool g_dispatcher_events_registered = false;
#if defined(EGO_EXPERIMENTAL_PRIVATE_MEMORY_ROUTE)
std::atomic<bool> g_memory_dispatcher = false;
#endif
ego::preloaded_addon::filename_identity g_preload_identity;
std::wstring g_preload_bound_directory;
ego::cooperative::presentation_driver g_adapter_input_driver;
ego::cooperative::logical_control g_logical_control;
std::atomic<bool> g_adapter_window_ready = false;
DWORD initialize_cooperative_member(void *opaque_request, bool explicit_initializer,
    bool preloaded_activation = false);
DWORD initialize_automatic_member() noexcept;
bool is_preloaded_member() noexcept
{
    return g_preload_identity.kind == ego::preloaded_addon::preload_filename_kind::valid;
}

bool can_drive_dormant_adapter() noexcept
{
#if defined(EGO_EXPERIMENTAL_PRIVATE_MEMORY_ROUTE)
    if (g_memory_dispatcher.load(std::memory_order_acquire))
        return g_cooperative_dispatcher;
#endif
    return is_preloaded_member() && g_cooperative_dispatcher;
}
thread_local bool g_cooperative_owned_record = false;
thread_local ego::cooperative::window_key g_cooperative_record_owner;
thread_local ego::cooperative::window_key g_cooperative_record_focus;
thread_local bool g_cooperative_raw_point_valid = false;
thread_local std::int32_t g_cooperative_raw_x = 0, g_cooperative_raw_y = 0;

constexpr std::size_t input_queue_capacity = 4096;
static_assert((input_queue_capacity & (input_queue_capacity - 1)) == 0);
static_assert(std::atomic<std::uint64_t>::is_always_lock_free);
static_assert(std::atomic<bool>::is_always_lock_free);
static_assert(std::is_trivially_copyable_v<input_message>);

struct queued_input_message
{
    std::uint64_t generation = 0;
    input_message message = {};
    std::uint32_t pointer_id = 0;
    std::uint32_t pointer_type = PT_POINTER;
    std::uint32_t pointer_key_states = 0;
    bool pointer_primary = false;
    bool pointer_metadata_valid = false;
    bool ownership_valid = false;
    ego::cooperative::window_key owner;
    ego::cooperative::window_key focus;
    std::int32_t canonical_x = 0, canonical_y = 0;
    bool canonical_point_valid = false;
};
static_assert(std::is_trivially_copyable_v<queued_input_message>);

/// Bounded Vyukov queue. Producers are the arbitrary threads on which ReShade
/// observes input; the render callback is the only consumer (guarded below).
/// Callback publication performs no allocation, IPC, logging, or mutex wait.
template <std::size_t Capacity>
class bounded_input_queue
{
    static_assert((Capacity & (Capacity - 1)) == 0);

    struct slot
    {
        std::atomic<std::uint64_t> sequence = 0;
        queued_input_message message = {};
    };

public:
    bounded_input_queue() noexcept
    {
        for (std::size_t index = 0; index < Capacity; ++index)
            slots_[index].sequence.store(
                static_cast<std::uint64_t>(index),
                std::memory_order_relaxed);
    }

    bounded_input_queue(const bounded_input_queue &) = delete;
    bounded_input_queue &operator=(const bounded_input_queue &) = delete;

    bool try_push(const queued_input_message &message) noexcept
    {
        std::uint64_t position = enqueue_position_.load(std::memory_order_relaxed);
        slot *target = nullptr;

        for (;;)
        {
            target = &slots_[position & (Capacity - 1)];
            const std::uint64_t sequence =
                target->sequence.load(std::memory_order_acquire);
            const std::int64_t difference =
                static_cast<std::int64_t>(sequence - position);
            if (difference == 0)
            {
                if (enqueue_position_.compare_exchange_weak(
                        position,
                        position + 1,
                        std::memory_order_relaxed,
                        std::memory_order_relaxed))
                    break;
            }
            else if (difference < 0)
            {
                return false;
            }
            else
            {
                position = enqueue_position_.load(std::memory_order_relaxed);
            }
        }

        target->message = message;
        target->sequence.store(position + 1, std::memory_order_release);
        return true;
    }

    bool try_pop(queued_input_message &message) noexcept
    {
        slot &source = slots_[dequeue_position_ & (Capacity - 1)];
        const std::uint64_t sequence =
            source.sequence.load(std::memory_order_acquire);
        const std::int64_t difference =
            static_cast<std::int64_t>(sequence - (dequeue_position_ + 1));
        if (difference != 0)
            return false;

        message = source.message;
        source.sequence.store(
            dequeue_position_ + Capacity,
            std::memory_order_release);
        ++dequeue_position_;
        return true;
    }

private:
    std::array<slot, Capacity> slots_ = {};
    std::atomic<std::uint64_t> enqueue_position_ = 0;
    std::uint64_t dequeue_position_ = 0;
};

bounded_input_queue<input_queue_capacity> g_source_input_queue;
std::atomic<bool> g_source_input_overflow = false;
std::atomic<bool> g_source_final_reset_pending = false;
constexpr std::uint64_t runtime_diagnostic_failure_interval_ms = 7500;

struct ordered_pointer_state
{
    std::uintptr_t target_window = 0;
    std::uint32_t pointer_id = 0;
    bool primary_down = false;
};


struct ordered_raw_input_state
{
    std::uintptr_t target_window = 0;
    std::array<bool, 256> keys_down = {};
    std::uint32_t mouse_buttons = 0;
    std::int32_t client_x = 0;
    std::int32_t client_y = 0;
    std::int32_t last_os_x = 0;
    std::int32_t last_os_y = 0;
    bool has_client_point = false;
    bool has_last_os_point = false;
};


enum class input_phase : std::uint8_t
{
    disabled,
    arming,
    enabled,
    disarming,
};
struct swapchain_data;

// Each published callback context owns its transport, frame resources and
// input state. Contexts stay alive for the lifetime of the pinned module.
struct participant_state
{
    std::atomic<std::uint64_t> participant_id = 0;
    std::atomic<std::uint64_t> input_source_cutoff = 0;
    std::string private_run_directory;
    bool private_route_present = false;
#if defined(EGO_EXPERIMENTAL_PRIVATE_MEMORY_ROUTE)
    std::optional<ego_private_route_v2> private_memory_route;
#endif
    std::uint64_t cooperative_focus_revision = 0;
    std::vector<ego::cooperative::window_key> producer_registration_order;
    ego::cooperative::logical_epoch_tracker logical_session_epoch;
    ego::cooperative::presentation_driver member_input_driver;
    std::uint64_t logical_fps_publication_tick = 0;
    bounded_input_queue<input_queue_capacity> input_queue;
    std::array<queued_input_message, input_queue_capacity> input_batch = {};
    std::atomic_flag input_consumer = ATOMIC_FLAG_INIT;
    std::atomic<std::uint64_t> input_generation = 1;
    std::atomic<std::uint64_t> dropped_input_messages = 0;
    std::atomic<bool> input_recovery_pending = false;
    std::atomic_flag overflow_logged = ATOMIC_FLAG_INIT;
    std::atomic_flag order_fault_logged = ATOMIC_FLAG_INIT;
    std::atomic_flag raw_rejected_logged = ATOMIC_FLAG_INIT;
    std::atomic_flag route_error_logged = ATOMIC_FLAG_INIT;
    std::atomic_flag target_surface_logged = ATOMIC_FLAG_INIT;
    std::atomic_flag fps_logged = ATOMIC_FLAG_INIT;
    std::atomic_flag diagnostic_publication_logged = ATOMIC_FLAG_INIT;
    std::array<std::atomic<std::uint64_t>, 9>
        runtime_diagnostic_failure_publication_ticks = {};
    std::atomic<std::uint64_t> target_surface_revision_sequence = 0;
    std::uint64_t last_input_sequence = 0;
    bool has_last_input_sequence = false;
    std::atomic<bool> pointer_route_reset_pending = false;
    ordered_pointer_state pointer_state = {};
    ordered_raw_input_state raw_input_state = {};
    input_phase cooperative_member_phase = input_phase::disabled;
    std::mutex swapchain_states_mutex;
    std::unordered_map<std::uint64_t, std::unique_ptr<swapchain_data>> swapchain_states;
    std::mutex transport_lifecycle_mutex;
    std::mutex transport_mutex;
    ego_transport *transport = nullptr;
    std::uint32_t transport_references = 0;
    std::atomic<std::uint64_t> swapchain_ownership_token_sequence = 0;
    std::atomic<std::uint64_t> primary_swapchain_token = 0;

    ~participant_state();
};

thread_local participant_state *g_callback_member = nullptr;
participant_state &member() noexcept;

class participant_callback_scope
{
public:
    explicit participant_callback_scope(void *context) noexcept :
        previous_(std::exchange(g_callback_member, static_cast<participant_state *>(context))) {}
    ~participant_callback_scope() { g_callback_member = previous_; }
    participant_callback_scope(const participant_callback_scope &) = delete;
    participant_callback_scope &operator=(const participant_callback_scope &) = delete;

private:
    participant_state *previous_;
};

bool owns_dispatcher_surface() noexcept
{
    return g_cooperative_dispatcher && g_callback_member == nullptr;
}

bool is_pointer_mouse_message(std::uint32_t message) noexcept
{
    switch (message)
    {
    case WM_POINTERUPDATE:
    case WM_POINTERDOWN:
    case WM_POINTERUP:
    case WM_POINTERENTER:
    case WM_POINTERLEAVE:
    case WM_POINTERWHEEL:
    case WM_POINTERHWHEEL:
        return true;
    default:
        return false;
    }
}

std::int64_t encode_client_point(std::int32_t x, std::int32_t y) noexcept
{
    const std::uint32_t packed =
        static_cast<std::uint16_t>(x) |
        (static_cast<std::uint32_t>(static_cast<std::uint16_t>(y)) << 16U);
    return static_cast<std::int64_t>(packed);
}

void capture_pointer_metadata(queued_input_message &queued) noexcept
{
    if (queued.message.source != input_message_source::window_message ||
        !is_pointer_mouse_message(queued.message.message))
    {
        return;
    }

    const std::uint32_t pointer_id = GET_POINTERID_WPARAM(
        static_cast<WPARAM>(queued.message.wparam));
    POINTER_INFO pointer_info = {};
    if (GetPointerInfo(pointer_id, &pointer_info) == FALSE)
    {
        // A pointer message can be synchronously forwarded or replayed after
        // its system history has expired. Preserve an explicitly primary
        // first-button mouse-style sequence from the immutable message flags;
        // real touch/pen input still has authoritative GetPointerInfo metadata
        // and is never reclassified by this fallback.
        const WPARAM pointer_wparam =
            static_cast<WPARAM>(queued.message.wparam);
        if (!IS_POINTER_PRIMARY_WPARAM(pointer_wparam))
            return;
        queued.pointer_id = pointer_id;
        queued.pointer_type = static_cast<std::uint32_t>(PT_MOUSE);
        queued.pointer_key_states =
            IS_POINTER_FIRSTBUTTON_WPARAM(pointer_wparam)
            ? MK_LBUTTON
            : 0;
        queued.pointer_primary = true;
        queued.pointer_metadata_valid = true;
        return;
    }

    queued.pointer_id = pointer_id;
    queued.pointer_type = static_cast<std::uint32_t>(pointer_info.pointerType);
    queued.pointer_key_states = pointer_info.dwKeyStates;
    queued.pointer_primary =
        (pointer_info.pointerFlags & POINTER_FLAG_PRIMARY) != 0;
    queued.pointer_metadata_valid = true;
}

void reset_ordered_pointer_state() noexcept
{
    member().pointer_state = {};
}

void reset_ordered_raw_input_state() noexcept
{
    member().raw_input_state = {};
}

bool translate_pointer_mouse_message(
    const queued_input_message &queued,
    input_message &message) noexcept
{
    if ((message.flags & static_cast<std::uint32_t>(
                             input_message_flags::no_legacy)) != 0)
    {
        // A NOLEGACY raw mouse stream is authoritative for this target. Some
        // games also enable mouse-in-pointer promotion, but projecting that
        // second representation would duplicate every click.
        return false;
    }

    if (!is_pointer_mouse_message(message.message))
        return true;
    if (message.message == WM_POINTERWHEEL || message.message == WM_POINTERHWHEEL)
    {
        // Pointer wheel coordinates are already screen-space, just like legacy
        // wheel. Do not use PRIMARY/FIRSTBUTTON flags: that word holds the delta.
        message.message = message.message == WM_POINTERWHEEL ? WM_MOUSEWHEEL : WM_MOUSEHWHEEL;
        message.wparam = (static_cast<std::uint32_t>(message.wparam) & 0xffff0000U) |
            (queued.pointer_key_states & (MK_CONTROL | MK_SHIFT | MK_LBUTTON | MK_RBUTTON | MK_MBUTTON));
        return true;
    }
    const bool is_mouse =
        queued.pointer_type == static_cast<std::uint32_t>(PT_MOUSE);
    const bool is_primary_contact =
        (queued.pointer_type == static_cast<std::uint32_t>(PT_TOUCH) ||
         queued.pointer_type == static_cast<std::uint32_t>(PT_PEN)) &&
        queued.pointer_primary;
    if (!queued.pointer_metadata_valid ||
        (!is_mouse && !is_primary_contact))
    {
        return false;
    }

    const bool client_point_valid =
        (message.flags & static_cast<std::uint32_t>(
                             input_message_flags::client_point_valid)) != 0;
    const WPARAM pointer_wparam = static_cast<WPARAM>(message.wparam);
    const std::uint64_t mouse_modifiers = queued.pointer_key_states &
        static_cast<std::uint32_t>(MK_CONTROL | MK_SHIFT);
    const std::uintptr_t target_window =
        reinterpret_cast<std::uintptr_t>(message.target_window);

    switch (message.message)
    {
    case WM_POINTERUPDATE:
        if (!client_point_valid)
            return false;
        message.message = WM_MOUSEMOVE;
        message.wparam = mouse_modifiers;
        if (member().pointer_state.primary_down &&
            member().pointer_state.pointer_id == queued.pointer_id &&
            member().pointer_state.target_window == target_window)
        {
            message.wparam |= MK_LBUTTON;
        }
        message.lparam = encode_client_point(message.client_x, message.client_y);
        return true;

    case WM_POINTERDOWN:
        if (!client_point_valid ||
            (is_mouse &&
             !IS_POINTER_FIRSTBUTTON_WPARAM(pointer_wparam)))
        {
            return false;
        }
        member().pointer_state = {
            target_window,
            queued.pointer_id,
            true,
        };
        message.message = WM_LBUTTONDOWN;
        message.wparam = mouse_modifiers | MK_LBUTTON;
        message.lparam = encode_client_point(message.client_x, message.client_y);
        return true;

    case WM_POINTERUP:
        if (!client_point_valid ||
            !member().pointer_state.primary_down ||
            member().pointer_state.pointer_id != queued.pointer_id ||
            member().pointer_state.target_window != target_window)
        {
            return false;
        }
        reset_ordered_pointer_state();
        message.message = WM_LBUTTONUP;
        message.wparam = mouse_modifiers;
        message.lparam = encode_client_point(message.client_x, message.client_y);
        return true;

    default:
        // Enter/leave records are suppressed for the game but
        // are not part of the production Electron route. Non-client pointer
        // activation is deliberately left outside the ReShade patch entirely.
        return false;
    }
}

void queue_cooperative_input(void *context, const void *record, std::uint32_t bytes) noexcept
{
    const participant_callback_scope scope(context);
    // Read the private generation before the cutoff. A reset publishes its
    // cutoff before advancing this generation, so an in-flight receiver can
    // never stamp an old physical record with a replacement session's epoch.
    const auto receiver_generation = member().input_generation.load(std::memory_order_acquire);
    if (record == nullptr || bytes < sizeof(ego::cooperative::input_record_v1))
        return;
    const auto &source = *static_cast<const ego::cooperative::input_record_v1 *>(record);
    if (source.struct_size < sizeof(source) || source.struct_size > bytes || source.version != 1 || source.text_length > 4 ||
        source.target_window > UINTPTR_MAX || source.source_window > UINTPTR_MAX || source.device_handle > UINTPTR_MAX)
        return;
    if (source.sequence <= member().input_source_cutoff.load(std::memory_order_acquire))
        return;
    queued_input_message queued = {};
    queued.generation = receiver_generation;
    auto &message = queued.message;
    message.source = static_cast<input_message_source>(source.source);
    message.device_type = static_cast<input_device_type>(source.device_type);
    message.sequence = source.sequence;
    message.target_window = reinterpret_cast<void *>(static_cast<std::uintptr_t>(source.target_window));
    message.source_window = reinterpret_cast<void *>(static_cast<std::uintptr_t>(source.source_window));
    message.device_handle = static_cast<std::uintptr_t>(source.device_handle);
    message.wparam = source.wparam; message.lparam = source.lparam;
    message.flags = source.flags; message.message = source.message; message.time = source.time;
    message.client_x = source.client_x; message.client_y = source.client_y;
    if (message.device_type == input_device_type::mouse)
        message.mouse = {source.mouse_flags, source.mouse_button_flags, source.mouse_button_data,
            source.mouse_reserved, source.mouse_raw_buttons, source.mouse_last_x, source.mouse_last_y, source.mouse_extra_information};
    else
        message.keyboard = {source.keyboard_make_code, source.keyboard_flags, source.keyboard_virtual_key,
            source.keyboard_reserved, source.keyboard_message, source.keyboard_extra_information};
    std::copy(std::begin(source.text), std::end(source.text), std::begin(message.text));
    message.text_length = static_cast<std::uint8_t>(source.text_length);
    queued.pointer_id = source.pointer_id; queued.pointer_type = source.pointer_type;
    queued.pointer_key_states = source.pointer_key_states;
    queued.pointer_primary = source.pointer_primary != 0;
    queued.pointer_metadata_valid = source.pointer_metadata_valid != 0;
    queued.ownership_valid = source.ownership_valid != 0;
    queued.owner = {source.owner_participant, source.owner_window, 0, source.owner_incarnation};
    queued.focus = {source.focus_participant, source.focus_window, 0, source.focus_incarnation};
    queued.canonical_x = source.canonical_x; queued.canonical_y = source.canonical_y;
    queued.canonical_point_valid = source.canonical_point_valid != 0;
    if (member().input_queue.try_push(queued))
        return;

    member().dropped_input_messages.fetch_add(1, std::memory_order_relaxed);
    member().input_recovery_pending.store(true, std::memory_order_release);
}

ego::cooperative::input_record_v1 freeze_source_input(const queued_input_message &queued) noexcept
{
    const auto &message = queued.message;
    ego::cooperative::input_record_v1 record;
    record.source = static_cast<std::uint32_t>(message.source);
    record.device_type = static_cast<std::uint32_t>(message.device_type);
    record.sequence = message.sequence;
    record.target_window = reinterpret_cast<std::uintptr_t>(message.target_window);
    record.source_window = reinterpret_cast<std::uintptr_t>(message.source_window);
    record.device_handle = message.device_handle;
    record.wparam = message.wparam; record.lparam = message.lparam;
    record.flags = message.flags; record.message = message.message; record.time = message.time;
    record.client_x = message.client_x; record.client_y = message.client_y;
    if (message.device_type == input_device_type::mouse)
    {
        record.mouse_flags = message.mouse.flags; record.mouse_button_flags = message.mouse.button_flags;
        record.mouse_button_data = message.mouse.button_data; record.mouse_reserved = message.mouse.reserved;
        record.mouse_raw_buttons = message.mouse.raw_buttons; record.mouse_last_x = message.mouse.last_x;
        record.mouse_last_y = message.mouse.last_y; record.mouse_extra_information = message.mouse.extra_information;
    }
    else
    {
        record.keyboard_make_code = message.keyboard.make_code; record.keyboard_flags = message.keyboard.flags;
        record.keyboard_virtual_key = message.keyboard.virtual_key; record.keyboard_reserved = message.keyboard.reserved;
        record.keyboard_message = message.keyboard.message; record.keyboard_extra_information = message.keyboard.extra_information;
    }
    std::copy(std::begin(message.text), std::end(message.text), std::begin(record.text));
    record.text_length = message.text_length;
    record.pointer_id = queued.pointer_id; record.pointer_type = queued.pointer_type;
    record.pointer_key_states = queued.pointer_key_states;
    record.pointer_primary = queued.pointer_primary ? 1U : 0U;
    record.pointer_metadata_valid = queued.pointer_metadata_valid ? 1U : 0U;
    return record;
}

void on_input_message(const input_message &message) noexcept
{
    g_cooperative.observe_source_sequence(message.sequence);
    queued_input_message queued = {};
    queued.message = message;
    capture_pointer_metadata(queued);
    if (!g_source_input_queue.try_push(queued))
        g_source_input_overflow.store(true, std::memory_order_release);
}

input_phase g_cooperative_adapter_phase = input_phase::disabled;

constexpr std::size_t official_hook_owner_capacity = 32;
constexpr std::size_t official_thread_hook_capacity = 16;
constexpr std::uint32_t invalid_official_hook_slot =
    std::numeric_limits<std::uint32_t>::max();

struct official_hook_owner
{
    // 'root_window' is the publication field. The hook callback acquires it
    // before reading the remaining immutable owner identity.
    std::atomic<std::uintptr_t> root_window = 0;
    std::atomic<std::uintptr_t> route_window = 0;
    std::atomic<std::uint32_t> thread_id = 0;
    std::atomic<std::uint64_t> primary_token = 0;
    std::atomic<input_phase> phase = input_phase::disabled;
    std::atomic<bool> hook_ready = false;
    std::atomic<bool> subclass_ready = false;
    std::atomic<std::int32_t> cursor_code = -1;
    // The following cursor bookkeeping is touched only on the window thread.
    HCURSOR saved_cursor = nullptr;
    bool cursor_owned = false;
    int cursor_show_adjustment = 0;
    std::uint32_t references = 0;
    std::uint32_t thread_hook_slot = invalid_official_hook_slot;
    std::atomic<DWORD> install_error = ERROR_SUCCESS;
    // Setup runs on the owning window thread. Its generation and completion
    // are protected separately from the hook registry; no callback takes the
    // registry mutex or waits for the render thread.
    std::mutex setup_mutex;
    std::atomic<std::uintptr_t> setup_cookie = 0;
    std::uint64_t setup_deadline = 0;
    std::uint64_t setup_next_retry = 0;
    bool setup_pending = false;
    bool setup_deadline_reported = false;
    bool setup_terminal = false;
};

struct official_thread_hook
{
    DWORD thread_id = 0;
    HHOOK hook = nullptr;
    std::uint32_t owner_references = 0;
};

std::mutex g_official_hook_mutex;
std::array<official_hook_owner, official_hook_owner_capacity>
    g_official_hook_owners = {};
std::array<official_thread_hook, official_thread_hook_capacity>
    g_official_thread_hooks = {};
std::atomic<std::uint64_t> g_official_hook_token_sequence = 0;
std::atomic<std::uintptr_t> g_official_setup_cookie_sequence = 0;
std::atomic<std::uint64_t> g_official_input_sequence = 0;
std::atomic<std::uint32_t> g_official_pointer_message_mask = 0;
std::atomic<std::uint32_t> g_official_hook_callbacks = 0;
std::atomic<bool> g_official_hooks_shutting_down = false;
std::atomic<bool> g_official_subclass_teardown_failed = false;
std::atomic<UINT> g_official_control_message = 0;
std::atomic_flag g_official_hook_error_logged = ATOMIC_FLAG_INIT;
std::atomic_flag g_official_pointer_sequence_logged = ATOMIC_FLAG_INIT;
std::atomic_flag g_official_hook_shutdown_timeout_logged = ATOMIC_FLAG_INIT;
constexpr std::uint64_t official_setup_timeout_ms = 5000;
constexpr std::uint64_t official_setup_retry_ms = 250;
bool service_official_subclass_setup(MSG &message) noexcept;

const wchar_t *official_owner_property_name()
{
    static const std::wstring name = L"ElectronGameOverlay.WindowOwner." +
        std::to_wstring(reinterpret_cast<std::uintptr_t>(&g_official_hook_owners));
    return name.c_str();
}

bool official_owner_window_matches(const official_hook_owner &owner, HWND window) noexcept
{
    const auto cookie = owner.setup_cookie.load(std::memory_order_acquire);
    DWORD process_id = 0;
    const DWORD thread_id = GetWindowThreadProcessId(window, &process_id);
    return cookie != 0 && window != nullptr && process_id == GetCurrentProcessId() &&
        thread_id == owner.thread_id.load(std::memory_order_acquire) &&
        reinterpret_cast<std::uintptr_t>(GetPropW(window, official_owner_property_name())) == cookie;
}

void remove_official_owner_property(const official_hook_owner &owner, HWND window) noexcept
{
    const auto cookie = owner.setup_cookie.load(std::memory_order_acquire);
    if (window != nullptr && cookie != 0 &&
        reinterpret_cast<std::uintptr_t>(GetPropW(window, official_owner_property_name())) == cookie)
        RemovePropW(window, official_owner_property_name());
}

struct official_hook_callback_release
{
    ~official_hook_callback_release()
    {
        g_official_hook_callbacks.fetch_sub(1, std::memory_order_release);
    }
};

bool is_official_keyboard_message(UINT message) noexcept
{
    return message >= WM_KEYFIRST && message <= WM_UNICHAR;
}

bool is_official_mouse_message(UINT message) noexcept
{
    return message >= WM_MOUSEFIRST && message <= WM_MOUSELAST;
}

bool is_official_pointer_message(UINT message) noexcept
{
    switch (message)
    {
    case WM_POINTERUPDATE:
    case WM_POINTERDOWN:
    case WM_POINTERUP:
    case WM_POINTERENTER:
    case WM_POINTERLEAVE:
    case WM_POINTERWHEEL:
    case WM_POINTERHWHEEL:
        return true;
    default:
        return false;
    }
}

bool is_official_overlay_input_message(UINT message) noexcept
{
    return message == WM_INPUT ||
        is_official_keyboard_message(message) ||
        is_official_mouse_message(message) ||
        is_official_pointer_message(message);
}

official_hook_owner *find_official_hook_owner(
    DWORD thread_id,
    HWND message_window) noexcept
{
    if (message_window == nullptr)
        return nullptr;

    HWND const message_root = [&]() {
        HWND const root = GetAncestor(message_window, GA_ROOT);
        return root != nullptr ? root : message_window;
    }();
    HWND const foreground = GetForegroundWindow();
    HWND const foreground_root = foreground != nullptr
        ? ([&]() {
              HWND const root = GetAncestor(foreground, GA_ROOT);
              return root != nullptr ? root : foreground;
          })()
        : nullptr;
    if (foreground_root == nullptr || foreground_root != message_root)
        return nullptr;

    for (official_hook_owner &owner : g_official_hook_owners)
    {
        const auto owner_root = reinterpret_cast<HWND>(
            owner.root_window.load(std::memory_order_acquire));
        if (owner_root == nullptr ||
            owner_root != message_root ||
            owner.thread_id.load(std::memory_order_relaxed) != thread_id ||
            !owner.hook_ready.load(std::memory_order_acquire) ||
            owner.phase.load(std::memory_order_acquire) == input_phase::disabled)
        {
            continue;
        }
        return &owner;
    }
    return nullptr;
}

void set_official_message_position(
    input_message &message,
    const MSG &details,
    HWND route_window) noexcept
{
    POINT client_point = details.pt;
    if (route_window != nullptr &&
        ScreenToClient(route_window, &client_point) != FALSE)
    {
        message.client_x = client_point.x;
        message.client_y = client_point.y;
        message.flags |= static_cast<std::uint32_t>(
            input_message_flags::client_point_valid);
    }
}

void mark_official_pointer_message(UINT message) noexcept
{
    switch (message)
    {
    case WM_POINTERUPDATE:
        g_official_pointer_message_mask.fetch_or(1U, std::memory_order_relaxed);
        break;
    case WM_POINTERDOWN:
        g_official_pointer_message_mask.fetch_or(2U, std::memory_order_relaxed);
        break;
    case WM_POINTERUP:
        g_official_pointer_message_mask.fetch_or(4U, std::memory_order_relaxed);
        break;
    default:
        break;
    }
}

constexpr std::uint32_t official_raw_no_legacy_keyboard = 1U << 0U;
constexpr std::uint32_t official_raw_no_legacy_mouse = 1U << 1U;

std::uint32_t official_raw_registration_flags(HWND source_window) noexcept
{
    struct registration_cache
    {
        HWND source_window = nullptr;
        HWND focus_window = nullptr;
        HWND foreground_window = nullptr;
        ULONGLONG sampled_at = 0;
        std::uint32_t flags = 0;
    };
    thread_local registration_cache cache = {};

    const ULONGLONG now = GetTickCount64();
    const HWND focus_window = GetFocus();
    const HWND foreground_window = GetForegroundWindow();
    if (cache.source_window == source_window &&
        cache.focus_window == focus_window &&
        cache.foreground_window == foreground_window &&
        now - cache.sampled_at < 1000)
    {
        return cache.flags;
    }

    cache.source_window = source_window;
    cache.focus_window = focus_window;
    cache.foreground_window = foreground_window;
    cache.sampled_at = now;
    cache.flags = 0;
    if (source_window == nullptr)
        return 0;

    std::array<RAWINPUTDEVICE, 64> devices = {};
    UINT count = static_cast<UINT>(devices.size());
    const UINT copied = GetRegisteredRawInputDevices(
        devices.data(),
        &count,
        sizeof(RAWINPUTDEVICE));
    if (copied == UINT_MAX || copied > devices.size())
        return 0;

    for (UINT index = 0; index < copied; ++index)
    {
        const RAWINPUTDEVICE &device = devices[index];
        if (device.usUsagePage != 0x01 ||
            (device.dwFlags & RIDEV_EXMODEMASK) != RIDEV_NOLEGACY)
        {
            continue;
        }
        if (device.hwndTarget != source_window)
        {
            if (device.hwndTarget != nullptr)
                continue;

            DWORD source_process = 0;
            if (GetWindowThreadProcessId(source_window, &source_process) !=
                    GetCurrentThreadId() ||
                source_process != GetCurrentProcessId() ||
                focus_window != source_window)
            {
                continue;
            }

            const HWND foreground_ancestor = foreground_window != nullptr
                ? GetAncestor(foreground_window, GA_ROOT)
                : nullptr;
            const HWND foreground_root = foreground_window != nullptr
                ? (foreground_ancestor != nullptr
                       ? foreground_ancestor
                       : foreground_window)
                : nullptr;
            const HWND source_ancestor = GetAncestor(source_window, GA_ROOT);
            const HWND source_root = source_ancestor != nullptr
                ? source_ancestor
                : source_window;
            if (foreground_root == nullptr || foreground_root != source_root)
                continue;
        }
        if (device.usUsage == 0x06)
            cache.flags |= official_raw_no_legacy_keyboard;
        else if (device.usUsage == 0x02)
            cache.flags |= official_raw_no_legacy_mouse;
    }
    return cache.flags;
}

void capture_official_raw_keyboard_text(
    input_message &message,
    const RAWKEYBOARD &keyboard,
    HWND source_window) noexcept
{
    struct ordered_keyboard_state
    {
        HWND source_window = nullptr;
        std::array<BYTE, 256> keys = {};
    };
    thread_local ordered_keyboard_state state = {};

    if (state.source_window != source_window)
    {
        state = {};
        state.source_window = source_window;
        static_cast<void>(GetKeyboardState(state.keys.data()));
    }

    const unsigned int virtual_key = keyboard.VKey;
    if (virtual_key == 0 || virtual_key >= state.keys.size())
        return;

    const bool down = (keyboard.Flags & RI_KEY_BREAK) == 0;
    state.keys[virtual_key] = down ? 0x80 : 0;
    if (!down)
        return;

    WCHAR text[5] = {};
    const int translated = ToUnicodeEx(
        virtual_key,
        keyboard.MakeCode,
        state.keys.data(),
        text,
        4,
        0x2,
        GetKeyboardLayout(0));
    if (translated == 0)
        return;

    const unsigned int text_length = static_cast<unsigned int>(
        std::min(translated < 0 ? -translated : translated, 4));
    message.text_length = static_cast<std::uint8_t>(text_length);
    for (unsigned int index = 0; index < text_length; ++index)
        message.text[index] = static_cast<std::uint16_t>(text[index]);
    if (translated < 0)
    {
        message.flags |= static_cast<std::uint32_t>(
            input_message_flags::dead_key);
    }
}

void observe_official_window_message(
    const MSG &details,
    HWND route_window) noexcept
{
    input_message message = {};
    message.source = input_message_source::window_message;
    message.device_type =
        is_official_mouse_message(details.message) ||
            is_official_pointer_message(details.message)
        ? input_device_type::mouse
        : input_device_type::keyboard;
    message.sequence =
        g_official_input_sequence.fetch_add(1, std::memory_order_relaxed) + 1;
    message.target_window = route_window;
    message.source_window = details.hwnd;
    message.wparam = static_cast<std::uint64_t>(details.wParam);
    message.lparam = static_cast<std::int64_t>(details.lParam);
    message.flags =
        static_cast<std::uint32_t>(input_message_flags::foreground);
    if (is_official_pointer_message(details.message) &&
        (official_raw_registration_flags(details.hwnd) &
         official_raw_no_legacy_mouse) != 0)
    {
        message.flags |= static_cast<std::uint32_t>(
            input_message_flags::no_legacy);
    }
    message.message = details.message;
    message.time = details.time;
    set_official_message_position(message, details, route_window);
    on_input_message(message);
    mark_official_pointer_message(details.message);
}

void observe_official_raw_input(
    const MSG &details,
    HWND route_window) noexcept
{
    RAWINPUT raw = {};
    UINT raw_size = sizeof(raw);
    const UINT copied = GetRawInputData(
        reinterpret_cast<HRAWINPUT>(details.lParam),
        RID_INPUT,
        &raw,
        &raw_size,
        sizeof(RAWINPUTHEADER));
    if (copied == UINT_MAX ||
        (raw.header.dwType != RIM_TYPEMOUSE &&
         raw.header.dwType != RIM_TYPEKEYBOARD))
    {
        return;
    }

    input_message message = {};
    message.source = input_message_source::raw_input;
    message.device_type = raw.header.dwType == RIM_TYPEMOUSE
        ? input_device_type::mouse
        : input_device_type::keyboard;
    message.sequence =
        g_official_input_sequence.fetch_add(1, std::memory_order_relaxed) + 1;
    message.target_window = route_window;
    message.source_window = details.hwnd;
    message.device_handle =
        reinterpret_cast<std::uintptr_t>(raw.header.hDevice);
    message.wparam = static_cast<std::uint64_t>(raw.header.wParam);
    if (GET_RAWINPUT_CODE_WPARAM(raw.header.wParam) == RIM_INPUT)
    {
        message.flags = static_cast<std::uint32_t>(
            input_message_flags::foreground);
    }
    message.message = details.message;
    message.time = details.time;
    set_official_message_position(message, details, route_window);

    if (raw.header.dwType == RIM_TYPEMOUSE)
    {
        message.mouse.flags = raw.data.mouse.usFlags;
        message.mouse.button_flags = raw.data.mouse.usButtonFlags;
        message.mouse.button_data = raw.data.mouse.usButtonData;
        message.mouse.raw_buttons = raw.data.mouse.ulRawButtons;
        message.mouse.last_x = raw.data.mouse.lLastX;
        message.mouse.last_y = raw.data.mouse.lLastY;
        message.mouse.extra_information =
            raw.data.mouse.ulExtraInformation;
    }
    else
    {
        message.keyboard.make_code = raw.data.keyboard.MakeCode;
        message.keyboard.flags = raw.data.keyboard.Flags;
        message.keyboard.virtual_key = raw.data.keyboard.VKey;
        message.keyboard.message = raw.data.keyboard.Message;
        message.keyboard.extra_information =
            raw.data.keyboard.ExtraInformation;
    }

    const std::uint32_t registration_flags =
        official_raw_registration_flags(details.hwnd);
    const bool no_legacy = raw.header.dwType == RIM_TYPEMOUSE
        ? (registration_flags & official_raw_no_legacy_mouse) != 0
        : (registration_flags & official_raw_no_legacy_keyboard) != 0;
    if (no_legacy)
    {
        message.flags |= static_cast<std::uint32_t>(
            input_message_flags::no_legacy);
        if (raw.header.dwType == RIM_TYPEKEYBOARD)
        {
            capture_official_raw_keyboard_text(
                message,
                raw.data.keyboard,
                details.hwnd);
        }
    }
    on_input_message(message);
}

LRESULT CALLBACK official_get_message_hook(
    int code,
    WPARAM remove_mode,
    LPARAM message_pointer) noexcept
{
    g_official_hook_callbacks.fetch_add(1, std::memory_order_acquire);
    const official_hook_callback_release release_callback;

    if (code < 0 ||
        remove_mode != PM_REMOVE ||
        message_pointer == 0 ||
        g_official_hooks_shutting_down.load(std::memory_order_acquire))
    {
        return CallNextHookEx(nullptr, code, remove_mode, message_pointer);
    }

    auto *const details = reinterpret_cast<MSG *>(message_pointer);
    if (service_official_subclass_setup(*details) || g_has_private_input_observer)
        return CallNextHookEx(nullptr, code, remove_mode, message_pointer);
    if (!is_official_overlay_input_message(details->message))
        return CallNextHookEx(nullptr, code, remove_mode, message_pointer);

    official_hook_owner *const owner =
        find_official_hook_owner(GetCurrentThreadId(), details->hwnd);
    if (owner == nullptr)
        return CallNextHookEx(nullptr, code, remove_mode, message_pointer);

    // Mouse and pointer input are deliberately owned by the same-thread
    // window subclass. Passing queued records through unchanged lets the
    // system perform mouse-to-pointer promotion and gives a single blocker
    // for queued and directly sent input. Keyboard/text/raw input remains
    // owned here.
    if (is_official_mouse_message(details->message) ||
        is_official_pointer_message(details->message))
        return CallNextHookEx(nullptr, code, remove_mode, message_pointer);

    const input_phase phase = owner->phase.load(std::memory_order_acquire);
    const bool route = phase == input_phase::enabled;
    HWND const route_window = reinterpret_cast<HWND>(
        owner->route_window.load(std::memory_order_relaxed));
    if (route)
    {
        if (details->message == WM_INPUT)
            observe_official_raw_input(*details, route_window);
        else
            observe_official_window_message(*details, route_window);

        // The application would ordinarily translate these after GetMessage
        // returns. Since it receives WM_NULL below, do that exactly once here
        // so layout/dead-key/Unicode text messages remain in the same queue.
        if (details->message == WM_KEYDOWN ||
            details->message == WM_SYSKEYDOWN)
        {
            TranslateMessage(details);
        }
    }

    // Mutate before continuing the chain. ReShade's own Get/PeekMessage
    // detour and any later WH_GETMESSAGE observer therefore see WM_NULL too,
    // preventing duplicate ImGui delivery while the game is intercepted.
    details->message = WM_NULL;
    details->wParam = 0;
    details->lParam = 0;
    return CallNextHookEx(nullptr, code, remove_mode, message_pointer);
}

constexpr WPARAM official_subclass_install =
    static_cast<WPARAM>(0x45474F494E535441ULL);
constexpr WPARAM official_cursor_update = static_cast<WPARAM>(0x45474355U);
constexpr WPARAM official_subclass_remove =
    static_cast<WPARAM>(0x45474F52454D4F56ULL);

UINT_PTR official_subclass_id(const official_hook_owner &owner) noexcept
{
    return owner.setup_cookie.load(std::memory_order_acquire);
}

bool official_owner_filters_window(
    const official_hook_owner &owner,
    HWND message_window) noexcept
{
    if (message_window == nullptr ||
        !owner.hook_ready.load(std::memory_order_acquire) ||
        owner.phase.load(std::memory_order_acquire) == input_phase::disabled)
    {
        return false;
    }

    HWND const root = reinterpret_cast<HWND>(
        owner.root_window.load(std::memory_order_acquire));
    HWND const message_root = [&]() {
        HWND const ancestor = GetAncestor(message_window, GA_ROOT);
        return ancestor != nullptr ? ancestor : message_window;
    }();
    HWND const foreground = GetForegroundWindow();
    HWND const foreground_root = foreground != nullptr
        ? ([&]() {
              HWND const ancestor = GetAncestor(foreground, GA_ROOT);
              return ancestor != nullptr ? ancestor : foreground;
          })()
        : nullptr;
    return root != nullptr &&
        message_root == root &&
        foreground_root == root;
}

bool apply_owner_cursor(official_hook_owner &owner) noexcept
{
    const HWND root = reinterpret_cast<HWND>(owner.root_window.load(std::memory_order_acquire));
    const HWND foreground = GetForegroundWindow();
    const bool foreground_owned = foreground != nullptr &&
        (foreground == root || GetAncestor(foreground, GA_ROOT) == root);
    const std::int32_t code = foreground_owned
        ? owner.cursor_code.load(std::memory_order_acquire) : -1;
    if (code < 0)
    {
        if (owner.cursor_owned)
        {
            SetCursor(owner.saved_cursor);
            while (owner.cursor_show_adjustment > 0)
            {
                ShowCursor(FALSE);
                --owner.cursor_show_adjustment;
            }
            owner.cursor_owned = false;
        }
        return false;
    }
    if (!owner.cursor_owned)
    {
        owner.saved_cursor = GetCursor();
        owner.cursor_owned = true;
    }
    HCURSOR cursor = code == 0 ? nullptr
        : LoadCursorW(nullptr, MAKEINTRESOURCEW(static_cast<WORD>(code)));
    SetCursor(cursor);
    if (code != 0)
    {
        CURSORINFO info = { sizeof(CURSORINFO) };
        if (GetCursorInfo(&info) && (info.flags & CURSOR_SHOWING) == 0)
        {
            // Balance only our own increments when returning ownership. A game
            // may have hidden its cursor before interception started.
            int count;
            do {
                count = ShowCursor(TRUE);
                ++owner.cursor_show_adjustment;
            } while (count < 0 && owner.cursor_show_adjustment < 32);
        }
    }
    return true;
}

LRESULT CALLBACK official_window_subclass(
    HWND window,
    UINT message,
    WPARAM wparam,
    LPARAM lparam,
    UINT_PTR subclass_id,
    DWORD_PTR reference_data) noexcept
{
    g_official_hook_callbacks.fetch_add(1, std::memory_order_acquire);
    const official_hook_callback_release release_callback;

    auto *const owner =
        reinterpret_cast<official_hook_owner *>(reference_data);
    const bool owner_valid =
        owner >= g_official_hook_owners.data() &&
        owner < g_official_hook_owners.data() +
            g_official_hook_owners.size() &&
        subclass_id != 0 && subclass_id == official_subclass_id(*owner) &&
        official_owner_window_matches(*owner, window);
    const UINT control_message =
        g_official_control_message.load(std::memory_order_acquire);

    if (owner_valid && message == WM_NCDESTROY)
    {
        {
            const std::scoped_lock setup_lock(owner->setup_mutex);
            owner->setup_pending = false;
            owner->setup_terminal = true;
            owner->hook_ready.store(false, std::memory_order_release);
            owner->subclass_ready.store(false, std::memory_order_release);
            owner->install_error.store(ERROR_INVALID_WINDOW_HANDLE, std::memory_order_release);
        }
        owner->phase.store(input_phase::disabled, std::memory_order_release);
        owner->cursor_code.store(-1, std::memory_order_release);
        apply_owner_cursor(*owner);
        remove_official_owner_property(*owner, window);
        RemoveWindowSubclass(window, official_window_subclass, subclass_id);
        return DefSubclassProc(window, message, wparam, lparam);
    }

    if (owner_valid &&
        message == control_message &&
        wparam == official_subclass_remove &&
        static_cast<UINT_PTR>(lparam) == subclass_id)
    {
        owner->cursor_code.store(-1, std::memory_order_release);
        apply_owner_cursor(*owner);
        owner->hook_ready.store(false, std::memory_order_release);
        owner->subclass_ready.store(false, std::memory_order_release);
        RemoveWindowSubclass(
            window,
            official_window_subclass,
            subclass_id);
        return 0;
    }
    if (owner_valid &&
        message == control_message &&
        wparam == official_subclass_install)
    {
        return 0;
    }

    if (owner_valid && message == control_message && wparam == official_cursor_update)
    {
        apply_owner_cursor(*owner);
        return 0;
    }
    if (owner_valid && message == WM_SETCURSOR && LOWORD(lparam) == HTCLIENT &&
        apply_owner_cursor(*owner))
        return TRUE;

    if (!owner_valid || g_has_private_input_observer ||
        g_official_hooks_shutting_down.load(std::memory_order_acquire) ||
        !is_official_overlay_input_message(message) ||
        !official_owner_filters_window(*owner, window))
    {
        return DefSubclassProc(window, message, wparam, lparam);
    }

    if (owner->phase.load(std::memory_order_acquire) ==
        input_phase::enabled)
    {
        if (is_official_pointer_message(message))
            mark_official_pointer_message(message);

        MSG details = {};
        details.hwnd = window;
        details.message = message;
        details.wParam = wparam;
        details.lParam = lparam;
        details.time = static_cast<DWORD>(GetMessageTime());
        const DWORD position = GetMessagePos();
        details.pt.x = static_cast<std::int16_t>(LOWORD(position));
        details.pt.y = static_cast<std::int16_t>(HIWORD(position));
        HWND const route_window = reinterpret_cast<HWND>(
            owner->route_window.load(std::memory_order_relaxed));
        if (message == WM_INPUT)
            observe_official_raw_input(details, route_window);
        else
            observe_official_window_message(details, route_window);
    }

    // Mouse and pointer messages stay intact through WH_GETMESSAGE so Windows
    // can perform mouse-to-pointer promotion before dispatch. Returning zero
    // owns both queued and directly sent input before the game and before
    // downstream subclasses.
    return 0;
}

bool complete_official_subclass_setup(official_hook_owner &owner, HWND window,
    std::uintptr_t cookie) noexcept
{
    if (!owner.setup_pending || cookie == 0 || official_subclass_id(owner) != cookie ||
        !official_owner_window_matches(owner, window) ||
        owner.root_window.load(std::memory_order_acquire) != reinterpret_cast<std::uintptr_t>(window) ||
        owner.thread_id.load(std::memory_order_acquire) != GetCurrentThreadId())
        return false;
    SetLastError(ERROR_SUCCESS);
    const BOOL installed = SetWindowSubclass(window, official_window_subclass,
        static_cast<UINT_PTR>(cookie), reinterpret_cast<DWORD_PTR>(&owner));
    DWORD error = installed != FALSE ? ERROR_SUCCESS : GetLastError();
    if (installed == FALSE && error == ERROR_SUCCESS)
        error = ERROR_INVALID_HOOK_HANDLE;
    owner.install_error.store(error, std::memory_order_release);
    owner.subclass_ready.store(installed != FALSE, std::memory_order_release);
    owner.hook_ready.store(installed != FALSE, std::memory_order_release);
    if (installed != FALSE)
    {
        owner.setup_pending = false;
        char detail[256] = {};
        sprintf_s(detail, "Electron game overlay acknowledged owner-thread "
            "input/cursor setup for root HWND %p on thread %lu.", window,
            static_cast<unsigned long>(GetCurrentThreadId()));
        reshade::log::message(reshade::log::level::info, detail);
        return true;
    }
    return false;
}

bool service_official_subclass_setup(MSG &message) noexcept
{
    if (message.message != g_official_control_message.load(std::memory_order_acquire) ||
        message.wParam != official_subclass_install)
        return false;
    const auto cookie = static_cast<std::uintptr_t>(message.lParam);
    for (auto &owner : g_official_hook_owners)
    {
        if (cookie == 0 || official_subclass_id(owner) != cookie)
            continue;
        const std::scoped_lock setup_lock(owner.setup_mutex);
        if (!g_official_hooks_shutting_down.load(std::memory_order_acquire))
            static_cast<void>(complete_official_subclass_setup(owner, message.hwnd, cookie));
        break;
    }
    // Obsolete generation requests are consumed too. They never reach game
    // code or install a subclass belonging to a recycled owner slot.
    message.message = WM_NULL; message.wParam = 0; message.lParam = 0;
    return true;
}

struct electron_texture
{
    resource texture = {};
    resource_view view = {};
    std::uint32_t width = 0;
    std::uint32_t height = 0;
    std::uint64_t state_revision = 0;
    std::uint64_t sequence = 0;
    bool upload_failure_reported = false;
};

struct swapchain_data
{
    std::mutex texture_mutex;
    std::unordered_map<std::uint32_t, electron_texture> textures;
    ego_transport *transport = nullptr;
    HWND window = nullptr;
    std::uint64_t ownership_token = 0;
    input_phase phase = input_phase::disabled;
    ego_target_surface_v1 last_target_surface = {};
    std::uint64_t target_surface_id = 0;
    std::uint64_t target_surface_revision = 0;
    std::uint64_t observed_session_epoch = 0;
    std::uint64_t retired_session_textures = 0;
    bool has_target_surface = false;
    bool first_scene_logged = false;
    bool first_multiwindow_scene_logged = false;
    bool has_observed_session_epoch = false;
    bool has_observed_authenticated_session = false;
    bool scene_query_failure_active = false;
    bool frame_rejection_reported = false;
    ego_status last_focus_error = EGO_STATUS_OK;
    ego_status last_session_query_error = EGO_STATUS_OK;
    ego_status last_interception_error = EGO_STATUS_OK;
    ego_status last_filter_error = EGO_STATUS_OK;
    ego_status last_scene_query_error = EGO_STATUS_OK;
    ego_status last_target_surface_error = EGO_STATUS_OK;
    ego_status last_fps_error = EGO_STATUS_OK;
    std::uint64_t official_hook_token = 0;
    std::uint32_t official_hook_slot = invalid_official_hook_slot;
    bool official_hook_failure_reported = false;
    bool transport_initialization_complete = false;
    bool swapchain_ready_published = false;
    std::mutex transport_initialization_mutex;
    std::vector<ego_window_frame_v1> cooperative_frames;
    std::unordered_map<std::uint32_t, std::uint64_t> cooperative_incarnations;
    bool cooperative_frame_active = false;
    std::uint64_t cooperative_input_revision = 0;
    bool cooperative_requested_interception = false;
};

participant_state::~participant_state() = default;
participant_state g_directory_member;
#if defined(EGO_EXPERIMENTAL_PRIVATE_MEMORY_ROUTE)
std::vector<std::unique_ptr<participant_state>> g_memory_members;
std::optional<ego_private_route_v2> g_preloaded_memory_binding;
#endif

participant_state &member() noexcept
{
    return g_callback_member == nullptr ? g_directory_member : *g_callback_member;
}

swapchain_data *find_swapchain_data(device_object *surface)
{
    const std::scoped_lock lock(member().swapchain_states_mutex);
    const auto found = member().swapchain_states.find(surface->get_native());
    return found == member().swapchain_states.end() ? nullptr : found->second.get();
}


void log_transport_failure(
    reshade::log::level level,
    const char *operation,
    ego_status status)
{
    char detail[512] = {};
    std::uint64_t required = 0;
    const ego_status detail_status =
        ego_get_last_error_message(detail, sizeof(detail), &required);

    char message[768] = {};
    if ((detail_status == EGO_STATUS_OK || detail_status == EGO_STATUS_BUFFER_TOO_SMALL) &&
        detail[0] != '\0')
    {
        sprintf_s(
            message,
            "Electron game overlay runtime %s failed (status %d): %s",
            operation,
            static_cast<int>(status),
            detail);
    }
    else
    {
        sprintf_s(
            message,
            "Electron game overlay runtime %s failed (status %d).",
            operation,
            static_cast<int>(status));
    }
    reshade::log::message(level, message);
}

void log_transport_error(const char *operation, ego_status status)
{
    log_transport_failure(reshade::log::level::error, operation, status);
}

void log_transport_warning(const char *operation, ego_status status)
{
    log_transport_failure(reshade::log::level::warning, operation, status);
}

bool take_runtime_diagnostic_failure_publication(std::uint32_t code) noexcept
{
    switch (code)
    {
    case EGO_RUNTIME_DIAGNOSTIC_SCENE_QUERY_FAILED:
    case EGO_RUNTIME_DIAGNOSTIC_FRAME_REJECTED:
    case EGO_RUNTIME_DIAGNOSTIC_FRAME_UPLOAD_FAILED:
    case EGO_RUNTIME_DIAGNOSTIC_INPUT_ROUTER_RESET:
    case EGO_RUNTIME_DIAGNOSTIC_INPUT_ROUTING_FAILED:
        break;
    default:
        return true;
    }

    if (code >= member().runtime_diagnostic_failure_publication_ticks.size())
        return false;

    const std::uint64_t now = GetTickCount64();
    auto &last_publication =
        member().runtime_diagnostic_failure_publication_ticks[code];
    std::uint64_t observed =
        last_publication.load(std::memory_order_relaxed);
    for (;;)
    {
        if (observed != 0 &&
            now >= observed &&
            now - observed < runtime_diagnostic_failure_interval_ms)
        {
            return false;
        }
        if (last_publication.compare_exchange_weak(
                observed,
                now,
                std::memory_order_relaxed,
                std::memory_order_relaxed))
        {
            return true;
        }
    }
}

void publish_runtime_diagnostic(
    ego_transport *transport,
    std::uint32_t code,
    ego_status error_code = EGO_STATUS_OK)
{
    if (transport == nullptr ||
        !take_runtime_diagnostic_failure_publication(code))
    {
        return;
    }

    ego_runtime_diagnostic_v1 diagnostic = {};
    diagnostic.struct_size =
        static_cast<std::uint32_t>(sizeof(ego_runtime_diagnostic_v1));
    diagnostic.abi_version = EGO_RUNTIME_DIAGNOSTIC_ABI_VERSION;
    diagnostic.code = code;
    diagnostic.error_code = error_code;

    const ego_status status =
        ego_transport_publish_diagnostic(transport, &diagnostic);
    if (status != EGO_STATUS_OK &&
        !member().diagnostic_publication_logged.test_and_set(std::memory_order_relaxed))
    {
        log_transport_error("runtime diagnostic publication", status);
    }
}

void publish_input_routing_failure(
    ego_transport *transport,
    ego_status error_code)
{
    publish_runtime_diagnostic(
        transport,
        EGO_RUNTIME_DIAGNOSTIC_INPUT_ROUTING_FAILED,
        error_code);
}

HWND official_root_window(HWND window) noexcept
{
    if (window == nullptr)
        return nullptr;
    HWND const root = GetAncestor(window, GA_ROOT);
    return root != nullptr ? root : window;
}

bool retain_official_thread_hook(
    DWORD thread_id,
    std::uint32_t &slot_index,
    DWORD &error) noexcept
{
    for (std::uint32_t index = 0;
         index < g_official_thread_hooks.size();
         ++index)
    {
        official_thread_hook &thread_hook = g_official_thread_hooks[index];
        if (thread_hook.thread_id != thread_id || thread_hook.hook == nullptr)
            continue;
        ++thread_hook.owner_references;
        slot_index = index;
        error = ERROR_SUCCESS;
        return true;
    }

    for (std::uint32_t index = 0;
         index < g_official_thread_hooks.size();
         ++index)
    {
        official_thread_hook &thread_hook = g_official_thread_hooks[index];
        if (thread_hook.thread_id != 0 || thread_hook.hook != nullptr)
            continue;

        SetLastError(ERROR_SUCCESS);
        HHOOK const hook = SetWindowsHookExW(
            WH_GETMESSAGE,
            official_get_message_hook,
            nullptr, // Validated target thread and callback belong to this process.
            thread_id);
        if (hook == nullptr)
        {
            error = GetLastError();
            if (error == ERROR_SUCCESS)
                error = ERROR_HOOK_NEEDS_HMOD;
            return false;
        }

        thread_hook.thread_id = thread_id;
        thread_hook.hook = hook;
        thread_hook.owner_references = 1;
        slot_index = index;
        error = ERROR_SUCCESS;
        return true;
    }

    error = ERROR_TOO_MANY_TCBS;
    return false;
}

void log_official_hook_failure(
    HWND root,
    DWORD thread_id,
    DWORD error) noexcept
{
    if (g_official_hook_error_logged.test_and_set(std::memory_order_relaxed))
        return;

    char message[320] = {};
    sprintf_s(
        message,
        "Electron game overlay could not install its official-ReShade "
        "WH_GETMESSAGE input hook for root HWND %p on thread %lu "
        "(Win32 error %lu). Interception remains inactive.",
        root,
        static_cast<unsigned long>(thread_id),
        static_cast<unsigned long>(error));
    reshade::log::message(reshade::log::level::error, message);
}

UINT ensure_official_control_message() noexcept
{
    UINT message =
        g_official_control_message.load(std::memory_order_acquire);
    if (message != 0)
        return message;

    message = RegisterWindowMessageW(
        L"ElectronGameOverlay.OfficialReShade.InputHook.v1");
    if (message != 0)
        g_official_control_message.store(message, std::memory_order_release);
    return message;
}

bool install_official_window_subclass(
    official_hook_owner &owner,
    std::uint32_t) noexcept
{
    const std::scoped_lock setup_lock(owner.setup_mutex);
    HWND const root = reinterpret_cast<HWND>(
        owner.root_window.load(std::memory_order_acquire));
    const DWORD thread_id =
        owner.thread_id.load(std::memory_order_acquire);
    if (!official_owner_window_matches(owner, root) ||
        thread_id == 0 ||
        ensure_official_control_message() == 0)
    {
        owner.install_error.store(
            ERROR_INVALID_WINDOW_HANDLE,
            std::memory_order_release);
        owner.setup_terminal = true;
        owner.setup_pending = false;
        owner.hook_ready.store(false, std::memory_order_release);
        return false;
    }
    if (owner.hook_ready.load(std::memory_order_acquire))
        return true;
    if (!owner.setup_pending || owner.setup_terminal || owner.setup_deadline_reported)
        return false;

    if (GetCurrentThreadId() == thread_id &&
        complete_official_subclass_setup(owner, root, official_subclass_id(owner)))
        return true;
    const std::uint64_t now = GetTickCount64();
    if (now >= owner.setup_deadline)
    {
        // Report the bounded startup failure, but retain the last queued
        // generation request so an owner thread that resumes later can rescue
        // the dispatcher. No more messages are posted after this deadline.
        owner.setup_deadline_reported = true;
        owner.install_error.store(ERROR_TIMEOUT, std::memory_order_release);
        return false;
    }
    if (now >= owner.setup_next_retry)
    {
        owner.setup_next_retry = now + official_setup_retry_ms;
        SetLastError(ERROR_SUCCESS);
        if (PostMessageW(root, g_official_control_message.load(std::memory_order_acquire),
            official_subclass_install, static_cast<LPARAM>(official_subclass_id(owner))) == FALSE)
            owner.install_error.store(GetLastError(), std::memory_order_release);
    }
    return false;
}

bool remove_official_window_subclass(
    official_hook_owner &owner) noexcept
{
    {
        const std::scoped_lock setup_lock(owner.setup_mutex);
        owner.setup_pending = false;
    }
    if (!owner.subclass_ready.load(std::memory_order_acquire))
    {
        remove_official_owner_property(owner, reinterpret_cast<HWND>(owner.root_window.load(std::memory_order_acquire)));
        return true;
    }

    owner.hook_ready.store(false, std::memory_order_release);
    HWND const root = reinterpret_cast<HWND>(
        owner.root_window.load(std::memory_order_acquire));
    const DWORD thread_id =
        owner.thread_id.load(std::memory_order_acquire);
    if (root == nullptr || IsWindow(root) == FALSE)
    {
        owner.subclass_ready.store(false, std::memory_order_release);
        return true;
    }

    if (GetCurrentThreadId() == thread_id)
    {
        const BOOL removed = RemoveWindowSubclass(
            root,
            official_window_subclass,
            official_subclass_id(owner));
        if (removed != FALSE)
        {
            owner.subclass_ready.store(false, std::memory_order_release);
            remove_official_owner_property(owner, root);
        }
        return removed != FALSE;
    }

    DWORD_PTR ignored_result = 0;
    const LRESULT sent = SendMessageTimeoutW(
        root,
        g_official_control_message.load(std::memory_order_acquire),
        official_subclass_remove,
        static_cast<LPARAM>(official_subclass_id(owner)),
        SMTO_ABORTIFHUNG | SMTO_BLOCK,
        2000,
        &ignored_result);
    const bool removed = sent != 0 && !owner.subclass_ready.load(std::memory_order_acquire);
    if (removed)
        remove_official_owner_property(owner, root);
    return removed;
}

bool retain_official_hook_owner(swapchain_data &data) noexcept
{
    if (data.window == nullptr ||
        g_official_hooks_shutting_down.load(std::memory_order_acquire))
    {
        return false;
    }

    HWND const root = official_root_window(data.window);
    DWORD process_id = 0;
    const DWORD thread_id =
        root != nullptr
        ? GetWindowThreadProcessId(root, &process_id)
        : 0;
    const std::uint64_t token =
        g_official_hook_token_sequence.fetch_add(
            1,
            std::memory_order_relaxed) +
        1;

    const std::scoped_lock lock(g_official_hook_mutex);
    for (std::uint32_t index = 0;
         index < g_official_hook_owners.size();
         ++index)
    {
        official_hook_owner &owner = g_official_hook_owners[index];
        if (owner.references == 0 ||
            reinterpret_cast<HWND>(
                owner.root_window.load(std::memory_order_acquire)) != root ||
            owner.thread_id.load(std::memory_order_acquire) != thread_id ||
            process_id != GetCurrentProcessId() || !official_owner_window_matches(owner, root))
        {
            continue;
        }

        ++owner.references;
        data.official_hook_slot = index;
        data.official_hook_token = token;
        if (owner.hook_ready.load(std::memory_order_acquire))
            return true;
        const std::scoped_lock setup_lock(owner.setup_mutex);
        return !owner.setup_terminal && !owner.setup_deadline_reported;
    }

    DWORD install_error = ERROR_SUCCESS;
    std::uint32_t thread_hook_slot = invalid_official_hook_slot;
    bool const identity_valid =
        root != nullptr &&
        thread_id != 0 &&
        process_id == GetCurrentProcessId();
    const bool message_hook_ready =
        identity_valid &&
        retain_official_thread_hook(
            thread_id,
            thread_hook_slot,
            install_error);
    if (!identity_valid)
        install_error = ERROR_INVALID_WINDOW_HANDLE;

    for (std::uint32_t index = 0;
         index < g_official_hook_owners.size();
         ++index)
    {
        official_hook_owner &owner = g_official_hook_owners[index];
        if (owner.references != 0 ||
            owner.root_window.load(std::memory_order_acquire) != 0)
        {
            continue;
        }

        std::uintptr_t cookie = g_official_setup_cookie_sequence.load(std::memory_order_relaxed);
        while (cookie != (std::numeric_limits<std::uintptr_t>::max)() &&
            !g_official_setup_cookie_sequence.compare_exchange_weak(cookie, cookie + 1,
                std::memory_order_relaxed, std::memory_order_relaxed)) {}
        cookie = cookie == (std::numeric_limits<std::uintptr_t>::max)() ? 0 : cookie + 1;
        const std::scoped_lock setup_lock(owner.setup_mutex);
        owner.references = 1;
        owner.thread_hook_slot = thread_hook_slot;
        owner.install_error.store(install_error, std::memory_order_relaxed);
        owner.route_window.store(
            reinterpret_cast<std::uintptr_t>(data.window),
            std::memory_order_relaxed);
        owner.thread_id.store(thread_id, std::memory_order_relaxed);
        owner.primary_token.store(0, std::memory_order_relaxed);
        owner.phase.store(input_phase::disabled, std::memory_order_relaxed);
        owner.hook_ready.store(false, std::memory_order_relaxed);
        owner.subclass_ready.store(false, std::memory_order_relaxed);
        owner.setup_cookie.store(cookie, std::memory_order_relaxed);
        owner.setup_pending = message_hook_ready && cookie != 0;
        owner.setup_terminal = !message_hook_ready || cookie == 0;
        owner.setup_deadline_reported = false;
        owner.setup_deadline = GetTickCount64() + official_setup_timeout_ms;
        owner.setup_next_retry = 0;
        if (cookie != 0 && SetPropW(root, official_owner_property_name(),
            reinterpret_cast<HANDLE>(cookie)) == FALSE)
        {
            owner.setup_pending = false;
            owner.setup_terminal = true;
            owner.install_error.store(GetLastError(), std::memory_order_relaxed);
        }
        if (cookie == 0)
            owner.install_error.store(ERROR_ARITHMETIC_OVERFLOW, std::memory_order_relaxed);
        owner.root_window.store(
            reinterpret_cast<std::uintptr_t>(root),
            std::memory_order_release);
        data.official_hook_slot = index;
        data.official_hook_token = token;

        // A pending owner is a live lease, not a failed installation. The
        // first eligible Present advances setup after releasing this registry
        // mutex, allowing the window thread to acknowledge independently.
        if (owner.setup_terminal)
        {
            log_official_hook_failure(
                root,
                thread_id,
                owner.install_error.load(std::memory_order_acquire));
        }
        return !owner.setup_terminal;
    }

    if (message_hook_ready &&
        thread_hook_slot < g_official_thread_hooks.size())
    {
        official_thread_hook &thread_hook =
            g_official_thread_hooks[thread_hook_slot];
        if (thread_hook.owner_references > 0)
            --thread_hook.owner_references;
        if (thread_hook.owner_references == 0)
        {
            UnhookWindowsHookEx(thread_hook.hook);
            thread_hook = {};
        }
    }
    log_official_hook_failure(root, thread_id, ERROR_TOO_MANY_TCBS);
    return false;
}

official_hook_owner *get_official_hook_owner(
    const swapchain_data &data) noexcept
{
    if (data.official_hook_slot >= g_official_hook_owners.size() ||
        data.official_hook_token == 0)
    {
        return nullptr;
    }

    official_hook_owner &owner =
        g_official_hook_owners[data.official_hook_slot];
    return owner.root_window.load(std::memory_order_acquire) != 0
        ? &owner
        : nullptr;
}

enum class official_setup_status { pending, ready, failed };

official_setup_status advance_official_hook_setup(swapchain_data &data)
{
    auto *const owner = get_official_hook_owner(data);
    if (owner == nullptr)
        return official_setup_status::failed;
    const std::scoped_lock registry_lock(g_official_hook_mutex);
    static_cast<void>(install_official_window_subclass(*owner, data.official_hook_slot));
    const std::scoped_lock setup_lock(owner->setup_mutex);
    if (owner->hook_ready.load(std::memory_order_acquire))
        return official_setup_status::ready;
    return owner->setup_terminal || owner->setup_deadline_reported
        ? official_setup_status::failed : official_setup_status::pending;
}

bool claim_official_input_owner(swapchain_data &data) noexcept
{
    official_hook_owner *const owner = get_official_hook_owner(data);
    if (owner == nullptr ||
        !owner->hook_ready.load(std::memory_order_acquire))
    {
        return false;
    }

    std::uint64_t primary =
        owner->primary_token.load(std::memory_order_acquire);
    if (primary == 0)
    {
        owner->primary_token.compare_exchange_strong(
            primary,
            data.official_hook_token,
            std::memory_order_acq_rel,
            std::memory_order_acquire);
        primary = owner->primary_token.load(std::memory_order_acquire);
    }
    if (primary != data.official_hook_token)
    {
        // Presenting peers for one exact HWND share one hook/cursor lease.
        // Transfer only its teardown token, preserving its phase and cursor
        // bookkeeping. An older peer's destructor can no longer release it.
        if (owner->route_window.load(std::memory_order_acquire) !=
            reinterpret_cast<std::uintptr_t>(data.window))
            return false;
        owner->primary_token.store(data.official_hook_token, std::memory_order_release);
    }

    // The elected rendering owner may differ from the first swap chain that
    // retained this root-window hook. Publish its exact route HWND before its
    // enabled phase becomes visible to the hook callbacks.
    owner->route_window.store(
        reinterpret_cast<std::uintptr_t>(data.window),
        std::memory_order_relaxed);
    return true;
}

void publish_official_hook_phase(
    const swapchain_data &data,
    input_phase phase) noexcept
{
    official_hook_owner *const owner = get_official_hook_owner(data);
    if (owner == nullptr ||
        owner->primary_token.load(std::memory_order_acquire) !=
            data.official_hook_token)
    {
        return;
    }
    owner->phase.store(phase, std::memory_order_release);
}

void release_official_hook_owner(swapchain_data &data) noexcept
{
    if (data.official_hook_slot >= g_official_hook_owners.size() ||
        data.official_hook_token == 0)
    {
        data.official_hook_slot = invalid_official_hook_slot;
        data.official_hook_token = 0;
        return;
    }

    const std::scoped_lock lock(g_official_hook_mutex);
    official_hook_owner &owner =
        g_official_hook_owners[data.official_hook_slot];
    g_logical_control.run([&] {
        if (owner.primary_token.load(std::memory_order_acquire) ==
            data.official_hook_token)
        {
            owner.phase.store(input_phase::disabled, std::memory_order_release);
            owner.primary_token.store(0, std::memory_order_release);
        }
    });

    if (owner.references > 0)
        --owner.references;
    if (owner.references == 0)
    {
        owner.phase.store(input_phase::disabled, std::memory_order_release);
        owner.hook_ready.store(false, std::memory_order_release);
        const bool subclass_removed =
            remove_official_window_subclass(owner);
        if (!subclass_removed)
        {
            g_official_subclass_teardown_failed.store(
                true,
                std::memory_order_release);
        }

        if (owner.thread_hook_slot < g_official_thread_hooks.size())
        {
            official_thread_hook &thread_hook =
                g_official_thread_hooks[owner.thread_hook_slot];
            if (thread_hook.owner_references > 0)
                --thread_hook.owner_references;
            if (thread_hook.owner_references == 0)
            {
                if (thread_hook.hook != nullptr)
                    UnhookWindowsHookEx(thread_hook.hook);
                thread_hook = {};
            }
        }

        if (subclass_removed)
        {
            owner.root_window.store(0, std::memory_order_release);
            owner.route_window.store(0, std::memory_order_relaxed);
            owner.thread_id.store(0, std::memory_order_relaxed);
            owner.primary_token.store(0, std::memory_order_relaxed);
            owner.subclass_ready.store(false, std::memory_order_relaxed);
        }
        owner.thread_hook_slot = invalid_official_hook_slot;
        owner.install_error.store(ERROR_SUCCESS, std::memory_order_relaxed);
    }

    data.official_hook_slot = invalid_official_hook_slot;
    data.official_hook_token = 0;
}

void shutdown_official_message_hooks(bool wait_for_callbacks) noexcept
{
    g_official_hooks_shutting_down.store(true, std::memory_order_release);

    {
        const std::scoped_lock lock(g_official_hook_mutex);
        for (official_hook_owner &owner : g_official_hook_owners)
        {
            owner.phase.store(input_phase::disabled, std::memory_order_release);
            owner.hook_ready.store(false, std::memory_order_release);
            const bool subclass_removed =
                remove_official_window_subclass(owner);
            if (!subclass_removed)
            {
                g_official_subclass_teardown_failed.store(
                    true,
                    std::memory_order_release);
            }
            else
            {
                owner.root_window.store(0, std::memory_order_release);
                owner.route_window.store(0, std::memory_order_relaxed);
                owner.thread_id.store(0, std::memory_order_relaxed);
                owner.primary_token.store(0, std::memory_order_relaxed);
                owner.subclass_ready.store(false, std::memory_order_relaxed);
            }
            owner.references = 0;
            owner.thread_hook_slot = invalid_official_hook_slot;
            owner.install_error.store(
                ERROR_SUCCESS,
                std::memory_order_relaxed);
        }
        for (official_thread_hook &thread_hook : g_official_thread_hooks)
        {
            if (thread_hook.hook != nullptr)
                UnhookWindowsHookEx(thread_hook.hook);
            thread_hook = {};
        }
    }

    if (!wait_for_callbacks)
        return;

    const ULONGLONG deadline = GetTickCount64() + 5000;
    while (g_official_hook_callbacks.load(std::memory_order_acquire) != 0 &&
           GetTickCount64() < deadline)
    {
        Sleep(1);
    }
    const bool callback_timeout =
        g_official_hook_callbacks.load(std::memory_order_acquire) != 0;
    const bool subclass_teardown_failed =
        g_official_subclass_teardown_failed.load(std::memory_order_acquire);
    if (!callback_timeout && !subclass_teardown_failed)
        return;

    if (!g_official_hook_shutdown_timeout_logged.test_and_set(
            std::memory_order_relaxed))
    {
        reshade::log::message(
            reshade::log::level::error,
            callback_timeout
                ? "Electron game overlay timed out waiting for an "
                  "official-ReShade input callback during unload; pinning the "
                  "add-on module to avoid executing an unloaded callback."
                : "Electron game overlay could not remove an official-ReShade "
                  "window subclass during unload; pinning the add-on module "
                  "to avoid executing an unloaded callback.");
    }
    HMODULE pinned_module = nullptr;
    if (GetModuleHandleExW(
        GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
            GET_MODULE_HANDLE_EX_FLAG_PIN,
        reinterpret_cast<LPCWSTR>(&g_addon_module),
        &pinned_module))
        g_module_pinned.store(true, std::memory_order_release);
}

ego_transport *retain_transport()
{
    // A manager-installed official-host adapter is intentionally routeless.
    // Its installation directory is never a private producer workspace and
    // must not receive Rust startup diagnostics or discovery output.
#if !defined(EGO_EXPERIMENTAL_PRIVATE_MEMORY_ROUTE)
    if (member().private_run_directory.empty() || !member().private_route_present)
        return nullptr;
#endif
    const std::scoped_lock lifecycle_lock(member().transport_lifecycle_mutex);
    const std::scoped_lock lock(member().transport_mutex);
#if defined(EGO_EXPERIMENTAL_PRIVATE_MEMORY_ROUTE)
    if (!member().private_memory_route && (member().private_run_directory.empty() || !member().private_route_present))
        return nullptr;
#endif
    if (member().transport == nullptr)
    {
        // A new Rust bridge has a new ordered focus-command stream.
        member().cooperative_focus_revision = 0;
        member().logical_session_epoch.reset();
        member().member_input_driver.reset();
        member().cooperative_member_phase = input_phase::disabled;
        member().logical_fps_publication_tick = 0;
        // Capabilities describe this mapped host's input seam, not the app's
        // package version. Stock ReShade exposes WM_INPUT through our message
        // hook, but only the validated private observer copies buffered reads.
        const std::uint64_t input_capabilities = EGO_INPUT_CAPABILITY_COPIED_WM_INPUT |
            (g_has_private_input_observer ? EGO_INPUT_CAPABILITY_COPIED_RAW_INPUT_BUFFER : 0);
        const ego_status status =
#if defined(EGO_EXPERIMENTAL_PRIVATE_MEMORY_ROUTE)
            member().private_memory_route ? ego_transport_create_for_private_route_v2(
                EGO_ABI_VERSION, &*member().private_memory_route, &member().transport) :
#endif
            ego_transport_create_for_directory_with_input_capabilities(
                EGO_ABI_VERSION,
                reinterpret_cast<const std::uint8_t *>(member().private_run_directory.data()),
                member().private_run_directory.size(),
                input_capabilities,
                &member().transport);
        if (status != EGO_STATUS_OK)
        {
            log_transport_error("transport initialization", status);
            member().transport = nullptr;
            return nullptr;
        }
        reshade::log::message(
            reshade::log::level::info,
            "Electron game overlay runtime initialized its transport and input router.");
        publish_runtime_diagnostic(
            member().transport,
            EGO_RUNTIME_DIAGNOSTIC_RUNTIME_READY);
    }

    ++member().transport_references;
    return member().transport;
}

void release_transport(ego_transport *transport, bool release_reference = true)
{
    // Keep a new zero-to-one transition behind the bounded drain/destroy, but
    // release the registry lock before waiting on the Rust/network workers.
    const std::scoped_lock lifecycle_lock(member().transport_lifecycle_mutex);
    ego_transport *destroy = nullptr;
    {
        const std::scoped_lock lock(member().transport_mutex);
        if (!release_reference && transport == nullptr)
            transport = member().transport;
        if (transport == nullptr || transport != member().transport ||
            (release_reference && member().transport_references == 0))
            return;

        if (release_reference)
            --member().transport_references;
        if (member().transport_references == 0 && !g_cooperative.has_live_surfaces())
        {
            destroy = member().transport;
            member().transport = nullptr;
            // A true zero-surface retirement is a fresh private bridge on the
            // next graphics lifecycle. Do not revive old focus/rank merely
            // because the new decoder allocates the same local IDs again.
            g_cooperative.cancel_owned_input(member().participant_id);
            static_cast<void>(g_cooperative.publish_windows(member().participant_id, nullptr, 0, true));
            static_cast<void>(g_cooperative.reconcile_registrations(member().participant_id, nullptr, 0));
            member().producer_registration_order.clear();
            member().cooperative_focus_revision = 0;
            member().logical_session_epoch.reset();
            member().member_input_driver.reset();
            member().cooperative_member_phase = input_phase::disabled;
            member().logical_fps_publication_tick = 0;
        }
    }

    if (destroy != nullptr)
    {
        const ego_status drain_status = ego_transport_drain(
            destroy,
            final_transport_drain_timeout_ms);
        if (drain_status != EGO_STATUS_OK)
            log_transport_warning("final outbound transport drain", drain_status);

        const ego_status status = ego_transport_destroy(destroy);
        if (status != EGO_STATUS_OK)
            log_transport_error("transport shutdown", status);
    }
}

bool target_window_focused(HWND window) noexcept
{
    if (window == nullptr || IsWindow(window) == FALSE)
        return false;

    const HWND foreground = GetForegroundWindow();
    if (foreground == nullptr)
        return false;

    return official_root_window(foreground) == official_root_window(window);
}

enum class raw_projection_result : std::uint8_t
{
    ignored,
    routed,
    failed,
};

bool route_normalized_input(
    ego_transport *transport,
    HWND target_window,
    std::uint32_t message,
    std::uint64_t wparam,
    std::int64_t lparam) noexcept
{
    ego_status status = EGO_STATUS_OK;
    if (member().participant_id != 0 && g_cooperative_owned_record)
    {
        if (g_cooperative_raw_point_valid &&
            (message == WM_MOUSEMOVE || message == WM_LBUTTONDOWN || message == WM_LBUTTONUP ||
             message == WM_RBUTTONDOWN || message == WM_RBUTTONUP || message == WM_MBUTTONDOWN || message == WM_MBUTTONUP))
            lparam = encode_client_point(g_cooperative_raw_x, g_cooperative_raw_y);
        else if (g_cooperative_raw_point_valid && (message == WM_MOUSEWHEEL || message == WM_MOUSEHWHEEL))
        {
            POINT screen = {g_cooperative_raw_x, g_cooperative_raw_y};
            if (!ClientToScreen(target_window, &screen)) return true;
            lparam = encode_client_point(screen.x, screen.y);
        }
        const auto owner = g_cooperative_record_owner;
        const auto focus = g_cooperative_record_focus;
        static_cast<void>(ego_transport_set_cooperative_focus(
            transport, focus.participant == member().participant_id ? focus.window_id : 0,
            focus.participant == member().participant_id ? focus.incarnation : 0));
        if (owner.participant != member().participant_id)
            return true;
        status = ego_transport_route_owned_window_message(
            transport, owner.window_id, owner.incarnation,
            reinterpret_cast<std::uintptr_t>(target_window), message, wparam, lparam);
    }
    else
    {
        status = ego_transport_route_window_message(
            transport, reinterpret_cast<std::uintptr_t>(target_window), message, wparam, lparam);
    }
    if (status == EGO_STATUS_OK)
        return true;

    if (!member().route_error_logged.test_and_set(std::memory_order_relaxed))
        log_transport_error("normalized raw input delivery", status);
    publish_input_routing_failure(transport, status);
    return false;
}

bool raw_target_owned_by_primary(HWND raw_target, HWND primary_target) noexcept
{
    if (raw_target == nullptr ||
        primary_target == nullptr ||
        IsWindow(raw_target) == FALSE ||
        IsWindow(primary_target) == FALSE)
    {
        return false;
    }
    return official_root_window(raw_target) ==
        official_root_window(primary_target);
}

std::int32_t saturating_coordinate_add(
    std::int32_t value,
    std::int32_t delta) noexcept
{
    return static_cast<std::int32_t>(std::clamp(
        static_cast<std::int64_t>(value) + delta,
        static_cast<std::int64_t>(std::numeric_limits<std::int32_t>::min()),
        static_cast<std::int64_t>(std::numeric_limits<std::int32_t>::max())));
}

void clamp_raw_client_point(
    HWND window,
    std::int32_t &x,
    std::int32_t &y) noexcept
{
    RECT client = {};
    if (GetClientRect(window, &client) == FALSE ||
        client.right <= client.left ||
        client.bottom <= client.top)
    {
        return;
    }
    x = std::clamp(
        x,
        static_cast<std::int32_t>(client.left),
        static_cast<std::int32_t>(client.right - 1));
    y = std::clamp(
        y,
        static_cast<std::int32_t>(client.top),
        static_cast<std::int32_t>(client.bottom - 1));
}

bool ordered_raw_key_down(std::uint32_t key) noexcept
{
    return key < member().raw_input_state.keys_down.size() &&
        member().raw_input_state.keys_down[key];
}

std::uint32_t ordered_raw_mouse_key_state() noexcept
{
    std::uint32_t state = member().raw_input_state.mouse_buttons;
    if (ordered_raw_key_down(VK_SHIFT) ||
        ordered_raw_key_down(VK_LSHIFT) ||
        ordered_raw_key_down(VK_RSHIFT))
    {
        state |= MK_SHIFT;
    }
    if (ordered_raw_key_down(VK_CONTROL) ||
        ordered_raw_key_down(VK_LCONTROL) ||
        ordered_raw_key_down(VK_RCONTROL))
    {
        state |= MK_CONTROL;
    }
    return state;
}

raw_projection_result project_raw_mouse(
    ego_transport *transport,
    const input_message &message,
    HWND target) noexcept
{
    ordered_raw_input_state &state = member().raw_input_state;
    const bool absolute =
        (message.mouse.flags & MOUSE_MOVE_ABSOLUTE) != 0;
    std::int32_t x = message.client_x;
    std::int32_t y = message.client_y;
    if (absolute)
    {
        const bool virtual_desktop =
            (message.mouse.flags & MOUSE_VIRTUAL_DESKTOP) != 0;
        const int screen_left = virtual_desktop
            ? GetSystemMetrics(SM_XVIRTUALSCREEN)
            : 0;
        const int screen_top = virtual_desktop
            ? GetSystemMetrics(SM_YVIRTUALSCREEN)
            : 0;
        const int screen_width = GetSystemMetrics(
            virtual_desktop ? SM_CXVIRTUALSCREEN : SM_CXSCREEN);
        const int screen_height = GetSystemMetrics(
            virtual_desktop ? SM_CYVIRTUALSCREEN : SM_CYSCREEN);
        if (screen_width > 0 && screen_height > 0)
        {
            constexpr std::int64_t absolute_range = 65'535;
            const std::int64_t normalized_x = std::clamp<std::int64_t>(
                message.mouse.last_x,
                0,
                absolute_range);
            const std::int64_t normalized_y = std::clamp<std::int64_t>(
                message.mouse.last_y,
                0,
                absolute_range);
            POINT screen = {
                screen_left + static_cast<LONG>(
                    (normalized_x * (screen_width - 1) +
                     absolute_range / 2) /
                    absolute_range),
                screen_top + static_cast<LONG>(
                    (normalized_y * (screen_height - 1) +
                     absolute_range / 2) /
                    absolute_range),
            };
            if (ScreenToClient(target, &screen) != FALSE)
            {
                x = screen.x;
                y = screen.y;
            }
        }
    }
    else if (message.source == input_message_source::raw_input_buffer)
    {
        const std::int32_t origin_x = state.has_client_point
            ? state.client_x
            : message.client_x;
        const std::int32_t origin_y = state.has_client_point
            ? state.client_y
            : message.client_y;
        x = saturating_coordinate_add(origin_x, message.mouse.last_x);
        y = saturating_coordinate_add(origin_y, message.mouse.last_y);
    }
    else if (
        state.has_client_point &&
        state.has_last_os_point &&
        message.client_x == state.last_os_x &&
        message.client_y == state.last_os_y)
    {
        x = saturating_coordinate_add(state.client_x, message.mouse.last_x);
        y = saturating_coordinate_add(state.client_y, message.mouse.last_y);
    }
    clamp_raw_client_point(target, x, y);
    state.client_x = x;
    state.client_y = y;
    state.last_os_x = message.client_x;
    state.last_os_y = message.client_y;
    state.has_client_point = true;
    state.has_last_os_point = true;

    const std::int64_t client_point = encode_client_point(x, y);
    bool routed = false;
    if (!route_normalized_input(
            transport,
            target,
            WM_MOUSEMOVE,
            ordered_raw_mouse_key_state(),
            client_point))
    {
        return raw_projection_result::failed;
    }
    routed = true;

    struct button_projection
    {
        std::uint16_t flag;
        std::uint32_t state_flag;
        std::uint32_t message;
        bool down;
    };
    constexpr button_projection buttons[] = {
        { RI_MOUSE_LEFT_BUTTON_DOWN, MK_LBUTTON, WM_LBUTTONDOWN, true },
        { RI_MOUSE_LEFT_BUTTON_UP, MK_LBUTTON, WM_LBUTTONUP, false },
        { RI_MOUSE_RIGHT_BUTTON_DOWN, MK_RBUTTON, WM_RBUTTONDOWN, true },
        { RI_MOUSE_RIGHT_BUTTON_UP, MK_RBUTTON, WM_RBUTTONUP, false },
        { RI_MOUSE_MIDDLE_BUTTON_DOWN, MK_MBUTTON, WM_MBUTTONDOWN, true },
        { RI_MOUSE_MIDDLE_BUTTON_UP, MK_MBUTTON, WM_MBUTTONUP, false },
    };
    for (const button_projection &button : buttons)
    {
        if ((message.mouse.button_flags & button.flag) == 0)
            continue;
        if (button.down)
            state.mouse_buttons |= button.state_flag;
        else
            state.mouse_buttons &= ~button.state_flag;
        if (!route_normalized_input(
                transport,
                target,
                button.message,
                ordered_raw_mouse_key_state(),
                client_point))
        {
            return raw_projection_result::failed;
        }
    }

    POINT screen = { x, y };
    const bool has_screen_point = ClientToScreen(target, &screen) != FALSE;
    const std::int64_t screen_point = encode_client_point(screen.x, screen.y);
    const auto route_wheel = [&](std::uint16_t flag, std::uint32_t wheel_message) {
        if ((message.mouse.button_flags & flag) == 0)
            return true;
        if (!has_screen_point)
            return true;
        const std::uint32_t wparam = ordered_raw_mouse_key_state() |
            (static_cast<std::uint32_t>(message.mouse.button_data) << 16U);
        return route_normalized_input(
            transport,
            target,
            wheel_message,
            wparam,
            screen_point);
    };
    if (!route_wheel(RI_MOUSE_WHEEL, WM_MOUSEWHEEL) ||
        !route_wheel(RI_MOUSE_HWHEEL, WM_MOUSEHWHEEL))
    {
        return raw_projection_result::failed;
    }
    return routed ? raw_projection_result::routed
                  : raw_projection_result::ignored;
}

raw_projection_result project_raw_keyboard(
    ego_transport *transport,
    const input_message &message,
    HWND target) noexcept
{
    const std::uint32_t key_message = message.keyboard.message;
    const bool down = key_message == WM_KEYDOWN ||
        key_message == WM_SYSKEYDOWN;
    const bool up = key_message == WM_KEYUP ||
        key_message == WM_SYSKEYUP;
    const std::uint32_t virtual_key = message.keyboard.virtual_key;
    if ((!down && !up) || virtual_key == 0 || virtual_key >= 0xFFU)
        return raw_projection_result::ignored;
    if (down == ((message.keyboard.flags & RI_KEY_BREAK) != 0))
        return raw_projection_result::ignored;

    ordered_raw_input_state &state = member().raw_input_state;
    const bool repeated = down && state.keys_down[virtual_key];
    state.keys_down[virtual_key] = down;

    std::uint32_t lparam = 1U |
        ((static_cast<std::uint32_t>(message.keyboard.make_code) & 0xFFU)
         << 16U);
    if ((message.keyboard.flags & RI_KEY_E0) != 0)
        lparam |= 1U << 24U;
    if (key_message == WM_SYSKEYDOWN || key_message == WM_SYSKEYUP)
        lparam |= 1U << 29U;
    if (repeated || up)
        lparam |= 1U << 30U;
    if (up)
        lparam |= 1U << 31U;

    if (!route_normalized_input(
            transport,
            target,
            key_message,
            virtual_key,
            lparam))
    {
        return raw_projection_result::failed;
    }

    const bool dead_key = (message.flags & static_cast<std::uint32_t>(
        input_message_flags::dead_key)) != 0;
    if (down && !dead_key)
    {
        const std::uint32_t character_message = key_message == WM_SYSKEYDOWN
            ? WM_SYSCHAR
            : WM_CHAR;
        const std::size_t text_length = std::min<std::size_t>(
            message.text_length,
            std::size(message.text));
        for (std::size_t index = 0; index < text_length; ++index)
        {
            if (!route_normalized_input(
                    transport,
                    target,
                    character_message,
                    message.text[index],
                    lparam))
            {
                return raw_projection_result::failed;
            }
        }
    }
    return raw_projection_result::routed;
}

raw_projection_result project_raw_input(
    ego_transport *transport,
    const input_message &message,
    HWND primary_target) noexcept
{
    const bool no_legacy = (message.flags & static_cast<std::uint32_t>(
        input_message_flags::no_legacy)) != 0;
    if (!no_legacy)
    {
        if (message.source == input_message_source::raw_input_buffer &&
            !member().raw_rejected_logged.test_and_set(std::memory_order_relaxed))
        {
            char diagnostic[256] = {};
            sprintf_s(
                diagnostic,
                "Electron game overlay rejected buffered raw input without "
                "an exact NOLEGACY registration (flags=0x%x, target=%p, "
                "primary=%p).",
                message.flags,
                reinterpret_cast<void *>(message.target_window),
                primary_target);
            reshade::log::message(
                reshade::log::level::warning,
                diagnostic);
        }
        return raw_projection_result::ignored;
    }

    const bool foreground = (message.flags & static_cast<std::uint32_t>(
        input_message_flags::foreground)) != 0;
    const bool client_point_valid = (message.flags & static_cast<std::uint32_t>(
        input_message_flags::client_point_valid)) != 0;
    HWND const target = static_cast<HWND>(message.target_window);
    if (!foreground ||
        !raw_target_owned_by_primary(target, primary_target) ||
        !target_window_focused(target) ||
        (message.device_type == input_device_type::mouse &&
         !client_point_valid))
    {
        if (!member().raw_rejected_logged.test_and_set(std::memory_order_relaxed))
        {
            char diagnostic[256] = {};
            sprintf_s(
                diagnostic,
                "Electron game overlay rejected authoritative raw input "
                "without an exact foreground target and client route "
                "(source=%u, flags=0x%x, target=%p, primary=%p).",
                static_cast<unsigned int>(message.source),
                message.flags,
                reinterpret_cast<void *>(message.target_window),
                primary_target);
            reshade::log::message(
                reshade::log::level::warning,
                diagnostic);
        }
        return raw_projection_result::ignored;
    }

    const std::uintptr_t target_identity =
        reinterpret_cast<std::uintptr_t>(target);
    if (member().raw_input_state.target_window != target_identity)
    {
        reset_ordered_raw_input_state();
        member().raw_input_state.target_window = target_identity;
    }

    switch (message.device_type)
    {
    case input_device_type::mouse:
        return project_raw_mouse(transport, message, target);
    case input_device_type::keyboard:
        return project_raw_keyboard(transport, message, target);
    default:
        return raw_projection_result::ignored;
    }
}

// Frozen physical-source arbitration precedes all version-private projection.
// It chooses ownership from source records, never from another engine's text,
// pointer normalization output, texture implementation or transport parser.
void drain_cooperative_sources(HWND primary_target)
{
    static std::array<queued_input_message, input_queue_capacity> batch;
    static ordered_raw_input_state pointer;
    static ordered_pointer_state promoted_pointer;
    static ego::cooperative::source_sequence_gate source_order;
    const bool routing = g_cooperative.interception_requested() &&
        !g_cooperative.snapshot_windows().empty() && target_window_focused(primary_target);
    if (!routing) { pointer = {}; promoted_pointer = {}; }
    const auto reset_source = [&]() {
        for (const auto &participant : g_cooperative.snapshot_participants())
        {
            g_cooperative.cancel_owned_input(participant.id, true);
            if (participant.callbacks.release_input != nullptr)
                participant.callbacks.release_input(participant.context);
        }
        static_cast<void>(g_cooperative.clear_capture());
        pointer = {}; promoted_pointer = {};
        queued_input_message discarded;
        while (g_source_input_queue.try_pop(discarded)) {}
        source_order.discard_through(g_cooperative.latest_source_sequence());
    };
    const bool final_reset = g_source_final_reset_pending.exchange(false, std::memory_order_acq_rel);
    const bool overflow_reset = g_source_input_overflow.exchange(false, std::memory_order_acq_rel);
    if (final_reset || overflow_reset)
    {
        reset_source();
        return;
    }
    std::size_t count = 0;
    while (count < batch.size() && g_source_input_queue.try_pop(batch[count])) ++count;
    std::sort(batch.begin(), batch.begin() + count, [](const auto &a, const auto &b) {
        return a.message.sequence < b.message.sequence;
    });
    const auto kept = std::remove_if(batch.begin(), batch.begin() + count, [&](const auto &queued) {
        return source_order.intentionally_discarded(queued.message.sequence);
    });
    count = static_cast<std::size_t>(kept - batch.begin());
    bool ordering_fault = false;
    for (std::size_t index = 0; index < count; ++index)
        if (!source_order.admit(batch[index].message.sequence)) ordering_fault = true;
    if (ordering_fault)
    {
        // Discard before integrating a stale raw delta or pointer projection.
        reset_source();
        return;
    }
    for (std::size_t index = 0; index < count; ++index)
    {
        const auto &queued = batch[index];
        const auto &message = queued.message;
        auto record = freeze_source_input(queued);
        ego::cooperative::window_key owner;
        std::uint32_t projection = 0;
        const auto decide = [&](std::uint32_t code, std::int32_t x, std::int32_t y, std::uint32_t wp) {
            const auto selected = g_cooperative.decide_input(message.sequence, projection++, code, x, y, wp);
            if (projection == 1) owner = selected;
        };
        if (routing && message.source == input_message_source::window_message)
        {
            input_message routed = message;
            bool accepted = true;
            if (is_pointer_mouse_message(message.message))
            {
                const auto own_state = member().pointer_state;
                member().pointer_state = promoted_pointer;
                accepted = translate_pointer_mouse_message(queued, routed);
                promoted_pointer = member().pointer_state;
                member().pointer_state = own_state;
            }
            POINT point = {static_cast<short>(LOWORD(static_cast<DWORD_PTR>(routed.lparam))),
                static_cast<short>(HIWORD(static_cast<DWORD_PTR>(routed.lparam)))};
            if (routed.message == WM_MOUSEWHEEL || routed.message == WM_MOUSEHWHEEL)
                ScreenToClient(static_cast<HWND>(routed.target_window), &point);
            if (accepted && routed.message != WM_INPUT)
                decide(routed.message, point.x, point.y, static_cast<std::uint32_t>(routed.wparam));
        }
        else if (routing)
        {
            const auto required = static_cast<std::uint32_t>(input_message_flags::foreground) |
                static_cast<std::uint32_t>(input_message_flags::no_legacy);
            const HWND target = static_cast<HWND>(message.target_window);
            if ((message.flags & required) == required && raw_target_owned_by_primary(target, primary_target) && target_window_focused(target))
            {
                if (message.device_type == input_device_type::keyboard)
                    decide(message.keyboard.message, 0, 0, message.keyboard.virtual_key);
                else if ((message.flags & static_cast<std::uint32_t>(input_message_flags::client_point_valid)) != 0)
                {
                    if (pointer.target_window != reinterpret_cast<std::uintptr_t>(target))
                    { pointer = {}; pointer.target_window = reinterpret_cast<std::uintptr_t>(target); }
                    std::int32_t x = message.client_x, y = message.client_y;
                    if ((message.mouse.flags & MOUSE_MOVE_ABSOLUTE) != 0)
                    {
                        const bool desktop = (message.mouse.flags & MOUSE_VIRTUAL_DESKTOP) != 0;
                        const auto width = GetSystemMetrics(desktop ? SM_CXVIRTUALSCREEN : SM_CXSCREEN);
                        const auto height = GetSystemMetrics(desktop ? SM_CYVIRTUALSCREEN : SM_CYSCREEN);
                        if (width > 0 && height > 0)
                        {
                            POINT screen = { (desktop ? GetSystemMetrics(SM_XVIRTUALSCREEN) : 0) +
                                static_cast<LONG>((std::clamp<std::int64_t>(message.mouse.last_x, 0, 65535) * (width - 1) + 32767) / 65535),
                                (desktop ? GetSystemMetrics(SM_YVIRTUALSCREEN) : 0) +
                                static_cast<LONG>((std::clamp<std::int64_t>(message.mouse.last_y, 0, 65535) * (height - 1) + 32767) / 65535) };
                            if (ScreenToClient(target, &screen)) { x = screen.x; y = screen.y; }
                        }
                    }
                    else if (message.source == input_message_source::raw_input_buffer ||
                        (pointer.has_client_point && pointer.has_last_os_point &&
                            message.client_x == pointer.last_os_x && message.client_y == pointer.last_os_y))
                    {
                        x = saturating_coordinate_add(pointer.has_client_point ? pointer.client_x : message.client_x, message.mouse.last_x);
                        y = saturating_coordinate_add(pointer.has_client_point ? pointer.client_y : message.client_y, message.mouse.last_y);
                    }
                    clamp_raw_client_point(target, x, y);
                    pointer.client_x = x; pointer.client_y = y; pointer.has_client_point = true;
                    pointer.last_os_x = message.client_x; pointer.last_os_y = message.client_y; pointer.has_last_os_point = true;
                    record.canonical_x = x; record.canonical_y = y; record.canonical_point_valid = 1;
                    decide(WM_MOUSEMOVE, x, y, 0);
                    constexpr std::uint16_t flags[] = {RI_MOUSE_LEFT_BUTTON_DOWN, RI_MOUSE_LEFT_BUTTON_UP,
                        RI_MOUSE_RIGHT_BUTTON_DOWN, RI_MOUSE_RIGHT_BUTTON_UP, RI_MOUSE_MIDDLE_BUTTON_DOWN, RI_MOUSE_MIDDLE_BUTTON_UP};
                    constexpr std::uint32_t codes[] = {WM_LBUTTONDOWN, WM_LBUTTONUP, WM_RBUTTONDOWN, WM_RBUTTONUP, WM_MBUTTONDOWN, WM_MBUTTONUP};
                    for (std::size_t button = 0; button < std::size(flags); ++button)
                        if ((message.mouse.button_flags & flags[button]) != 0) decide(codes[button], x, y, 0);
                }
            }
        }
        const auto focus = g_cooperative.focus();
        record.ownership_valid = 1;
        record.owner_participant = owner.participant; record.owner_window = owner.window_id; record.owner_incarnation = owner.incarnation;
        record.focus_participant = focus.participant; record.focus_window = focus.window_id; record.focus_incarnation = focus.incarnation;
        g_cooperative.broadcast_message(&record, sizeof(record));
    }
}

struct input_consumer_release
{
    ~input_consumer_release()
    {
        member().input_consumer.clear(std::memory_order_release);
    }
};

bool log_input_overflow_once(std::uint64_t dropped)
{
    if (member().overflow_logged.test_and_set(std::memory_order_relaxed))
        return false;

    char message[256] = {};
    sprintf_s(
        message,
        "Electron ReShade input observer queue overflowed (%llu record(s) dropped); "
        "the Electron router was reset before input delivery resumed.",
        static_cast<unsigned long long>(dropped));
    reshade::log::message(reshade::log::level::warning, message);
    return true;
}

void discard_queued_input()
{
    queued_input_message discarded = {};
    while (member().input_queue.try_pop(discarded))
    {
    }
}

bool reset_input_router(ego_transport *transport, HWND target_window)
{
    if (member().participant_id != 0)
        g_cooperative.cancel_owned_input(member().participant_id, true);
    // Advancing the generation makes a producer that was preempted before this
    // reset harmless: its late publication is recognized and discarded.
    member().input_source_cutoff.store(g_cooperative.latest_source_sequence(), std::memory_order_release);
    member().input_generation.fetch_add(1, std::memory_order_acq_rel);
    reset_ordered_pointer_state();
    reset_ordered_raw_input_state();
    member().pointer_route_reset_pending.store(false, std::memory_order_release);
    discard_queued_input();

    const ego_status blur_status = ego_transport_set_target_focused(transport, 0);
    if (blur_status != EGO_STATUS_OK)
    {
        log_transport_error("input-loss blur reset", blur_status);
        publish_input_routing_failure(transport, blur_status);
        member().input_recovery_pending.store(true, std::memory_order_release);
        return false;
    }

    const ego_status focus_status = ego_transport_set_target_focused(
        transport,
        target_window_focused(target_window) ? 1U : 0U);
    if (focus_status != EGO_STATUS_OK)
    {
        log_transport_error("input-loss focus restore", focus_status);
        publish_input_routing_failure(transport, focus_status);
        member().input_recovery_pending.store(true, std::memory_order_release);
        return false;
    }

    member().last_input_sequence = 0;
    member().has_last_input_sequence = false;
    return true;
}

bool recover_dropped_input(ego_transport *transport, HWND target_window)
{
    const bool recovery_requested =
        member().input_recovery_pending.exchange(false, std::memory_order_acq_rel);
    const std::uint64_t dropped =
        member().dropped_input_messages.exchange(0, std::memory_order_acq_rel);
    if (!recovery_requested && dropped == 0)
        return true;

    if (dropped != 0 && log_input_overflow_once(dropped))
    {
        publish_runtime_diagnostic(
            transport,
            EGO_RUNTIME_DIAGNOSTIC_INPUT_ROUTER_RESET);
    }
    if (!reset_input_router(transport, target_window))
        return false;

    // An overflow that raced the reset belongs to a newer generation. Leave it
    // for the next render callback and do not route anything in this one.
    return !member().input_recovery_pending.load(std::memory_order_acquire) &&
        member().dropped_input_messages.load(std::memory_order_acquire) == 0;
}

void drain_input_messages(ego_transport *transport, HWND target_window)
{
    if (transport == nullptr ||
        member().input_consumer.test_and_set(std::memory_order_acquire))
    {
        return;
    }
    const input_consumer_release release_consumer;

    if (member().pointer_route_reset_pending.exchange(false, std::memory_order_acq_rel))
    {
        reset_ordered_pointer_state();
        reset_ordered_raw_input_state();
    }

    if (!recover_dropped_input(transport, target_window))
        return;

    std::size_t count = 0;
    while (count < member().input_batch.size() &&
           member().input_queue.try_pop(member().input_batch[count]))
    {
        ++count;
    }
    if (count == 0)
        return;

    if (member().input_recovery_pending.load(std::memory_order_acquire) ||
        member().dropped_input_messages.load(std::memory_order_acquire) != 0)
    {
        static_cast<void>(recover_dropped_input(transport, target_window));
        return;
    }

    std::sort(
        member().input_batch.begin(),
        member().input_batch.begin() + count,
        [](const queued_input_message &left, const queued_input_message &right) {
            return left.message.sequence < right.message.sequence;
        });

    const std::uint64_t generation =
        member().input_generation.load(std::memory_order_acquire);
    std::uint64_t previous_sequence = member().last_input_sequence;
    bool has_previous_sequence = member().has_last_input_sequence;
    bool ordering_fault = false;
    for (std::size_t index = 0; index < count; ++index)
    {
        const queued_input_message &queued = member().input_batch[index];
        if (queued.generation != generation)
            continue;
        if (has_previous_sequence &&
            queued.message.sequence <= previous_sequence)
        {
            ordering_fault = true;
            break;
        }
        previous_sequence = queued.message.sequence;
        has_previous_sequence = true;
    }

    if (ordering_fault)
    {
        if (!member().order_fault_logged.test_and_set(std::memory_order_relaxed))
        {
            reshade::log::message(
                reshade::log::level::warning,
                "Electron ReShade input records arrived out of global sequence; "
                "the Electron router was reset before delivery resumed.");
            publish_runtime_diagnostic(
                transport,
                EGO_RUNTIME_DIAGNOSTIC_INPUT_ROUTER_RESET);
        }
        static_cast<void>(reset_input_router(transport, target_window));
        return;
    }

    for (std::size_t index = 0; index < count; ++index)
    {
        const queued_input_message &queued = member().input_batch[index];
        if (queued.generation != generation)
            continue;
        if (member().input_recovery_pending.load(std::memory_order_acquire) ||
            member().dropped_input_messages.load(std::memory_order_acquire) != 0)
        {
            static_cast<void>(recover_dropped_input(transport, target_window));
            return;
        }

        input_message routed_message = queued.message;
        g_cooperative_owned_record = queued.ownership_valid;
        g_cooperative_record_owner = queued.owner;
        g_cooperative_record_focus = queued.focus;
        g_cooperative_raw_point_valid = queued.canonical_point_valid;
        g_cooperative_raw_x = queued.canonical_x; g_cooperative_raw_y = queued.canonical_y;
        if (routed_message.source == input_message_source::window_message &&
            !translate_pointer_mouse_message(queued, routed_message))
        {
            member().last_input_sequence = queued.message.sequence;
            member().has_last_input_sequence = true;
            continue;
        }

        const input_message &message = routed_message;
        switch (message.source)
        {
        case input_message_source::window_message:
            if (message.message == WM_INPUT)
            {
                break;
            }
            else
            {
                if (!route_normalized_input(
                    transport, static_cast<HWND>(message.target_window),
                    message.message, message.wparam, message.lparam))
                {
                    if (!member().route_error_logged.test_and_set(std::memory_order_relaxed))
                        log_transport_error("copied input delivery", EGO_STATUS_INTERNAL_ERROR);
                    publish_input_routing_failure(transport, EGO_STATUS_INTERNAL_ERROR);
                    static_cast<void>(reset_input_router(transport, target_window));
                    return;
                }
                break;
            }

        case input_message_source::raw_input:
        case input_message_source::raw_input_buffer:
        {
            const raw_projection_result result = project_raw_input(
                transport,
                message,
                target_window);
            if (result == raw_projection_result::failed)
            {
                static_cast<void>(reset_input_router(transport, target_window));
                return;
            }
            break;
        }

        default:
            static_cast<void>(reset_input_router(transport, target_window));
            return;
        }

        member().last_input_sequence = message.sequence;
        member().has_last_input_sequence = true;
    }
}

void discard_dormant_input()
{
    // Invalidate every in-flight producer/batch even if another render
    // callback currently owns the destructive queue reset below.
    member().input_source_cutoff.store(g_cooperative.latest_source_sequence(), std::memory_order_release);
    member().input_generation.fetch_add(1, std::memory_order_acq_rel);

    if (member().input_consumer.test_and_set(std::memory_order_acquire))
        return;
    const input_consumer_release release_consumer;

    // A copied message may have raced the transport disconnect. Advance the
    // generation before competing for the consumer so a preempted producer
    // cannot republish a stale event into a later producer session.
    reset_ordered_pointer_state();
    reset_ordered_raw_input_state();
    member().pointer_route_reset_pending.store(false, std::memory_order_release);
    discard_queued_input();
    member().dropped_input_messages.store(0, std::memory_order_release);
    member().input_recovery_pending.store(false, std::memory_order_release);
    member().last_input_sequence = 0;
    member().has_last_input_sequence = false;
}

input_phase next_phase(input_phase current, bool desired)
{
    switch (current)
    {
    case input_phase::disabled:
        return desired ? input_phase::arming : input_phase::disabled;
    case input_phase::arming:
        return desired ? input_phase::enabled : input_phase::disarming;
    case input_phase::enabled:
        return desired ? input_phase::enabled : input_phase::disarming;
    case input_phase::disarming:
        return desired ? input_phase::arming : input_phase::disabled;
    default:
        return input_phase::disabled;
    }
}

bool valid_frame(const ego_window_frame_v1 &frame)
{
    if (frame.struct_size != sizeof(frame) ||
        frame.abi_version != EGO_ABI_VERSION ||
        frame.raster_width == 0 ||
        frame.raster_height == 0 ||
        frame.rect_width <= 0 ||
        frame.rect_height <= 0 ||
        frame.rgba == nullptr)
    {
        return false;
    }

    const std::uint64_t minimum_row_pitch =
        static_cast<std::uint64_t>(frame.raster_width) * 4;
    return frame.row_pitch >= minimum_row_pitch &&
        frame.row_pitch <= std::numeric_limits<std::uint32_t>::max() &&
        frame.rgba_len <= std::numeric_limits<std::uint32_t>::max() &&
        frame.rgba_len >= frame.row_pitch * frame.raster_height;
}

void destroy_texture(device *device, electron_texture &texture)
{
    if (texture.view.handle != 0)
        device->destroy_resource_view(texture.view);
    if (texture.texture.handle != 0)
        device->destroy_resource(texture.texture);
    texture = {};
}

std::size_t retire_all_electron_textures(
    effect_runtime *runtime,
    swapchain_data &data)
{
    device *const device = runtime->get_device();
    const std::scoped_lock lock(data.texture_mutex);
    if (data.textures.empty())
        return 0;

    // ReShade keeps the add-on and graphics device loaded after a producer
    // disconnect. Wait for prior draws once, then release every producer-owned
    // resource so the dormant add-on retains no Electron framebuffers.
    const std::size_t retired_count = data.textures.size();
    runtime->get_command_queue()->wait_idle();
    for (auto &[window_id, texture] : data.textures)
    {
        static_cast<void>(window_id);
        destroy_texture(device, texture);
    }
    data.textures.clear();
    return retired_count;
}

void report_frame_upload_failure(
    ego_transport *transport,
    electron_texture &texture,
    const char *message)
{
    if (texture.upload_failure_reported)
        return;

    texture.upload_failure_reported = true;
    reshade::log::message(reshade::log::level::error, message);
    publish_runtime_diagnostic(
        transport,
        EGO_RUNTIME_DIAGNOSTIC_FRAME_UPLOAD_FAILED);
}

bool create_texture(
    effect_runtime *runtime,
    const ego_window_frame_v1 &frame,
    electron_texture &texture,
    ego_transport *transport)
{
    device *const device = runtime->get_device();
    const bool explicit_upload = device->get_api() == device_api::d3d12;
    subresource_data initial_data = {};
    initial_data.data = const_cast<std::uint8_t *>(frame.rgba);
    initial_data.row_pitch = static_cast<std::uint32_t>(frame.row_pitch);
    initial_data.slice_pitch = static_cast<std::uint32_t>(frame.rgba_len);

    const resource_desc desc(
        frame.raster_width,
        frame.raster_height,
        1,
        1,
        format::r8g8b8a8_unorm,
        1,
        memory_heap::gpu_only,
        resource_usage::shader_resource | resource_usage::copy_dest);

    if (!device->create_resource(
            desc,
            explicit_upload ? nullptr : &initial_data,
            explicit_upload ? resource_usage::copy_dest : resource_usage::shader_resource,
            &texture.texture))
    {
        report_frame_upload_failure(
            transport,
            texture,
            "Electron game overlay runtime could not create an Electron texture.");
        return false;
    }

    if (explicit_upload && !ego::initial_texture_upload::upload_d3d12_rgba(
            device, runtime->get_command_queue(), texture.texture, initial_data,
            frame.raster_width, frame.raster_height))
    {
        device->destroy_resource(texture.texture);
        texture.texture = {};
        report_frame_upload_failure(transport, texture,
            "Electron game overlay runtime could not upload its initial texture on the runtime queue.");
        return false;
    }

    if (!device->create_resource_view(
            texture.texture,
            resource_usage::shader_resource,
            resource_view_desc(format::r8g8b8a8_unorm),
            &texture.view))
    {
        device->destroy_resource(texture.texture);
        texture.texture = {};
        report_frame_upload_failure(
            transport,
            texture,
            "Electron game overlay runtime could not create an Electron texture view.");
        return false;
    }

    texture.width = frame.raster_width;
    texture.height = frame.raster_height;
    texture.state_revision = frame.state_revision;
    texture.sequence = frame.sequence;
    texture.upload_failure_reported = false;
    return true;
}

bool update_texture(
    effect_runtime *runtime,
    const ego_window_frame_v1 &frame,
    electron_texture &texture,
    ego_transport *transport)
{
    command_queue *const queue = runtime->get_command_queue();
    if (queue == nullptr)
    {
        report_frame_upload_failure(
            transport,
            texture,
            "Electron game overlay runtime could not acquire the texture upload queue.");
        return false;
    }

    command_list *command_list = queue->get_immediate_command_list();
    if (command_list == nullptr)
    {
        report_frame_upload_failure(
            transport,
            texture,
            "Electron game overlay runtime could not acquire the pre-upload command list.");
        return false;
    }

    subresource_data pixels = {};
    pixels.data = const_cast<std::uint8_t *>(frame.rgba);
    pixels.row_pitch = static_cast<std::uint32_t>(frame.row_pitch);
    pixels.slice_pitch = static_cast<std::uint32_t>(frame.rgba_len);

    command_list->barrier(
        texture.texture,
        resource_usage::shader_resource,
        resource_usage::copy_dest);
    queue->flush_immediate_command_list();

    runtime->get_device()->update_texture_region(pixels, texture.texture, 0);

    command_list = queue->get_immediate_command_list();
    if (command_list == nullptr)
    {
        report_frame_upload_failure(
            transport,
            texture,
            "Electron game overlay runtime could not acquire the post-upload command list.");
        return false;
    }
    command_list->barrier(
        texture.texture,
        resource_usage::copy_dest,
        resource_usage::shader_resource);
    queue->flush_immediate_command_list();

    texture.state_revision = frame.state_revision;
    texture.sequence = frame.sequence;
    texture.upload_failure_reported = false;
    return true;
}

std::uint32_t transport_graphics_api(device_api api) noexcept
{
    switch (api)
    {
    case device_api::d3d9:
        return EGO_GRAPHICS_API_D3D9;
    case device_api::d3d10:
        return EGO_GRAPHICS_API_D3D10;
    case device_api::d3d11:
        return EGO_GRAPHICS_API_D3D11;
    case device_api::d3d12:
        return EGO_GRAPHICS_API_D3D12;
    case device_api::opengl:
        return EGO_GRAPHICS_API_OPENGL;
    case device_api::vulkan:
        return EGO_GRAPHICS_API_VULKAN;
    default:
        return EGO_GRAPHICS_API_UNKNOWN;
    }
}

bool positive_rect_dimensions(
    const RECT &rect,
    std::uint32_t &width,
    std::uint32_t &height) noexcept
{
    const std::int64_t signed_width =
        static_cast<std::int64_t>(rect.right) - rect.left;
    const std::int64_t signed_height =
        static_cast<std::int64_t>(rect.bottom) - rect.top;
    if (signed_width <= 0 || signed_height <= 0 ||
        signed_width > std::numeric_limits<std::uint32_t>::max() ||
        signed_height > std::numeric_limits<std::uint32_t>::max())
    {
        return false;
    }

    width = static_cast<std::uint32_t>(signed_width);
    height = static_cast<std::uint32_t>(signed_height);
    return true;
}

class scoped_thread_dpi_awareness
{
public:
    scoped_thread_dpi_awareness() noexcept
        : previous_context_(SetThreadDpiAwarenessContext(
              DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2))
    {
    }

    scoped_thread_dpi_awareness(const scoped_thread_dpi_awareness &) = delete;
    scoped_thread_dpi_awareness &operator=(
        const scoped_thread_dpi_awareness &) = delete;

    ~scoped_thread_dpi_awareness()
    {
        if (previous_context_ != nullptr)
            static_cast<void>(SetThreadDpiAwarenessContext(previous_context_));
    }

    [[nodiscard]] bool active() const noexcept
    {
        return previous_context_ != nullptr;
    }

private:
    DPI_AWARENESS_CONTEXT previous_context_ = nullptr;
};

std::uint64_t next_swapchain_ownership_token() noexcept
{
    std::uint64_t current =
        member().swapchain_ownership_token_sequence.load(std::memory_order_relaxed);
    while (current != std::numeric_limits<std::uint64_t>::max())
    {
        const std::uint64_t next = current + 1;
        if (member().swapchain_ownership_token_sequence.compare_exchange_weak(
                current,
                next,
                std::memory_order_relaxed,
                std::memory_order_relaxed))
        {
            return next;
        }
    }
    return 0;
}

bool owns_primary_swapchain(const swapchain_data &data) noexcept
{
    return data.ownership_token != 0 &&
        member().primary_swapchain_token.load(std::memory_order_acquire) ==
            data.ownership_token;
}

bool claim_primary_swapchain(const swapchain_data &data) noexcept
{
    if (data.ownership_token == 0)
        return false;

    std::uint64_t expected = 0;
    if (member().primary_swapchain_token.compare_exchange_strong(
            expected,
            data.ownership_token,
            std::memory_order_acq_rel,
            std::memory_order_acquire))
    {
        return true;
    }
    return expected == data.ownership_token;
}

void release_primary_swapchain(const swapchain_data &data) noexcept
{
    if (data.ownership_token == 0)
        return;

    std::uint64_t expected = data.ownership_token;
    static_cast<void>(member().primary_swapchain_token.compare_exchange_strong(
        expected,
        0,
        std::memory_order_release,
        std::memory_order_relaxed));
}

std::uint64_t next_target_surface_revision() noexcept
{
    std::uint64_t current =
        member().target_surface_revision_sequence.load(std::memory_order_relaxed);
    while (current != std::numeric_limits<std::uint64_t>::max())
    {
        const std::uint64_t next = current + 1;
        if (member().target_surface_revision_sequence.compare_exchange_weak(
                current,
                next,
                std::memory_order_relaxed,
                std::memory_order_relaxed))
        {
            return next;
        }
    }

    // Do not wrap to zero or publish an event older than one already observed.
    return 0;
}

bool equivalent_target_surface(
    const ego_target_surface_v1 &left,
    const ego_target_surface_v1 &right) noexcept
{
    return left.struct_size == right.struct_size &&
        left.abi_version == right.abi_version &&
        left.surface_id == right.surface_id &&
        left.target_hwnd == right.target_hwnd &&
        left.monitor_handle == right.monitor_handle &&
        left.graphics_api == right.graphics_api &&
        left.render_width == right.render_width &&
        left.render_height == right.render_height &&
        left.client_screen_x == right.client_screen_x &&
        left.client_screen_y == right.client_screen_y &&
        left.client_width == right.client_width &&
        left.client_height == right.client_height &&
        left.window_screen_x == right.window_screen_x &&
        left.window_screen_y == right.window_screen_y &&
        left.window_width == right.window_width &&
        left.window_height == right.window_height &&
        left.dpi_x == right.dpi_x &&
        left.dpi_y == right.dpi_y &&
        left.monitor_x == right.monitor_x &&
        left.monitor_y == right.monitor_y &&
        left.monitor_width == right.monitor_width &&
        left.monitor_height == right.monitor_height &&
        left.work_x == right.work_x &&
        left.work_y == right.work_y &&
        left.work_width == right.work_width &&
        left.work_height == right.work_height &&
        left.state_flags == right.state_flags;
}

bool capture_target_surface(
    effect_runtime *runtime,
    const swapchain_data &data,
    ego_target_surface_v1 &surface) noexcept
{
    const auto surface_id = static_cast<std::uint64_t>(
        reinterpret_cast<std::uintptr_t>(runtime));
    if (surface_id == 0)
        return false;

    const scoped_thread_dpi_awareness dpi_awareness;
    if (!dpi_awareness.active())
        return false;

    const HWND runtime_window = static_cast<HWND>(runtime->get_hwnd());
    const HWND window = runtime_window != nullptr ? runtime_window : data.window;
    if (window == nullptr || IsWindow(window) == FALSE)
        return false;

    std::uint32_t render_width = 0;
    std::uint32_t render_height = 0;
    runtime->get_screenshot_width_and_height(&render_width, &render_height);
    if (render_width == 0 || render_height == 0)
        return false;

    RECT client_rect = {};
    std::uint32_t client_width = 0;
    std::uint32_t client_height = 0;
    if (GetClientRect(window, &client_rect) == FALSE ||
        !positive_rect_dimensions(client_rect, client_width, client_height))
    {
        return false;
    }

    POINT client_origin = { client_rect.left, client_rect.top };
    if (ClientToScreen(window, &client_origin) == FALSE)
        return false;

    RECT window_rect = {};
    std::uint32_t window_width = 0;
    std::uint32_t window_height = 0;
    if (GetWindowRect(window, &window_rect) == FALSE ||
        !positive_rect_dimensions(window_rect, window_width, window_height))
    {
        window_rect.left = client_origin.x;
        window_rect.top = client_origin.y;
        window_width = client_width;
        window_height = client_height;
    }

    const HMONITOR monitor = MonitorFromWindow(window, MONITOR_DEFAULTTONEAREST);
    if (monitor == nullptr)
        return false;

    MONITORINFO monitor_info = {};
    monitor_info.cbSize = sizeof(monitor_info);
    std::uint32_t monitor_width = 0;
    std::uint32_t monitor_height = 0;
    std::uint32_t work_width = 0;
    std::uint32_t work_height = 0;
    if (GetMonitorInfoW(monitor, &monitor_info) == FALSE ||
        !positive_rect_dimensions(
            monitor_info.rcMonitor,
            monitor_width,
            monitor_height) ||
        !positive_rect_dimensions(
            monitor_info.rcWork,
            work_width,
            work_height))
    {
        return false;
    }

    std::uint32_t state_flags = 0;
    const HWND foreground = GetForegroundWindow();
    const HWND root = GetAncestor(window, GA_ROOT);
    if (foreground == window || (root != nullptr && foreground == root))
        state_flags |= EGO_TARGET_SURFACE_FOCUSED;
    if (IsIconic(window) != FALSE)
        state_flags |= EGO_TARGET_SURFACE_MINIMIZED;
    if (IsWindowVisible(window) != FALSE)
        state_flags |= EGO_TARGET_SURFACE_VISIBLE;

    const std::int64_t client_right =
        static_cast<std::int64_t>(client_origin.x) + client_width;
    const std::int64_t client_bottom =
        static_cast<std::int64_t>(client_origin.y) + client_height;
    if (client_origin.x <= monitor_info.rcMonitor.left &&
        client_origin.y <= monitor_info.rcMonitor.top &&
        client_right >= monitor_info.rcMonitor.right &&
        client_bottom >= monitor_info.rcMonitor.bottom)
    {
        state_flags |= EGO_TARGET_SURFACE_FULLSCREEN;
    }

    std::uint32_t dpi = GetDpiForWindow(window);
    if (dpi == 0)
        dpi = USER_DEFAULT_SCREEN_DPI;

    surface = {};
    surface.struct_size = sizeof(surface);
    surface.abi_version = EGO_ABI_VERSION;
    surface.surface_id = surface_id;
    surface.target_hwnd = static_cast<std::uint64_t>(
        reinterpret_cast<std::uintptr_t>(window));
    surface.monitor_handle = static_cast<std::uint64_t>(
        reinterpret_cast<std::uintptr_t>(monitor));
    surface.graphics_api = transport_graphics_api(runtime->get_device()->get_api());
    surface.render_width = render_width;
    surface.render_height = render_height;
    surface.client_screen_x = client_origin.x;
    surface.client_screen_y = client_origin.y;
    surface.client_width = client_width;
    surface.client_height = client_height;
    surface.window_screen_x = window_rect.left;
    surface.window_screen_y = window_rect.top;
    surface.window_width = window_width;
    surface.window_height = window_height;
    surface.dpi_x = dpi;
    surface.dpi_y = dpi;
    surface.monitor_x = monitor_info.rcMonitor.left;
    surface.monitor_y = monitor_info.rcMonitor.top;
    surface.monitor_width = monitor_width;
    surface.monitor_height = monitor_height;
    surface.work_x = monitor_info.rcWork.left;
    surface.work_y = monitor_info.rcWork.top;
    surface.work_width = work_width;
    surface.work_height = work_height;
    surface.state_flags = state_flags;
    return true;
}

void publish_target_surface(
    swapchain_data &data,
    ego_target_surface_v1 surface)
{
    if (data.has_target_surface &&
        equivalent_target_surface(data.last_target_surface, surface))
    {
        return;
    }

    surface.revision = next_target_surface_revision();
    if (surface.revision == 0)
        return;
    data.target_surface_revision = surface.revision;
    const ego_status status =
        ego_transport_publish_target_surface(data.transport, &surface);
    if (status != EGO_STATUS_OK)
    {
        if (status != data.last_target_surface_error)
        {
            data.last_target_surface_error = status;
            log_transport_error("target-surface publication", status);
        }
        return;
    }

    data.last_target_surface_error = EGO_STATUS_OK;
    data.last_target_surface = surface;
    data.target_surface_id = surface.surface_id;
    data.has_target_surface = true;

    if (!member().target_surface_logged.test_and_set(std::memory_order_relaxed))
    {
        char message[256] = {};
        sprintf_s(
            message,
            "Electron game overlay runtime published its first target-surface "
            "telemetry (surface %llu, API 0x%x, render %ux%u, client %ux%u).",
            static_cast<unsigned long long>(surface.surface_id),
            surface.graphics_api,
            surface.render_width,
            surface.render_height,
            surface.client_width,
            surface.client_height);
        reshade::log::message(reshade::log::level::info, message);
    }
}

bool update_primary_target_surface(
    swapchain_data &data,
    const ego_target_surface_v1 &surface,
    bool captured)
{
    if (data.transport == nullptr)
        return false;

    if (!owns_primary_swapchain(data))
    {
        // Offscreen and otherwise incomplete runtimes never reserve primary
        // ownership. The first presenter with an exact usable target wins.
        if (!captured || !claim_primary_swapchain(data))
            return false;
    }

    // A transient geometry query failure does not transfer ownership. The
    // stable owner continues rendering and will republish on a later frame.
    if (captured)
        publish_target_surface(data, surface);
    return true;
}

HWND primary_target_window(const swapchain_data &data) noexcept
{
    if (data.has_target_surface && data.last_target_surface.target_hwnd != 0)
    {
        return reinterpret_cast<HWND>(static_cast<std::uintptr_t>(
            data.last_target_surface.target_hwnd));
    }
    return data.window;
}

void remove_target_surface(swapchain_data &data)
{
    if (data.transport == nullptr || !data.has_target_surface ||
        data.target_surface_id == 0)
    {
        return;
    }

    const std::uint64_t removal_revision = next_target_surface_revision();
    if (removal_revision == 0)
        return;
    data.target_surface_revision = removal_revision;
    const ego_status status = ego_transport_remove_target_surface(
        data.transport,
        data.target_surface_id,
        removal_revision);
    if (status != EGO_STATUS_OK)
        log_transport_error("target-surface removal", status);

    data.has_target_surface = false;
}

void publish_render_fps(swapchain_data &data)
{
    if (data.transport == nullptr)
        return;

    constexpr std::uint64_t publication_interval_ms = 1000;
    const std::uint64_t now = GetTickCount64();
    if (member().logical_fps_publication_tick != 0 &&
        now - member().logical_fps_publication_tick < publication_interval_ms)
    {
        return;
    }

    const float fps = ImGui::GetIO().Framerate;
    if (!std::isfinite(fps) || fps <= 0.0f)
        return;

    const double scaled_fps = std::round(static_cast<double>(fps) * 1000.0);
    const std::uint32_t fps_milli = static_cast<std::uint32_t>(std::min(
        scaled_fps,
        static_cast<double>(std::numeric_limits<std::uint32_t>::max())));
    if (fps_milli == 0)
        return;

    member().logical_fps_publication_tick = now;
    const ego_status status = ego_transport_publish_fps(data.transport, fps_milli);
    if (status != EGO_STATUS_OK)
    {
        if (status != data.last_fps_error)
        {
            data.last_fps_error = status;
            log_transport_error("injected render FPS publication", status);
        }
        return;
    }

    data.last_fps_error = EGO_STATUS_OK;
    if (!member().fps_logged.test_and_set(std::memory_order_relaxed))
    {
        char message[192] = {};
        sprintf_s(
            message,
            "Electron game overlay runtime published its first injected render FPS "
            "sample (%.3f FPS).",
            static_cast<double>(fps_milli) / 1000.0);
        reshade::log::message(reshade::log::level::info, message);
    }
}

void initialize_own_surface_transport(swapchain_data &data, bool publish_ready = true)
{
    const std::scoped_lock initialization_lock(data.transport_initialization_mutex);
    // A folder-loaded module is only an adapter until its owning application
    // explicitly binds a private stage. Preserve the deferred initialization
    // state so that activation can retain its transport on a later frame.
    if ((is_preloaded_member() || can_drive_dormant_adapter()) &&
        member().participant_id.load(std::memory_order_acquire) == 0)
        return;
    if (!data.transport_initialization_complete)
    {
        data.transport = retain_transport();
        data.transport_initialization_complete = true;
    }
    if (publish_ready && !data.swapchain_ready_published)
    {
        publish_runtime_diagnostic(data.transport, EGO_RUNTIME_DIAGNOSTIC_SWAPCHAIN_READY);
        data.swapchain_ready_published = true;
    }
}

bool advance_own_surface_startup(swapchain_data &data)
{
    if (!owns_dispatcher_surface())
    {
        initialize_own_surface_transport(data);
        return true;
    }
    const auto status = advance_official_hook_setup(data);
    if (status == official_setup_status::pending)
    {
        if (!g_adapter_window_ready.load(std::memory_order_acquire))
            g_source_final_reset_pending.store(true, std::memory_order_release);
        return false;
    }
    // A bounded failure must reach the supplying producer, while a later UI
    // acknowledgement can still rescue this pinned dispatcher for future apps.
    initialize_own_surface_transport(data, status == official_setup_status::ready);
    if (status == official_setup_status::failed)
    {
        if (!data.official_hook_failure_reported &&
            (!is_preloaded_member() || data.transport != nullptr))
        {
            data.official_hook_failure_reported = true;
            if (auto *const owner = get_official_hook_owner(data))
                log_official_hook_failure(data.window,
                    owner->thread_id.load(std::memory_order_acquire),
                    owner->install_error.load(std::memory_order_acquire));
            publish_input_routing_failure(data.transport, EGO_STATUS_INITIALIZATION_FAILED);
        }
        return false;
    }
    return true;
}

void initialize_own_surface(device_object *surface, HWND window)
{
    if (member().participant_id == 0 && initialize_automatic_member() != ERROR_SUCCESS &&
        !can_drive_dormant_adapter())
        return;

    swapchain_data *data = nullptr;
    {
        const std::scoped_lock lock(member().swapchain_states_mutex);
        auto [entry, inserted] = member().swapchain_states.try_emplace(surface->get_native());
        if (!inserted)
            return;
        entry->second = std::make_unique<swapchain_data>();
        data = entry->second.get();
    }
    data->window = window;
    data->ownership_token = next_swapchain_ownership_token();
    if (owns_dispatcher_surface())
        static_cast<void>(retain_official_hook_owner(*data));
    static_cast<void>(advance_own_surface_startup(*data));
}

void on_init_swapchain(swapchain *surface, bool resize)
{
    if (!resize)
    {
        static_cast<void>(g_cooperative.observe_surface(surface->get_native(),
            reinterpret_cast<std::uintptr_t>(surface->get_hwnd())));
        initialize_own_surface(surface, static_cast<HWND>(surface->get_hwnd()));
    }
}

void destroy_own_swapchain(swapchain *swapchain, bool resize)
{
    if (resize)
        return;

    auto *const data = find_swapchain_data(swapchain);
    if (data == nullptr)
        return;

    ego_transport *const transport = data->transport;
    remove_target_surface(*data);
    release_official_hook_owner(*data);
    // ReShade destroys the effect runtime (and the callback below retires its
    // queue-owned resources) before this final non-resize swap-chain event.
    // Publish zero only after every old-owner operation is complete so another
    // presenter cannot promote during teardown.
    release_primary_swapchain(*data);
    {
        const std::scoped_lock lock(member().swapchain_states_mutex);
        member().swapchain_states.erase(swapchain->get_native());
    }
    release_transport(transport);
}

#if 0
// Retained temporarily as compile-time-disabled reference for the API-18
// frame-state adapter. Official hosts now use the message hook below instead:
// frame polling cannot preserve a complete down/up between presentations.
bool route_official_input_message(
    swapchain_data &data,
    std::uint32_t message,
    std::uint64_t wparam,
    std::int64_t lparam)
{
    const ego_status status = ego_transport_route_window_message(
        data.transport,
        reinterpret_cast<std::uintptr_t>(data.window),
        message,
        wparam,
        lparam);
    if (status == EGO_STATUS_OK)
        return true;

    if (!member().route_error_logged.test_and_set(std::memory_order_relaxed))
        log_transport_error("official ReShade input delivery", status);
    publish_input_routing_failure(data.transport, status);
    static_cast<void>(reset_input_router(data.transport));
    data.official_input = {};
    return false;
}

std::uint32_t official_mouse_key_state(
    const ImGuiIO &io,
    const std::array<bool, 5> &mouse_down)
{
    std::uint32_t state = 0;
    if (mouse_down[ImGuiMouseButton_Left])
        state |= MK_LBUTTON;
    if (mouse_down[ImGuiMouseButton_Right])
        state |= MK_RBUTTON;
    if (mouse_down[ImGuiMouseButton_Middle])
        state |= MK_MBUTTON;
    if (io.KeyCtrl)
        state |= MK_CONTROL;
    if (io.KeyShift)
        state |= MK_SHIFT;
    return state;
}

bool is_extended_virtual_key(std::uint32_t virtual_key)
{
    switch (virtual_key)
    {
    case VK_RCONTROL:
    case VK_RMENU:
    case VK_INSERT:
    case VK_DELETE:
    case VK_HOME:
    case VK_END:
    case VK_PRIOR:
    case VK_NEXT:
    case VK_LEFT:
    case VK_UP:
    case VK_RIGHT:
    case VK_DOWN:
    case VK_NUMLOCK:
    case VK_DIVIDE:
    case VK_SNAPSHOT:
    case VK_LWIN:
    case VK_RWIN:
    case VK_APPS:
        return true;
    default:
        return false;
    }
}

std::uint32_t official_keyboard_lparam(
    std::uint32_t virtual_key,
    bool down,
    bool repeated,
    bool system_key)
{
    const std::uint32_t scan_code =
        MapVirtualKeyW(virtual_key, MAPVK_VK_TO_VSC) & 0xFFU;
    std::uint32_t lparam = 1U | (scan_code << 16U);
    if (is_extended_virtual_key(virtual_key))
        lparam |= 1U << 24U;
    if (system_key)
        lparam |= 1U << 29U;
    if (repeated || !down)
        lparam |= 1U << 30U;
    if (!down)
        lparam |= 1U << 31U;
    return lparam;
}

void route_official_reshade_input(swapchain_data &data)
{
    if (g_has_private_input_observer || data.transport == nullptr)
        return;

    official_input_state &state = data.official_input;
    const HWND foreground = GetForegroundWindow();
    const HWND root = GetAncestor(data.window, GA_ROOT);
    const bool target_focused =
        foreground != nullptr &&
        (foreground == data.window || (root != nullptr && foreground == root));
    if (data.phase != input_phase::enabled || !target_focused)
    {
        state = {};
        return;
    }

    ImGuiIO &io = ImGui::GetIO();
    std::array<bool, 5> mouse_down = {};
    for (std::size_t index = 0; index < mouse_down.size(); ++index)
        mouse_down[index] = io.MouseDown[index];

    if (ImGui::IsMousePosValid(&io.MousePos))
    {
        const auto clamp_coordinate = [](float value) {
            return static_cast<std::int32_t>(std::clamp(
                std::lround(static_cast<double>(value)),
                static_cast<long>(std::numeric_limits<std::int16_t>::min()),
                static_cast<long>(std::numeric_limits<std::int16_t>::max())));
        };
        const std::int32_t mouse_x = clamp_coordinate(io.MousePos.x);
        const std::int32_t mouse_y = clamp_coordinate(io.MousePos.y);
        if (!state.has_mouse_position ||
            state.mouse_x != mouse_x ||
            state.mouse_y != mouse_y)
        {
            if (!route_official_input_message(
                    data,
                    WM_MOUSEMOVE,
                    official_mouse_key_state(io, mouse_down),
                    encode_client_point(mouse_x, mouse_y)))
            {
                return;
            }
        }
        state.mouse_x = mouse_x;
        state.mouse_y = mouse_y;
        state.has_mouse_position = true;
    }

    struct mouse_button_message
    {
        std::size_t index;
        std::uint32_t down;
        std::uint32_t up;
    };
    constexpr mouse_button_message mouse_button_messages[] = {
        { ImGuiMouseButton_Left, WM_LBUTTONDOWN, WM_LBUTTONUP },
        { ImGuiMouseButton_Right, WM_RBUTTONDOWN, WM_RBUTTONUP },
        { ImGuiMouseButton_Middle, WM_MBUTTONDOWN, WM_MBUTTONUP },
    };
    if (state.has_mouse_position)
    {
        const std::int64_t point =
            encode_client_point(state.mouse_x, state.mouse_y);
        for (const mouse_button_message &mapping : mouse_button_messages)
        {
            const bool clicked = ImGui::IsMouseClicked(
                static_cast<ImGuiMouseButton>(mapping.index),
                false);
            const bool released = ImGui::IsMouseReleased(
                static_cast<ImGuiMouseButton>(mapping.index));
            const bool changed =
                mouse_down[mapping.index] != state.mouse_down[mapping.index];

            if (clicked)
            {
                auto event_buttons = state.mouse_down;
                event_buttons[mapping.index] = true;
                if (!route_official_input_message(
                        data,
                        mapping.down,
                        official_mouse_key_state(io, event_buttons),
                        point))
                {
                    return;
                }
            }
            if (released)
            {
                auto event_buttons = state.mouse_down;
                event_buttons[mapping.index] = false;
                if (!route_official_input_message(
                        data,
                        mapping.up,
                        official_mouse_key_state(io, event_buttons),
                        point))
                {
                    return;
                }
            }
            if (!clicked && !released && changed)
            {
                if (!route_official_input_message(
                        data,
                        mouse_down[mapping.index] ? mapping.down : mapping.up,
                        official_mouse_key_state(io, mouse_down),
                        point))
                {
                    return;
                }
            }
        }

        POINT wheel_point = { state.mouse_x, state.mouse_y };
        const bool has_wheel_screen_point =
            ClientToScreen(data.window, &wheel_point) != FALSE;
        const auto route_wheel = [&](std::uint32_t message, double units) {
            if (units == 0.0)
                return true;
            if (!has_wheel_screen_point)
                return false;
            const long scaled = std::clamp(
                std::lround(units * WHEEL_DELTA),
                static_cast<long>(std::numeric_limits<std::int16_t>::min()),
                static_cast<long>(std::numeric_limits<std::int16_t>::max()));
            const std::uint32_t wparam =
                official_mouse_key_state(io, mouse_down) |
                (static_cast<std::uint32_t>(
                     static_cast<std::uint16_t>(scaled)) << 16U);
            return route_official_input_message(
                data,
                message,
                wparam,
                encode_client_point(
                    std::clamp(
                        wheel_point.x,
                        static_cast<LONG>(
                            std::numeric_limits<std::int16_t>::min()),
                        static_cast<LONG>(
                            std::numeric_limits<std::int16_t>::max())),
                    std::clamp(
                        wheel_point.y,
                        static_cast<LONG>(
                            std::numeric_limits<std::int16_t>::min()),
                        static_cast<LONG>(
                            std::numeric_limits<std::int16_t>::max()))));
        };
        if (!route_wheel(WM_MOUSEWHEEL, io.MouseWheel) ||
            !route_wheel(WM_MOUSEHWHEEL, -static_cast<double>(io.MouseWheelH)))
        {
            return;
        }
    }

    for (std::size_t index = 0; index < std::size(official_key_mappings); ++index)
    {
        const official_key_mapping &mapping = official_key_mappings[index];
        const bool down = ImGui::IsKeyDown(mapping.key);
        const bool changed = down != state.keys_down[index];
        const bool pressed = ImGui::IsKeyPressed(mapping.key, false);
        const bool released = ImGui::IsKeyReleased(mapping.key);
        const bool repeated =
            down &&
            !pressed &&
            !released &&
            ImGui::IsKeyPressed(mapping.key, true);
        if (!changed && !pressed && !released && !repeated)
            continue;

        const bool system_key =
            io.KeyAlt ||
            mapping.virtual_key == VK_LMENU ||
            mapping.virtual_key == VK_RMENU;
        const auto route_key = [&](bool event_down, bool event_repeated) {
            return route_official_input_message(
                data,
                event_down
                    ? (system_key ? WM_SYSKEYDOWN : WM_KEYDOWN)
                    : (system_key ? WM_SYSKEYUP : WM_KEYUP),
                mapping.virtual_key,
                official_keyboard_lparam(
                    mapping.virtual_key,
                    event_down,
                    event_repeated,
                    system_key));
        };
        if (pressed && !route_key(true, false))
        {
            return;
        }
        if (released && !route_key(false, false))
            return;
        if (!pressed && !released && changed && !route_key(down, false))
            return;
        if (repeated && !route_key(true, true))
            return;
        state.keys_down[index] = down;
    }

    const std::uint32_t character_message = io.KeyAlt ? WM_SYSCHAR : WM_CHAR;
    for (int index = 0; index < io.InputQueueCharacters.Size; ++index)
    {
        if (!route_official_input_message(
                data,
                character_message,
                io.InputQueueCharacters[index],
                1))
        {
            return;
        }
    }

    state.mouse_down = mouse_down;
}

#endif

void update_input_ownership(effect_runtime *runtime, swapchain_data &data)
{
    if (data.transport == nullptr)
        return;

    if (!g_has_private_input_observer && member().participant_id == 0)
    {
        official_hook_owner *const owner = get_official_hook_owner(data);
        if (owner == nullptr ||
            !owner->hook_ready.load(std::memory_order_acquire))
        {
            data.phase = input_phase::disabled;
            if (!data.official_hook_failure_reported)
            {
                data.official_hook_failure_reported = true;
                publish_input_routing_failure(
                    data.transport,
                    EGO_STATUS_INITIALIZATION_FAILED);
            }
            static_cast<void>(ego_transport_apply_input_filter(
                data.transport,
                0,
                0));
            return;
        }
        if (!claim_official_input_owner(data))
            return;
    }

    ego_status status = ego_transport_set_target_focused(
        data.transport,
        target_window_focused(primary_target_window(data)) ? 1U : 0U);
    if (status != EGO_STATUS_OK && status != data.last_focus_error)
    {
        data.last_focus_error = status;
        log_transport_error("focus publication", status);
        publish_input_routing_failure(data.transport, status);
    }
    else if (status == EGO_STATUS_OK)
    {
        data.last_focus_error = EGO_STATUS_OK;
    }

    std::uint32_t desired = 0;
    status = ego_transport_desired_interception(data.transport, &desired);
    if (status != EGO_STATUS_OK)
    {
        if (status != data.last_interception_error)
        {
            data.last_interception_error = status;
            log_transport_error("interception query", status);
            publish_input_routing_failure(data.transport, status);
        }
        desired = 0;
    }
    else
    {
        data.last_interception_error = EGO_STATUS_OK;
    }

    data.phase = next_phase(data.phase, desired != 0);
    if (!g_has_private_input_observer && member().participant_id == 0)
        publish_official_hook_phase(data, data.phase);
    if (data.phase != input_phase::disabled)
        runtime->block_input_next_frame();

    const bool routing_enabled = data.phase == input_phase::enabled;
    if (!routing_enabled)
        member().pointer_route_reset_pending.store(true, std::memory_order_release);
    const bool acknowledge =
        data.phase == input_phase::disabled || data.phase == input_phase::enabled;
    status = ego_transport_apply_input_filter(
        data.transport,
        routing_enabled ? 1U : 0U,
        acknowledge ? 1U : 0U);
    if (status != EGO_STATUS_OK && status != data.last_filter_error)
    {
        data.last_filter_error = status;
        log_transport_error("input filter publication", status);
        publish_input_routing_failure(data.transport, status);
    }
    else if (status == EGO_STATUS_OK)
    {
        data.last_filter_error = EGO_STATUS_OK;
    }

    // Participant callbacks never own the process cursor or suppression hook.
    // The event adapter applies the aggregate state once after all members.
    if (member().participant_id != 0)
        return;

    std::int32_t cursor_code = -1;
    if (auto *owner = get_official_hook_owner(data))
    {
        std::int32_t &code = cursor_code;
        // ReShade freezes GetCursorPos for intercepted game polling. CURSORINFO
        // gives the real screen point, so hover follows the routed OS pointer.
        CURSORINFO cursor_info = { sizeof(CURSORINFO) };
        if (routing_enabled && GetCursorInfo(&cursor_info))
        {
            POINT point = cursor_info.ptScreenPos;
            if (ScreenToClient(data.window, &point))
                static_cast<void>(ego_transport_cursor_at(data.transport, point.x, point.y, &code));
        }
        const auto previous = owner->cursor_code.exchange(code, std::memory_order_acq_rel);
        if (previous != code)
            PostMessageW(reinterpret_cast<HWND>(owner->root_window.load(std::memory_order_acquire)),
                g_official_control_message.load(std::memory_order_acquire), official_cursor_update, 0);
    }
    ImGuiIO &io = ImGui::GetIO();
    CURSORINFO visible_cursor = { sizeof(CURSORINFO) };
    const bool native_cursor_visible = GetCursorInfo(&visible_cursor) &&
        (visible_cursor.flags & CURSOR_SHOWING) != 0;
    // Some games continually hide the hardware cursor. Retain the existing
    // in-game fallback, using Chromium's shape rather than a permanent arrow.
    io.MouseDrawCursor = cursor_code > 0 && !native_cursor_visible;
    if (io.MouseDrawCursor)
    {
        ImGuiMouseCursor shape = ImGuiMouseCursor_Arrow;
        switch (cursor_code)
        {
        case 32513: shape = ImGuiMouseCursor_TextInput; break;
        case 32649: shape = ImGuiMouseCursor_Hand; break;
        case 32642: shape = ImGuiMouseCursor_ResizeNWSE; break;
        case 32643: shape = ImGuiMouseCursor_ResizeNESW; break;
        case 32644: shape = ImGuiMouseCursor_ResizeEW; break;
        case 32645: shape = ImGuiMouseCursor_ResizeNS; break;
        case 32646: shape = ImGuiMouseCursor_ResizeAll; break;
        case 32648: shape = ImGuiMouseCursor_NotAllowed; break;
        }
        ImGui::SetMouseCursor(shape);
    }
}

bool transport_session_epoch(
    swapchain_data &data,
    std::uint64_t &epoch)
{
    if (data.transport == nullptr)
        return false;

    const ego_status status =
        ego_transport_session_epoch(data.transport, &epoch);
    if (status != EGO_STATUS_OK)
    {
        if (status != data.last_session_query_error)
        {
            data.last_session_query_error = status;
            log_transport_error("producer-session query", status);
            publish_input_routing_failure(data.transport, status);
        }
        return false;
    }

    data.last_session_query_error = EGO_STATUS_OK;
    return true;
}

bool producer_session_active(std::uint64_t epoch)
{
    return (epoch & EGO_SESSION_EPOCH_ACTIVE_BIT) != 0;
}

void deactivate_input(swapchain_data &data, bool reset_imgui_cursor, bool acknowledge)
{
    if (auto *owner = member().participant_id == 0 ? get_official_hook_owner(data) : nullptr)
    {
        owner->cursor_code.store(-1, std::memory_order_release);
        PostMessageW(reinterpret_cast<HWND>(owner->root_window.load(std::memory_order_acquire)),
            g_official_control_message.load(std::memory_order_acquire), official_cursor_update, 0);
    }
    data.phase = input_phase::disabled;
    member().cooperative_member_phase = input_phase::disabled;
    if (!g_has_private_input_observer && member().participant_id == 0)
        publish_official_hook_phase(data, input_phase::disabled);

    discard_dormant_input();

    if (!acknowledge)
    {
        const ego_status focus_status =
            ego_transport_set_target_focused(data.transport, 0);
        if (focus_status != EGO_STATUS_OK && focus_status != data.last_focus_error)
        {
            data.last_focus_error = focus_status;
            log_transport_error("dormant input blur", focus_status);
            publish_input_routing_failure(data.transport, focus_status);
        }
        else if (focus_status == EGO_STATUS_OK)
        {
            data.last_focus_error = EGO_STATUS_OK;
        }
    }

    // Actual owner destruction commits blur and the disabled filter together.
    // A separate blur would invalidate the old Present's release sample.
    // Session observations remain transitional: a new authentication can race
    // their epoch snapshot and must not receive the old session's false ACK.
    const ego_status status = acknowledge
        ? ego_transport_retire_input_filter(data.transport)
        : ego_transport_apply_input_filter(data.transport, 0, 0);
    if (status != EGO_STATUS_OK && status != data.last_filter_error)
    {
        data.last_filter_error = status;
        log_transport_error("dormant input release", status);
        publish_input_routing_failure(data.transport, status);
    }
    else if (status == EGO_STATUS_OK)
    {
        data.last_filter_error = EGO_STATUS_OK;
        if (acknowledge)
            data.last_focus_error = EGO_STATUS_OK;
    }

    if (reset_imgui_cursor && member().participant_id == 0)
        ImGui::GetIO().MouseDrawCursor = false;
}

void deactivate_dormant_input(swapchain_data &data)
{
    deactivate_input(data, true, false);
}

void deactivate_destroyed_runtime_input(swapchain_data &data)
{
    // ReShade fires destroy_effect_runtime after tearing down its ImGui device
    // resources. Fail open without touching that context.
    deactivate_input(data, false, true);
}

void destroy_own_effect_runtime(effect_runtime *runtime)
{
    auto *const data = find_swapchain_data(runtime);
    if (data == nullptr)
        return;

    g_logical_control.run([&] {
        if (member().member_input_driver.release(runtime->get_native()))
            deactivate_destroyed_runtime_input(*data);
    });

    // This callback precedes both resize and final swap-chain destruction while
    // the runtime's exact graphics queue is still available. Waiting here and
    // retiring only this swap chain's map prevents cross-queue resource use.
    static_cast<void>(retire_all_electron_textures(runtime, *data));
}

void log_official_pointer_sequence()
{
    if (g_has_private_input_observer ||
        (g_official_pointer_message_mask.load(std::memory_order_acquire) & 7U) !=
            7U ||
        g_official_pointer_sequence_logged.test_and_set(
            std::memory_order_relaxed))
    {
        return;
    }

    reshade::log::message(
        reshade::log::level::info,
        "Electron game overlay official-host message hook observed and "
        "withheld a primary pointer update/down/up sequence.");
}

void compose_electron_scene(effect_runtime *runtime, swapchain_data &swapchain_state)
{
    swapchain_state.cooperative_frames.clear();
    if (swapchain_state.transport == nullptr)
        return;

    // Sample before acquiring the immutable scene: any command/focus/window
    // eligibility change racing publication invalidates this acknowledgement
    // token rather than acknowledging a stale aggregate grant.
    ego_input_state_v1 input_state = {};
    input_state.struct_size = sizeof(input_state); input_state.abi_version = EGO_ABI_VERSION;
    swapchain_state.cooperative_requested_interception = false;
    swapchain_state.cooperative_input_revision = UINT64_MAX;
    if (ego_transport_get_cooperative_input_state(swapchain_state.transport,
        &input_state, &swapchain_state.cooperative_input_revision) == EGO_STATUS_OK)
        swapchain_state.cooperative_requested_interception = input_state.requested_interception != 0;

    ego_scene_snapshot *snapshot = nullptr;
    ego_status status = ego_transport_acquire_scene(swapchain_state.transport, &snapshot);
    if (status != EGO_STATUS_OK || snapshot == nullptr)
    {
        if (!swapchain_state.scene_query_failure_active ||
            status != swapchain_state.last_scene_query_error)
        {
            swapchain_state.scene_query_failure_active = true;
            swapchain_state.last_scene_query_error = status;
            log_transport_error("scene acquisition", status);
            publish_runtime_diagnostic(
                swapchain_state.transport,
                EGO_RUNTIME_DIAGNOSTIC_SCENE_QUERY_FAILED,
                status);
        }
        return;
    }

    std::uint64_t window_count = 0;
    status = ego_scene_snapshot_window_count(snapshot, &window_count);
    if (status != EGO_STATUS_OK)
    {
        ego_scene_snapshot_release(snapshot);
        if (!swapchain_state.scene_query_failure_active ||
            status != swapchain_state.last_scene_query_error)
        {
            swapchain_state.scene_query_failure_active = true;
            swapchain_state.last_scene_query_error = status;
            log_transport_error("scene enumeration", status);
            publish_runtime_diagnostic(
                swapchain_state.transport,
                EGO_RUNTIME_DIAGNOSTIC_SCENE_QUERY_FAILED,
                status);
        }
        return;
    }
    swapchain_state.scene_query_failure_active = false;
    swapchain_state.last_scene_query_error = EGO_STATUS_OK;

    // Registration identity survives an unpainted raster resize. Preserve the
    // cooperative rank for those windows, and prune only authoritative closes.
    std::uint64_t registration_count = 0;
    std::vector<ego::cooperative::window_key> registrations;
    if (ego_scene_snapshot_registration_count(snapshot, &registration_count) != EGO_STATUS_OK ||
        registration_count > ego::cooperative::max_windows)
    {
        ego_scene_snapshot_release(snapshot);
        return;
    }
    registrations.reserve(static_cast<std::size_t>(registration_count));
    std::unordered_map<std::uint32_t, std::uint64_t> incarnations;
    incarnations.reserve(static_cast<std::size_t>(registration_count));
    for (std::uint64_t index = 0; index < registration_count; ++index)
    {
        std::uint32_t window_id = 0;
        std::uint64_t incarnation = 0;
        if (ego_scene_snapshot_get_registration(snapshot, index, &window_id, &incarnation) != EGO_STATUS_OK)
        {
            ego_scene_snapshot_release(snapshot);
            return;
        }
        registrations.push_back({member().participant_id, window_id, 0, incarnation});
        incarnations.emplace(window_id, incarnation);
    }
    g_logical_control.run([&] {
        const bool reconciled = g_cooperative.reconcile_registrations(member().participant_id, registrations.data(), registrations.size());
        if (reconciled && registrations != member().producer_registration_order &&
            g_cooperative.reorder_registrations(member().participant_id, registrations.data(), registrations.size()))
            member().producer_registration_order = registrations;
    });
    swapchain_state.cooperative_incarnations.swap(incarnations);

    device *const device = runtime->get_device();

    std::unordered_set<std::uint32_t> active_windows;
    active_windows.reserve(static_cast<std::size_t>(window_count));

    const std::scoped_lock lock(swapchain_state.texture_mutex);
    ImDrawList *const draw_list = ImGui::GetBackgroundDrawList();
    std::uint64_t rendered_window_count = 0;
    bool frame_rejected = false;
    for (std::uint64_t index = 0; index < window_count; ++index)
    {
        ego_window_frame_v1 frame = {};
        frame.struct_size = sizeof(frame);
        frame.abi_version = EGO_ABI_VERSION;
        status = ego_scene_snapshot_get_window(snapshot, index, &frame);
        if (status != EGO_STATUS_OK || !valid_frame(frame))
        {
            frame_rejected = true;
            if (!swapchain_state.frame_rejection_reported)
            {
                swapchain_state.frame_rejection_reported = true;
                reshade::log::message(
                    reshade::log::level::warning,
                    "Electron game overlay runtime rejected an invalid transported frame.");
                publish_runtime_diagnostic(
                    swapchain_state.transport,
                    EGO_RUNTIME_DIAGNOSTIC_FRAME_REJECTED,
                    status);
            }
            continue;
        }

        active_windows.insert(frame.window_id);
        std::uint64_t incarnation = 0;
        if (ego_scene_snapshot_window_incarnation(snapshot, index, &incarnation) != EGO_STATUS_OK || incarnation == 0)
            continue;
        swapchain_state.cooperative_incarnations.insert_or_assign(frame.window_id, incarnation);
        auto [entry, inserted] =
            swapchain_state.textures.try_emplace(frame.window_id);
        electron_texture &texture = entry->second;

        if (inserted || texture.texture.handle == 0 ||
            texture.width != frame.raster_width ||
            texture.height != frame.raster_height)
        {
            if (!inserted && texture.texture.handle != 0)
            {
                runtime->get_command_queue()->wait_idle();
                destroy_texture(device, texture);
            }
            if (!create_texture(
                    runtime,
                    frame,
                    texture,
                    swapchain_state.transport))
                continue;
        }
        else if ((texture.state_revision != frame.state_revision ||
                  texture.sequence != frame.sequence) &&
                 !update_texture(
                     runtime,
                     frame,
                     texture,
                     swapchain_state.transport))
        {
            continue;
        }

        const ImVec2 top_left(
            static_cast<float>(frame.rect_x),
            static_cast<float>(frame.rect_y));
        const ImVec2 bottom_right(
            static_cast<float>(frame.rect_x) + static_cast<float>(frame.rect_width),
            static_cast<float>(frame.rect_y) + static_cast<float>(frame.rect_height));
        if (member().participant_id == 0)
            draw_list->AddImage(texture.view.handle, top_left, bottom_right);
        frame.name_utf8 = nullptr;
        frame.rgba = nullptr;
        swapchain_state.cooperative_frames.push_back(frame);
        ++rendered_window_count;
    }
    if (!frame_rejected)
        swapchain_state.frame_rejection_reported = false;

    bool removed_texture = false;
    std::uint64_t removed_texture_count = 0;
    for (auto iterator = swapchain_state.textures.begin();
         iterator != swapchain_state.textures.end();)
    {
        if (active_windows.contains(iterator->first))
        {
            ++iterator;
            continue;
        }
        if (!removed_texture)
        {
            runtime->get_command_queue()->wait_idle();
            removed_texture = true;
        }
        destroy_texture(device, iterator->second);
        iterator = swapchain_state.textures.erase(iterator);
        ++removed_texture_count;
    }
    swapchain_state.retired_session_textures += removed_texture_count;

    ego_scene_snapshot_release(snapshot);
    if (rendered_window_count != 0 && !swapchain_state.first_scene_logged)
    {
        swapchain_state.first_scene_logged = true;
        char message[160] = {};
        sprintf_s(
            message,
            "Electron game overlay runtime rendered its first transported scene (%llu window(s)).",
            static_cast<unsigned long long>(rendered_window_count));
        reshade::log::message(reshade::log::level::info, message);
        publish_runtime_diagnostic(
            swapchain_state.transport,
            EGO_RUNTIME_DIAGNOSTIC_SCENE_RENDERING_STARTED);
    }
    if (rendered_window_count >= 2 && !swapchain_state.first_multiwindow_scene_logged)
    {
        swapchain_state.first_multiwindow_scene_logged = true;
        char message[176] = {};
        sprintf_s(
            message,
            "Electron game overlay runtime rendered its first transported multi-window scene (%llu window(s)).",
            static_cast<unsigned long long>(rendered_window_count));
        reshade::log::message(reshade::log::level::info, message);
    }
}

bool prepare_own_frame(effect_runtime *runtime, bool anchor_owner)
{
    auto *data = find_swapchain_data(runtime);
    if (data == nullptr)
    {
        // A privately loaded late participant did not observe init_swapchain.
        // The authenticated live effect-runtime supplies its current surface.
        initialize_own_surface(runtime, static_cast<HWND>(runtime->get_hwnd()));
        data = find_swapchain_data(runtime);
    }
    if (data == nullptr)
        return false;
    if (!advance_own_surface_startup(*data))
        return false;
    data->cooperative_frame_active = false;
    data->cooperative_frames.clear();
    if (data->transport == nullptr)
        return false;

    std::uint64_t session_epoch = 0;
    if (!transport_session_epoch(*data, session_epoch))
    {
        g_logical_control.run([&] { deactivate_dormant_input(*data); });
        data->retired_session_textures +=
            retire_all_electron_textures(runtime, *data);
        return true;
    }

    const bool session_active =
        producer_session_active(session_epoch);
    const bool first_session_observation =
        !data->has_observed_session_epoch;
    const std::uint64_t previous_session_epoch =
        data->observed_session_epoch;
    const bool session_epoch_changed =
        !first_session_observation &&
        previous_session_epoch != session_epoch;

    // Every eligible Present drives one module stream, even when the anchor
    // chain is paused. Its local texture epoch never decides shared cleanup.
    ego_target_surface_v1 surface = {};
    const bool captured = capture_target_surface(runtime, *data, surface);
    const bool admitted = g_logical_control.run([&] {
        if (anchor_owner && !owns_primary_swapchain(*data) &&
            (!captured || !claim_primary_swapchain(*data)))
            return false;
        const auto logical_epoch = member().logical_session_epoch.observe(session_epoch);
        if (logical_epoch.stale)
            return false;
        if (anchor_owner && !update_primary_target_surface(*data, surface, captured))
            return false;
        if (!anchor_owner && captured)
            publish_target_surface(*data, surface);
        member().member_input_driver.activate(runtime->get_native());
        if (logical_epoch.changed)
        {
            deactivate_dormant_input(*data);
            // An epoch ends registrations; an ordinary raster gap does not.
            static_cast<void>(g_cooperative.reconcile_registrations(member().participant_id, nullptr, 0));
            member().producer_registration_order.clear();
        }
        return true;
    });
    if (!admitted)
        return false;

    if (first_session_observation)
    {
        data->has_observed_session_epoch = true;
        data->observed_session_epoch = session_epoch;
        if (session_active)
        {
            data->has_observed_authenticated_session = true;
            data->retired_session_textures = 0;
        }
    }
    else if (session_epoch_changed)
    {
        // Every runtime retires only its own queue-owned GPU resources. The
        // module's logical stream has already handled shared input/metadata.
        data->observed_session_epoch = session_epoch;
        data->cooperative_incarnations.clear();
        data->retired_session_textures +=
            retire_all_electron_textures(runtime, *data);

        if (!session_active &&
            data->has_observed_authenticated_session)
        {
            char message[256] = {};
            sprintf_s(
                message,
                "Electron game overlay runtime deactivated its producer session, "
                "released input, and retired %llu transported texture(s); the "
                "add-on remains loaded dormant.",
                static_cast<unsigned long long>(
                    data->retired_session_textures));
            reshade::log::message(reshade::log::level::info, message);
            data->retired_session_textures = 0;
        }
        else if (session_active)
        {
            if (data->has_observed_authenticated_session)
            {
                char message[320] = {};
                sprintf_s(
                    message,
                    "Electron game overlay runtime advanced its producer "
                    "session epoch from %llu to %llu, released old input, and "
                    "retired %llu transported texture(s) before composing the "
                    "replacement session.",
                    static_cast<unsigned long long>(
                        previous_session_epoch),
                    static_cast<unsigned long long>(session_epoch),
                    static_cast<unsigned long long>(
                        data->retired_session_textures));
                reshade::log::message(
                    reshade::log::level::info,
                    message);
            }
            data->has_observed_authenticated_session = true;
            data->retired_session_textures = 0;
        }
    }

    if (!session_active)
    {
        if (!session_epoch_changed)
        {
            g_logical_control.run([&] { deactivate_dormant_input(*data); });
            data->retired_session_textures +=
                retire_all_electron_textures(runtime, *data);
        }
        return true;
    }

    g_logical_control.run([&] { publish_render_fps(*data); });
    log_official_pointer_sequence();
    compose_electron_scene(runtime, *data);
    data->cooperative_frame_active = true;
    return true;
}

void cooperative_prepare_frame(void *context, void *opaque_runtime)
{
    const participant_callback_scope scope(context);
    if (member().participant_id.load(std::memory_order_acquire) == 0)
        return;
    auto *const runtime = static_cast<effect_runtime *>(opaque_runtime);
    if (find_swapchain_data(runtime) == nullptr)
        initialize_own_surface(runtime, static_cast<HWND>(runtime->get_hwnd()));
    const bool logical_owner = g_cooperative.claim_primary_surface(runtime->get_native());
    const auto primary = g_cooperative.primary_surface();
    const auto role = ego::cooperative::classify_presentation(runtime->get_native(),
        reinterpret_cast<std::uintptr_t>(runtime->get_hwnd()), logical_owner,
        primary.native_id, primary.hwnd);
    if (!ego::cooperative::drives_logical_frame(role))
        return;
    if (!prepare_own_frame(runtime, logical_owner))
        return;
    auto *const data = find_swapchain_data(runtime);
    if (logical_owner && data != nullptr && !owns_primary_swapchain(*data))
        return;
    std::vector<ego::cooperative::window_v1> windows;
    if (data != nullptr && data->cooperative_frame_active)
    {
        windows.reserve(data->cooperative_frames.size());
        for (const auto &frame : data->cooperative_frames)
        {
            ego::cooperative::window_v1 window;
            window.window_id = frame.window_id;
            window.incarnation = data->cooperative_incarnations.at(frame.window_id);
            window.flags = frame.transparent != 0 ? ego::cooperative::window_transparent : 0;
            window.x = frame.rect_x; window.y = frame.rect_y;
            window.width = frame.rect_width; window.height = frame.rect_height;
            windows.push_back(window);
        }
    }
    g_logical_control.run([&] {
        static_cast<void>(g_cooperative.publish_windows(member().participant_id, windows.data(), windows.size(), true));
        static_cast<void>(g_cooperative.set_interception(member().participant_id,
            data != nullptr && data->cooperative_frame_active && data->cooperative_requested_interception &&
            target_window_focused(data->window)));
        if (data == nullptr || data->transport == nullptr)
            return;
        for (;;)
        {
            std::uint64_t focus_revision = 0, focus_incarnation = 0;
            std::uint32_t focus_window = 0, focused = 0;
            if (ego_transport_cooperative_focus_request(data->transport, member().cooperative_focus_revision,
                &focus_revision, &focus_window, &focus_incarnation, &focused) != EGO_STATUS_OK || focus_revision == 0)
                break;
            const auto found = data->cooperative_incarnations.find(focus_window);
            if (focused != 0 && found != data->cooperative_incarnations.end() && found->second == focus_incarnation)
            {
                if (g_cooperative.set_focus({member().participant_id, focus_window, 0, focus_incarnation}))
                    member().cooperative_focus_revision = focus_revision;
                else
                    break;
            }
            else if (focused == 0)
            {
                const auto current = g_cooperative.focus();
                if (current.participant == member().participant_id && current.window_id == focus_window && current.incarnation == focus_incarnation)
                    static_cast<void>(g_cooperative.set_focus({}));
                member().cooperative_focus_revision = focus_revision;
            }
            else break;
        }
        const auto focus = g_cooperative.focus();
        static_cast<void>(ego_transport_set_cooperative_focus(
            data->transport, focus.participant == member().participant_id ? focus.window_id : 0,
            focus.participant == member().participant_id ? focus.incarnation : 0));
    });
}

void cooperative_flush_input(void *context, void *opaque_runtime)
{
    const participant_callback_scope scope(context);
    auto *const runtime = static_cast<effect_runtime *>(opaque_runtime);
    auto *const data = find_swapchain_data(runtime);
    if (data == nullptr || !data->cooperative_frame_active ||
        member().member_input_driver.native_id() != runtime->get_native())
        return;
    g_logical_control.run([&] {
        if (member().member_input_driver.native_id() != runtime->get_native())
            return;
        const auto focus = g_cooperative.focus();
        static_cast<void>(ego_transport_set_cooperative_focus(data->transport,
            focus.participant == member().participant_id ? focus.window_id : 0,
            focus.participant == member().participant_id ? focus.incarnation : 0));
        static_cast<void>(ego_transport_set_cooperative_interception_checked(data->transport,
            g_cooperative.interception_requested() && !g_cooperative.snapshot_windows().empty() ? 1U : 0U,
            data->cooperative_input_revision));
        data->phase = member().cooperative_member_phase;
        update_input_ownership(runtime, *data);
        member().cooperative_member_phase = data->phase;
        drain_input_messages(data->transport, primary_target_window(*data));
    });
}

void cooperative_render_window(void *context, void *opaque_runtime, std::uint32_t window_id, std::uint64_t incarnation)
{
    const participant_callback_scope scope(context);
    auto *const data = find_swapchain_data(static_cast<effect_runtime *>(opaque_runtime));
    if (data == nullptr || !data->cooperative_frame_active)
        return;
    const auto identity = data->cooperative_incarnations.find(window_id);
    if (identity == data->cooperative_incarnations.end() || identity->second != incarnation)
        return;
    const std::scoped_lock lock(data->texture_mutex);
    const auto texture = data->textures.find(window_id);
    if (texture == data->textures.end() || texture->second.view.handle == 0)
        return;
    const auto frame = std::find_if(data->cooperative_frames.begin(), data->cooperative_frames.end(),
        [window_id](const auto &value) { return value.window_id == window_id; });
    if (frame == data->cooperative_frames.end())
        return;
    if (owns_dispatcher_surface() && g_render_readback.enabled())
    {
        ego::render_readback_diagnostic::own_window_note note;
        note.runtime = static_cast<effect_runtime *>(opaque_runtime);
        note.texture = texture->second.texture.handle; note.srv = texture->second.view.handle;
        note.window_id = window_id; note.incarnation = incarnation;
        note.sequence = frame->sequence; note.revision = frame->state_revision;
        note.x = frame->rect_x; note.y = frame->rect_y; note.width = frame->rect_width; note.height = frame->rect_height;
        note.raster_width = frame->raster_width; note.raster_height = frame->raster_height;
        const auto &io = ImGui::GetIO();
        note.display_width = io.DisplaySize.x; note.display_height = io.DisplaySize.y;
        note.framebuffer_x = io.DisplayFramebufferScale.x; note.framebuffer_y = io.DisplayFramebufferScale.y;
        g_render_readback.note_own_window(note);
    }
    ImGui::GetBackgroundDrawList()->AddImage(texture->second.view.handle,
        ImVec2(static_cast<float>(frame->rect_x), static_cast<float>(frame->rect_y)),
        ImVec2(static_cast<float>(frame->rect_x) + frame->rect_width,
            static_cast<float>(frame->rect_y) + frame->rect_height));
}

std::uint32_t cooperative_hit_test(void *context, std::uint32_t window_id, std::uint64_t incarnation,
    std::int32_t x, std::int32_t y)
{
    const participant_callback_scope scope(context);
    const std::scoped_lock lock(member().transport_mutex);
    std::uint32_t hit = 0;
    if (member().transport != nullptr)
        static_cast<void>(ego_transport_hit_test_window(member().transport, window_id, incarnation, x, y, &hit));
    return hit ? ego::cooperative::hit_body : 0;
}

std::int32_t cooperative_cursor_at(void *context, std::uint32_t window_id, std::uint64_t incarnation,
    std::int32_t, std::int32_t)
{
    const participant_callback_scope scope(context);
    const std::scoped_lock lock(member().transport_mutex);
    std::int32_t cursor = -1;
    if (member().transport != nullptr)
        static_cast<void>(ego_transport_cursor_for_window(member().transport, window_id, incarnation, &cursor));
    return cursor;
}

void cooperative_release_input(void *context)
{
    const participant_callback_scope scope(context);
    g_logical_control.run([&] {
        if (member().transport != nullptr)
            static_cast<void>(ego_transport_release_cooperative_ownership(member().transport));
        discard_dormant_input();
    });
}

void cooperative_destroy_surface(void *context, void *surface, std::uint32_t final_swapchain)
{
    const participant_callback_scope scope(context);
    if (final_swapchain != 0)
    {
        destroy_own_swapchain(static_cast<swapchain *>(surface), false);
        // A late participant may never have presented this surviving surface,
        // but its zero-ref bridge hold must still drain on the final destroy.
        release_transport(nullptr, false);
    }
    else
        destroy_own_effect_runtime(static_cast<effect_runtime *>(surface));
}

void on_destroy_swapchain(swapchain *surface, bool resize)
{
    if (resize) return;
    const auto retired_primary = g_logical_control.run([&] {
        return g_cooperative.primary_surface();
    });
    g_cooperative.remove_surface(surface->get_native());
    if (!g_cooperative.has_live_surfaces())
    {
        // No future Present is required to stop suppression. Source pointer
        // state is invalidated before any recreated surface can project input.
        g_source_final_reset_pending.store(true, std::memory_order_release);
        g_logical_control.run([&] {
            g_cooperative_adapter_phase = input_phase::disabled;
            g_adapter_window_ready.store(false, std::memory_order_release);
            g_adapter_input_driver.reset();
            if (auto *const data = find_swapchain_data(surface))
            {
                if (auto *const owner = get_official_hook_owner(*data))
                {
                    owner->phase.store(input_phase::disabled, std::memory_order_release);
                    owner->cursor_code.store(-1, std::memory_order_release);
                    PostMessageW(reinterpret_cast<HWND>(owner->root_window.load(std::memory_order_acquire)),
                        g_official_control_message.load(std::memory_order_acquire), official_cursor_update, 0);
                }
            }
        });
    }
    bool own_surface_destroyed = false;
    for (const auto &participant : g_cooperative.snapshot_participants())
        if (participant.callbacks.destroy_surface != nullptr)
        {
            own_surface_destroyed = own_surface_destroyed ||
                (participant.callbacks.destroy_surface == cooperative_destroy_surface && participant.context == nullptr);
            participant.callbacks.destroy_surface(participant.context, surface, 1);
        }
    // The dormant first adapter deliberately has no participant entry. Compare
    // the callback in the same snapshot rather than a concurrently published
    // participant id, so activation cannot make baseline cleanup disappear.
    if (!own_surface_destroyed)
        cooperative_destroy_surface(nullptr, surface, 1);
    g_logical_control.run([&] {
        g_cooperative.release_primary_surface(surface->get_native(),
            g_adapter_input_driver.native_id(),
            retired_primary.native_id == surface->get_native() ? retired_primary.hwnd : 0);
    });
}

void on_destroy_effect_runtime(effect_runtime *runtime)
{
    g_logical_control.run([&] {
        if (g_adapter_input_driver.release(runtime->get_native()))
        {
            // A former presenter may be reset after a peer has taken over. Only
            // retirement of the current driver can release the shared adapter.
            g_cooperative_adapter_phase = input_phase::disabled;
            g_adapter_window_ready.store(false, std::memory_order_release);
            g_cooperative.retire_input_driver_capture();
            if (auto *const data = find_swapchain_data(runtime))
            {
                if (!g_has_private_input_observer)
                    publish_official_hook_phase(*data, input_phase::disabled);
                if (auto *const owner = get_official_hook_owner(*data))
                {
                    owner->cursor_code.store(-1, std::memory_order_release);
                    PostMessageW(reinterpret_cast<HWND>(owner->root_window.load(std::memory_order_acquire)),
                        g_official_control_message.load(std::memory_order_acquire), official_cursor_update, 0);
                }
            }
        }
    });
    bool own_surface_destroyed = false;
    for (const auto &participant : g_cooperative.snapshot_participants())
        if (participant.callbacks.destroy_surface != nullptr)
        {
            own_surface_destroyed = own_surface_destroyed ||
                (participant.callbacks.destroy_surface == cooperative_destroy_surface && participant.context == nullptr);
            participant.callbacks.destroy_surface(participant.context, runtime, 0);
        }
    if (!own_surface_destroyed)
        cooperative_destroy_surface(nullptr, runtime, 0);
}

void apply_cooperative_adapter_state(effect_runtime *runtime)
{
    auto *const data = find_swapchain_data(runtime);
    if (data == nullptr)
        return;
    g_logical_control.run([&] {
        g_adapter_input_driver.activate(runtime->get_native());
        bool requested = g_cooperative.interception_requested() && !g_cooperative.snapshot_windows().empty() && target_window_focused(data->window);
        auto *const owner = get_official_hook_owner(*data);
        if (!g_has_private_input_observer &&
            (owner == nullptr || !owner->hook_ready.load(std::memory_order_acquire) || !claim_official_input_owner(*data)))
            requested = false;
        g_cooperative_adapter_phase = next_phase(g_cooperative_adapter_phase, requested);
        if (!g_has_private_input_observer)
            publish_official_hook_phase(*data, g_cooperative_adapter_phase);
        if (g_cooperative_adapter_phase != input_phase::disabled)
            runtime->block_input_next_frame();
    });
}

void apply_cooperative_presentation_cursor(effect_runtime *runtime)
{
    auto *const data = find_swapchain_data(runtime);
    if (data == nullptr)
        return;
    std::int32_t cursor = -1;
    CURSORINFO info = {sizeof(CURSORINFO)};
    const bool have_cursor = GetCursorInfo(&info) != FALSE;
    const bool routing = g_logical_control.run([&] {
        return g_adapter_input_driver.native_id() == runtime->get_native() &&
            g_cooperative_adapter_phase == input_phase::enabled;
    });
    if (routing && have_cursor)
    {
        POINT point = info.ptScreenPos;
        if (ScreenToClient(data->window, &point))
            cursor = g_cooperative.cursor_at(point.x, point.y);
    }
    // All exact-HWND presenters drive one window-thread hardware lease. Each
    // current ImGui presentation also needs its own software cursor output.
    g_logical_control.run([&] {
        if (g_adapter_input_driver.native_id() != runtime->get_native())
            return;
        auto *const owner = get_official_hook_owner(*data);
        if (owner != nullptr && owner->cursor_code.exchange(cursor, std::memory_order_acq_rel) != cursor)
            PostMessageW(reinterpret_cast<HWND>(owner->root_window.load(std::memory_order_acquire)),
                g_official_control_message.load(std::memory_order_acquire), official_cursor_update, 0);
    });
    ImGuiIO &io = ImGui::GetIO();
    io.MouseDrawCursor = cursor > 0 && (!have_cursor || (info.flags & CURSOR_SHOWING) == 0);
    if (io.MouseDrawCursor)
    {
        ImGuiMouseCursor shape = ImGuiMouseCursor_Arrow;
        switch (cursor)
        {
        case 32513: shape = ImGuiMouseCursor_TextInput; break;
        case 32649: shape = ImGuiMouseCursor_Hand; break;
        case 32642: shape = ImGuiMouseCursor_ResizeNWSE; break;
        case 32643: shape = ImGuiMouseCursor_ResizeNESW; break;
        case 32644: shape = ImGuiMouseCursor_ResizeEW; break;
        case 32645: shape = ImGuiMouseCursor_ResizeNS; break;
        case 32646: shape = ImGuiMouseCursor_ResizeAll; break;
        case 32648: shape = ImGuiMouseCursor_NotAllowed; break;
        }
        ImGui::SetMouseCursor(shape);
    }
}

void on_reshade_overlay(effect_runtime *runtime)
{
    if (member().participant_id == 0 && initialize_automatic_member() != ERROR_SUCCESS &&
        !can_drive_dormant_adapter())
        return;
    const bool logical_owner = g_cooperative.claim_primary_surface(runtime->get_native());
    const auto primary = g_cooperative.primary_surface();
    const auto role = ego::cooperative::classify_presentation(runtime->get_native(),
        reinterpret_cast<std::uintptr_t>(runtime->get_hwnd()), logical_owner,
        primary.native_id, primary.hwnd);
    if (ego::cooperative::drives_logical_frame(role))
    {
        if (find_swapchain_data(runtime) == nullptr)
            initialize_own_surface(runtime, static_cast<HWND>(runtime->get_hwnd()));
        auto *const data = find_swapchain_data(runtime);
        if (data == nullptr || !advance_own_surface_startup(*data))
            return;
        g_logical_control.run([&] {
            g_adapter_window_ready.store(true, std::memory_order_release);
            g_adapter_input_driver.activate(runtime->get_native());
            if (data != nullptr && !g_has_private_input_observer)
                static_cast<void>(claim_official_input_owner(*data));
        });
    }
    // This also protects older participants: none of their preparation or
    // input callbacks may advertise success before the shared cursor/input
    // adapter has acknowledged owner-thread installation.
    if (!g_adapter_window_ready.load(std::memory_order_acquire))
        return;
    for (const auto &participant : g_cooperative.snapshot_participants())
        if (participant.callbacks.prepare_frame != nullptr)
            participant.callbacks.prepare_frame(participant.context, runtime);
    if (!ego::cooperative::drives_logical_frame(role))
        return;
    drain_cooperative_sources(static_cast<HWND>(runtime->get_hwnd()));
    for (const auto &participant : g_cooperative.snapshot_participants())
        if (participant.callbacks.flush_input != nullptr)
            participant.callbacks.flush_input(participant.context, runtime);
    apply_cooperative_adapter_state(runtime);
    apply_cooperative_presentation_cursor(runtime);
    for (const auto &window : g_cooperative.snapshot_windows())
        if (window.callbacks.render_window != nullptr)
            window.callbacks.render_window(window.context, runtime, window.key.window_id, window.key.incarnation);
}

void on_reshade_present_diagnostic(effect_runtime *runtime)
{
    g_render_readback.after_overlay(runtime);
}

bool register_compatible_addon(HMODULE module)
{
    reshade::internal::get_current_module_handle(module);
    g_addon_module = module;
    g_official_hooks_shutting_down.store(false, std::memory_order_release);
    HMODULE const host = reshade::internal::get_reshade_module_handle();
    if (host == nullptr)
    {
        g_addon_module = nullptr;
        return false;
    }
    const auto register_addon = reinterpret_cast<bool (*)(void *, std::uint32_t)>(
        GetProcAddress(host, "ReShadeRegisterAddon"));
    const auto unregister_addon = reinterpret_cast<void (*)(void *)>(
        GetProcAddress(host, "ReShadeUnregisterAddon"));
    const bool register_public_metadata = g_cooperative_dispatcher || is_preloaded_member();
    if (register_addon == nullptr ||
        unregister_addon == nullptr ||
        (register_public_metadata && !register_addon(module, public_reshade_api_version)))
    {
        g_addon_module = nullptr;
        return false;
    }

    const auto get_imgui_table =
        reinterpret_cast<const imgui_function_table *(*)(std::uint32_t)>(
            GetProcAddress(host, "ReShadeGetImGuiFunctionTable"));
    if (get_imgui_table == nullptr ||
        !(imgui_function_table_instance() = get_imgui_table(IMGUI_VERSION_NUM)))
    {
        if (register_public_metadata)
            unregister_addon(module);
        g_addon_module = nullptr;
        return false;
    }

    const auto host_abi = reinterpret_cast<const unsigned int *>(
        GetProcAddress(host, "ElectronGameOverlayReShadeHostAbi"));
    const bool has_private_gate =
        GetProcAddress(host, "ElectronGameOverlayReShadeAddonGate") != nullptr;
    g_reshade_host_module = host;
    g_has_private_input_observer =
        host_abi != nullptr && *host_abi == 1 && has_private_gate;
    g_public_registered = register_public_metadata;
    return true;
}

void unregister_compatible_addon(HMODULE module)
{
    if (g_reshade_host_module != nullptr && g_public_registered)
    {
        const auto unregister_addon = reinterpret_cast<void (*)(void *)>(
            GetProcAddress(g_reshade_host_module, "ReShadeUnregisterAddon"));
        if (unregister_addon != nullptr)
            unregister_addon(module);
    }
    g_has_private_input_observer = false;
    g_reshade_host_module = nullptr;
    g_addon_module = nullptr;
    imgui_function_table_instance() = nullptr;
}

struct member_initialize_v1
{
    std::uint32_t struct_size;
    std::uint32_t abi_version;
    wchar_t run_directory[32768];
};
static_assert(sizeof(member_initialize_v1) == 65544);
static_assert(alignof(member_initialize_v1) == 4);
static_assert(std::is_trivially_copyable_v<member_initialize_v1>);

bool has_owned_stage_marker(const std::filesystem::path &directory)
{
    const auto marker = directory / L".electron-game-overlay-run.json";
    const auto attributes = GetFileAttributesW(marker.c_str());
    if (attributes == INVALID_FILE_ATTRIBUTES ||
        (attributes & (FILE_ATTRIBUTE_DIRECTORY | FILE_ATTRIBUTE_REPARSE_POINT)) != 0)
        return false;
    HANDLE file = CreateFileW(marker.c_str(), GENERIC_READ,
        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OPEN_REPARSE_POINT, nullptr);
    if (file == INVALID_HANDLE_VALUE) return false;
    LARGE_INTEGER length = {};
    bool valid = GetFileSizeEx(file, &length) && length.QuadPart > 0 && length.QuadPart <= 4096;
    std::string document(valid ? static_cast<std::size_t>(length.QuadPart) : 0, '\0');
    DWORD read = 0;
    if (valid) valid = ReadFile(file, document.data(), static_cast<DWORD>(document.size()), &read, nullptr) && read == document.size();
    CloseHandle(file);
    if (!valid) return false;
    // SDK ownership records are a flat JSON object with canonical UUID/ISO
    // strings. Parse the complete object, rejecting duplicate/unknown keys,
    // malformed syntax and wrong types rather than matching substrings.
    std::size_t position = 0;
    const auto whitespace = [&]() {
        while (position < document.size() &&
            (document[position] == ' ' || document[position] == '\t' || document[position] == '\r' || document[position] == '\n')) ++position;
    };
    const auto string_value = [&](std::string &value) {
        whitespace(); value.clear();
        if (position == document.size() || document[position++] != '"') return false;
        while (position < document.size())
        {
            const auto character = document[position++];
            if (character == '"') return true;
            if (static_cast<unsigned char>(character) < 0x20) return false;
            if (character == '\\')
            {
                if (position == document.size()) return false;
                const auto escaped = document[position++];
                if (escaped == '"' || escaped == '\\' || escaped == '/') value += escaped;
                else return false; // Canonical SDK UUID/path/time strings need no other escapes.
            }
            else value += character;
        }
        return false;
    };
    whitespace();
    if (position == document.size() || document[position++] != '{') return false;
    std::unordered_map<std::string, std::string> fields;
    for (;;)
    {
        std::string key, value;
        if (!string_value(key)) return false;
        whitespace();
        if (position == document.size() || document[position++] != ':') return false;
        whitespace();
        if (key == "schemaVersion")
        {
            if (position == document.size() || document[position++] != '1') return false;
            value = "1";
        }
        else if (!string_value(value)) return false;
        if (!fields.emplace(key, value).second) return false;
        whitespace();
        if (position == document.size()) return false;
        const auto separator = document[position++];
        if (separator == '}') break;
        if (separator != ',') return false;
    }
    whitespace();
    if (position != document.size() || fields.size() != 5 || fields["schemaVersion"] != "1" ||
        fields["kind"] != "electron-game-overlay-reshade-run") return false;
    const auto &id = fields["runId"];
    if (id.size() != 36 || id[14] != '4' ||
        (id[19] != '8' && id[19] != '9' && id[19] != 'a' && id[19] != 'b')) return false;
    for (std::size_t index = 0; index < id.size(); ++index)
        if (index == 8 || index == 13 || index == 18 || index == 23)
        { if (id[index] != '-') return false; }
        else if (!((id[index] >= '0' && id[index] <= '9') || (id[index] >= 'a' && id[index] <= 'f'))) return false;
    const auto &created = fields["createdAt"];
    if (created.size() != 24 || created[4] != '-' || created[7] != '-' || created[10] != 'T' ||
        created[13] != ':' || created[16] != ':' || created[19] != '.' || created[23] != 'Z') return false;
    for (std::size_t index = 0; index < created.size(); ++index)
        if (index != 4 && index != 7 && index != 10 && index != 13 && index != 16 && index != 19 && index != 23 &&
            (created[index] < '0' || created[index] > '9')) return false;
    const auto name = directory.filename().wstring();
    const auto bytes = WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, name.data(), static_cast<int>(name.size()), nullptr, 0, nullptr, nullptr);
    if (bytes <= 0) return false;
    std::string encoded(static_cast<std::size_t>(bytes), '\0');
    return WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, name.data(), static_cast<int>(name.size()),
        encoded.data(), bytes, nullptr, nullptr) == bytes && fields["directoryName"] == encoded;
}

DWORD pin_cooperative_modules()
{
    HMODULE pinned_host = nullptr;
    if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_PIN,
        reinterpret_cast<LPCWSTR>(g_reshade_host_module), &pinned_host))
        return GetLastError();
    HMODULE pinned = nullptr;
    if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_PIN,
        reinterpret_cast<LPCWSTR>(&g_addon_module), &pinned))
        return GetLastError();
    g_module_pinned.store(true, std::memory_order_release);
    return ERROR_SUCCESS;
}

DWORD publish_cooperative_member(participant_state *context = nullptr)
{
    const participant_callback_scope scope(context);
    ego::cooperative::callbacks_v1 callbacks;
    callbacks.prepare_frame = cooperative_prepare_frame;
    callbacks.render_window = cooperative_render_window;
    callbacks.hit_test = cooperative_hit_test;
    callbacks.route_message = queue_cooperative_input;
    callbacks.release_input = cooperative_release_input;
    callbacks.cursor_at = cooperative_cursor_at;
    callbacks.destroy_surface = cooperative_destroy_surface;
    callbacks.flush_input = cooperative_flush_input;
    auto admission = g_cooperative.reserve_participant();
    if (!admission)
        return ERROR_TOO_MANY_SESS;
    // No callback/context is visible and no registry lock is held while
    // acquiring the loader lock. Rejected admission must not pin this module.
    const auto pin_error = pin_cooperative_modules();
    if (pin_error != ERROR_SUCCESS)
        return pin_error;
    // PIN is irreversible. If publication fails, consume the invisible slot
    // rather than admitting an unbounded number of other pinned modules.
    admission.retain_if_unpublished();
    member().input_source_cutoff.store(g_cooperative.latest_source_sequence(), std::memory_order_release);
    // Callback snapshots may begin as soon as publish releases the registry.
    if (context != nullptr)
        context->participant_id.store(admission.id(), std::memory_order_release);
    const auto participant = admission.publish(callbacks, context);
    if (participant == 0)
    {
        if (context != nullptr)
            context->participant_id.store(0, std::memory_order_release);
        return ERROR_TOO_MANY_SESS;
    }
    if (context == nullptr)
        member().participant_id.store(participant, std::memory_order_release);
    InterlockedExchange(&ElectronGameOverlayCooperativeReadyV1, 1);
    return ERROR_SUCCESS;
}

DWORD initialize_cooperative_member(void *opaque_request, bool explicit_initializer,
    bool preloaded_activation)
{
    const std::scoped_lock lock(g_member_initialization_mutex);
#if defined(EGO_EXPERIMENTAL_PRIVATE_MEMORY_ROUTE)
    if (g_memory_dispatcher.load(std::memory_order_acquire) || g_preloaded_memory_binding)
        return ERROR_ALREADY_ASSIGNED;
#endif
    std::wstring directory;
    if (preloaded_activation)
    {
        if (!is_preloaded_member() || opaque_request == nullptr)
            return ERROR_INVALID_FUNCTION;
        const auto &request = *static_cast<const member_initialize_v1 *>(opaque_request);
        if (request.struct_size != sizeof(request) || request.abi_version != 1)
            return ERROR_INVALID_PARAMETER;
        const auto length = wcsnlen_s(request.run_directory, std::size(request.run_directory));
        if (length == 0 || length == std::size(request.run_directory))
            return ERROR_INVALID_PARAMETER;
        const auto requested = std::filesystem::path(std::wstring(request.run_directory, length));
        if (!requested.is_absolute())
            return ERROR_BAD_PATHNAME;
        std::error_code error;
        const auto canonical = std::filesystem::canonical(requested, error);
        if (error || !has_owned_stage_marker(canonical))
            return ERROR_ACCESS_DENIED;
        directory = canonical.wstring();
        if (!g_preload_bound_directory.empty() &&
            CompareStringOrdinal(g_preload_bound_directory.c_str(),
                static_cast<int>(g_preload_bound_directory.size()), directory.c_str(),
                static_cast<int>(directory.size()), TRUE) != CSTR_EQUAL)
            return ERROR_ALREADY_ASSIGNED;
        // Reserve the binding before admission or PIN can be consumed. A
        // failed/uncertain activation may retry this route but never retarget
        // the mapped feature engine to a later application session.
        if (g_preload_bound_directory.empty())
            g_preload_bound_directory = directory;
    }
    else if (is_preloaded_member())
        return ERROR_INVALID_FUNCTION;
    if (member().participant_id.load(std::memory_order_acquire) != 0)
        return ERROR_SUCCESS;
    if (!preloaded_activation && opaque_request != nullptr)
    {
        const auto &request = *static_cast<const member_initialize_v1 *>(opaque_request);
        if (request.struct_size != sizeof(request) || request.abi_version != 1)
            return ERROR_INVALID_PARAMETER;
        const auto length = wcsnlen_s(request.run_directory, std::size(request.run_directory));
        if (length == 0 || length == std::size(request.run_directory))
            return ERROR_INVALID_PARAMETER;
        directory.assign(request.run_directory, length);
    }
    else if (!preloaded_activation)
    {
        std::array<wchar_t, 32768> path = {};
        const auto length = GetModuleFileNameW(g_addon_module, path.data(), static_cast<DWORD>(path.size()));
        if (length == 0 || length == path.size())
            return ERROR_BAD_PATHNAME;
        directory = std::filesystem::path(std::wstring(path.data(), length)).parent_path().wstring();
    }
    if (!std::filesystem::path(directory).is_absolute())
        return ERROR_BAD_PATHNAME;
    const auto route_directory = std::filesystem::path(directory);
    member().private_route_present = explicit_initializer || has_owned_stage_marker(route_directory);
    g_render_readback.configure(route_directory, g_cooperative_dispatcher && has_owned_stage_marker(route_directory));
    const int bytes = WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS,
        directory.data(), static_cast<int>(directory.size()), nullptr, 0, nullptr, nullptr);
    if (bytes <= 0)
        return ERROR_NO_UNICODE_TRANSLATION;
    member().private_run_directory.assign(static_cast<std::size_t>(bytes), '\0');
    if (WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, directory.data(),
        static_cast<int>(directory.size()), member().private_run_directory.data(), bytes, nullptr, nullptr) != bytes)
        return ERROR_NO_UNICODE_TRANSLATION;
    return publish_cooperative_member();
}

#if defined(EGO_EXPERIMENTAL_PRIVATE_MEMORY_ROUTE)
static_assert(sizeof(ego_private_route_v2) == 112);
static_assert(offsetof(ego_private_route_v2, token_ascii) == 48);

DWORD initialize_memory_member(const ego_private_route_v2 *route)
{
    if (route == nullptr || route->struct_size != sizeof(*route) ||
        route->version != EGO_PRIVATE_ROUTE_VERSION || route->reserved != 0 || route->reserved2 != 0 ||
        route->port == 0 || route->producer_pid == 0 || route->producer_creation_time_100ns == 0 ||
        route->target_pid != GetCurrentProcessId() ||
        !std::all_of(std::begin(route->token_ascii), std::end(route->token_ascii), [](std::uint8_t c) {
            return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
        }))
        return ERROR_INVALID_PARAMETER;
    FILETIME created{}, exited{}, kernel{}, user{};
    if (!GetProcessTimes(GetCurrentProcess(), &created, &exited, &kernel, &user))
        return GetLastError();
    const auto birth = (static_cast<std::uint64_t>(created.dwHighDateTime) << 32) | created.dwLowDateTime;
    if (birth == 0 || birth != route->target_creation_time_100ns)
        return ERROR_INVALID_PARAMETER;

    const HANDLE producer = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | SYNCHRONIZE, FALSE,
        route->producer_pid);
    if (producer == nullptr)
        return GetLastError();
    const bool producer_live = GetProcessTimes(producer, &created, &exited, &kernel, &user) &&
        WaitForSingleObject(producer, 0) == WAIT_TIMEOUT;
    CloseHandle(producer);
    const auto producer_birth = (static_cast<std::uint64_t>(created.dwHighDateTime) << 32) | created.dwLowDateTime;
    if (!producer_live || producer_birth != route->producer_creation_time_100ns)
        return ERROR_INVALID_PARAMETER;

    const std::scoped_lock initialization_lock(g_member_initialization_mutex);
    if (g_reshade_host_module == nullptr)
        return ERROR_INVALID_FUNCTION;
    const auto same_route = [route](const ego_private_route_v2 &existing) {
        return existing.producer_pid == route->producer_pid &&
            existing.producer_creation_time_100ns == route->producer_creation_time_100ns &&
            existing.port == route->port &&
            std::equal(std::begin(existing.token_ascii), std::end(existing.token_ascii), std::begin(route->token_ascii));
    };
    if (is_preloaded_member())
    {
        if (!g_preload_bound_directory.empty() || (g_preloaded_memory_binding && !same_route(*g_preloaded_memory_binding)))
            return ERROR_ALREADY_ASSIGNED;
        // A dormant registry image has one lifetime binding. Reserve it before
        // publishing callbacks, including failures with an uncertain outcome.
        if (!g_preloaded_memory_binding) g_preloaded_memory_binding = *route;
    }
    for (const auto &entry : g_memory_members)
    {
        if (same_route(*entry->private_memory_route))
            return ERROR_SUCCESS;
    }
    if (g_memory_members.size() >= ego::cooperative::max_participants)
        return ERROR_TOO_MANY_SESS;
    auto state = std::make_unique<participant_state>();
    state->private_memory_route = *route;
    state->private_memory_route->input_capabilities = EGO_INPUT_CAPABILITY_COPIED_WM_INPUT |
        (g_has_private_input_observer ? EGO_INPUT_CAPABILITY_COPIED_RAW_INPUT_BUFFER : 0);
    auto *const context = state.get();
    // Own the allocation before making it visible to callbacks. Published
    // snapshots can outlive producer shutdown and retain this stable pointer.
    g_memory_members.push_back(std::move(state));
    const auto result = publish_cooperative_member(context);
    if (result == ERROR_SUCCESS)
        g_memory_dispatcher.store(true, std::memory_order_release);
    else
        g_memory_members.pop_back();
    return result;
}
#endif

DWORD initialize_automatic_member() noexcept
{
    if (is_preloaded_member())
        return ERROR_NOT_READY;
    try { return initialize_cooperative_member(nullptr, false); }
    catch (...) { return ERROR_DLL_INIT_FAILED; }
}

void register_dispatcher_events()
{
    if (g_dispatcher_events_registered)
        return;
    reshade::register_event<reshade::addon_event::init_swapchain>(on_init_swapchain);
    reshade::register_event<reshade::addon_event::destroy_swapchain>(on_destroy_swapchain);
    reshade::register_event<reshade::addon_event::destroy_effect_runtime>(on_destroy_effect_runtime);
    reshade::register_event<reshade::addon_event::reshade_overlay>(on_reshade_overlay);
    reshade::register_event<reshade::addon_event::reshade_present>(on_reshade_present_diagnostic);
    if (g_has_private_input_observer)
        reshade::register_event<reshade::addon_event::input_message>(on_input_message);
    g_dispatcher_events_registered = true;
    // Callback registration is complete independently of any private producer.
    InterlockedExchange(&ElectronGameOverlayCooperativeAdapterReadyV1, 1);
}
} // namespace

extern "C" __declspec(dllexport) const char *NAME = "Electron Game Overlay Runtime";
extern "C" __declspec(dllexport) const char *DESCRIPTION =
    "Backend-neutral Electron OSR scenes rendered through ReShade.";
extern "C" __declspec(dllexport) const unsigned int
    ElectronGameOverlayReShadeAddonAbi = 1;
extern "C" __declspec(dllexport) volatile LONG ElectronGameOverlayCooperativeReadyV1 = 0;
extern "C" __declspec(dllexport) __declspec(align(4)) volatile LONG ElectronGameOverlayCooperativeAdapterReadyV1 = 0;

#if defined(_M_IX86)
#pragma comment(linker, "/EXPORT:ElectronGameOverlayInitializeMember=_ElectronGameOverlayInitializeMember@4")
#pragma comment(linker, "/EXPORT:ElectronGameOverlayActivatePreloadedMemberV1=_ElectronGameOverlayActivatePreloadedMemberV1@4")
#pragma comment(linker, "/EXPORT:ElectronGameOverlayCanUnloadFailedMemberV1=_ElectronGameOverlayCanUnloadFailedMemberV1@0")
#endif
#if defined(EGO_EXPERIMENTAL_PRIVATE_MEMORY_ROUTE)
#if defined(_M_IX86)
#pragma comment(linker, "/EXPORT:ElectronGameOverlayInitializeMemoryMemberV2=_ElectronGameOverlayInitializeMemoryMemberV2@4")
#endif
extern "C" __declspec(dllexport) DWORD WINAPI ElectronGameOverlayInitializeMemoryMemberV2(const ego_private_route_v2 *route)
{
    try { return initialize_memory_member(route); }
    catch (...) { return ERROR_DLL_INIT_FAILED; }
}
#endif
extern "C" __declspec(dllexport) DWORD WINAPI ElectronGameOverlayInitializeMember(void *request)
{
    try { return initialize_cooperative_member(request, true); }
    catch (...) { return ERROR_DLL_INIT_FAILED; }
}
extern "C" __declspec(dllexport) DWORD WINAPI ElectronGameOverlayActivatePreloadedMemberV1(void *request)
{
    try { return initialize_cooperative_member(request, true, true); }
    catch (...) { return ERROR_DLL_INIT_FAILED; }
}
// The injector asks only after an explicit initializer failure. Absence,
// timeout or a zero result is never permission to unload mapped callbacks.
extern "C" __declspec(dllexport) DWORD WINAPI ElectronGameOverlayCanUnloadFailedMemberV1()
{
    try
    {
        const std::scoped_lock initialization_lock(g_member_initialization_mutex);
        const std::scoped_lock transport_lock(member().transport_mutex);
        return !g_module_pinned.load(std::memory_order_acquire) &&
            member().participant_id.load(std::memory_order_acquire) == 0 &&
            InterlockedCompareExchange(&ElectronGameOverlayCooperativeReadyV1, 0, 0) == 0 &&
            !g_cooperative_dispatcher && !g_public_registered && member().transport == nullptr &&
            member().transport_references == 0 ? 1 : 0;
    }
    catch (...) { return 0; }
}
#ifndef ELECTRON_GAME_OVERLAY_ADDON_BUILD_ID
#error "ELECTRON_GAME_OVERLAY_ADDON_BUILD_ID must be provided by the build."
#endif
#if defined(EGO_EXPERIMENTAL_PRIVATE_MEMORY_ROUTE)
static_assert(std::string_view(ELECTRON_GAME_OVERLAY_ADDON_BUILD_ID) != "CCE20935ADD44EF6A5A7973014B2E07F",
    "The private-memory member must have its own mapped build identity.");
#endif
extern "C" __declspec(dllexport) const char
    ElectronGameOverlayReShadeAddonBuildId[] =
        ELECTRON_GAME_OVERLAY_ADDON_BUILD_ID;
static_assert(
    sizeof(ElectronGameOverlayReShadeAddonBuildId) == 33,
    "The Electron Game Overlay add-on build ID must be 32 ASCII characters.");

// The loader also invokes DllMain on driver-created threads with small stacks.
// Keep process initialization behind a non-inlined boundary and put its bounded
// filename buffer on the heap, so every thread notification has a small frame.
__declspec(noinline) BOOL initialize_addon_process(HMODULE module)
{
    constexpr DWORD path_capacity = 32768;
    const std::unique_ptr<wchar_t[]> path(new (std::nothrow) wchar_t[path_capacity]);
    if (!path)
        return FALSE;
    const auto length = GetModuleFileNameW(module, path.get(), path_capacity);
    if (length == 0 || length == path_capacity)
        return FALSE;
    const std::wstring_view full_path(path.get(), length);
    const auto separator = full_path.find_last_of(L"\\/");
    const auto leaf = full_path.substr(separator == std::wstring_view::npos ? 0 : separator + 1);
    g_preload_identity = ego::preloaded_addon::classify_filename(leaf,
        ElectronGameOverlayReShadeAddonBuildId,
#ifdef _WIN64
        true
#else
        false
#endif
    );
    if (g_preload_identity.kind == ego::preloaded_addon::preload_filename_kind::invalid)
        return FALSE;
    if (is_preloaded_member())
        NAME = g_preload_identity.public_name.data();
    if (!g_cooperative.open())
        return FALSE;
    g_cooperative_dispatcher = g_cooperative.claim_dispatcher();
    if (!register_compatible_addon(module))
    {
        if (g_cooperative_dispatcher)
            g_cooperative.abandon_dispatcher_claim();
        return FALSE;
    }

    if (g_cooperative_dispatcher)
        register_dispatcher_events();
    return TRUE;
}

extern "C" __declspec(dllexport) bool AddonInit(HMODULE module, HMODULE)
{
    if (!g_cooperative_dispatcher && !is_preloaded_member())
        return true;
    if (!g_public_registered && !register_compatible_addon(module))
        return false;
    if (can_drive_dormant_adapter() && !g_module_pinned.load(std::memory_order_acquire))
    {
        // The scanner calls AddonInit after LoadLibrary releases the loader
        // lock. The sole baseline adapter survives independently of any app's
        // participant admission; offline metadata-only peers are not pinned.
        if (pin_cooperative_modules() != ERROR_SUCCESS)
        {
            AddonUninit(module, g_reshade_host_module);
            g_cooperative.abandon_dispatcher_claim();
            g_cooperative_dispatcher = false;
            return false;
        }
    }
    if (g_cooperative_dispatcher)
        register_dispatcher_events();
    return true;
}

extern "C" __declspec(dllexport) void AddonUninit(HMODULE module, HMODULE)
{
    if (g_cooperative_dispatcher)
    {
        InterlockedExchange(&ElectronGameOverlayCooperativeAdapterReadyV1, 0);
        g_adapter_window_ready.store(false, std::memory_order_release);
        shutdown_official_message_hooks(true);
        g_dispatcher_events_registered = false;
        g_cooperative_adapter_phase = input_phase::disabled;
    }
    if (g_cooperative_dispatcher || is_preloaded_member())
    {
        unregister_compatible_addon(module);
        g_public_registered = false;
    }
}

BOOL APIENTRY DllMain(HMODULE module, DWORD reason, LPVOID reserved)
{
    switch (reason)
    {
    case DLL_PROCESS_ATTACH:
        return initialize_addon_process(module);

    case DLL_PROCESS_DETACH:
        if (reserved == nullptr)
            shutdown_official_message_hooks(false);
        else
            g_official_hooks_shutting_down.store(
                true,
                std::memory_order_release);
        unregister_compatible_addon(module);
        break;
    }

    return TRUE;
}
